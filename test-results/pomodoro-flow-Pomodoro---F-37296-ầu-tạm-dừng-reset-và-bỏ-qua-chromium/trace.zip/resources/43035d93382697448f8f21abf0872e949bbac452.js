(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/services/firebase/config.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "appClient",
    ()=>appClient,
    "auth",
    ()=>auth,
    "db",
    ()=>db,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/app/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/app/dist/esm/index.esm.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/auth/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/auth/dist/esm/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
;
;
;
// Firebase configuration
const firebaseConfig = {
    apiKey: ("TURBOPACK compile-time value", "AIzaSyDwyj9ywmKxfQZJiIMCzfFg0Q8rhH-cAEc"),
    authDomain: ("TURBOPACK compile-time value", "auth.tdatdev.software"),
    projectId: ("TURBOPACK compile-time value", "vitisme-7e546"),
    storageBucket: ("TURBOPACK compile-time value", "vitisme-7e546.appspot.com"),
    messagingSenderId: ("TURBOPACK compile-time value", "213694170604"),
    appId: ("TURBOPACK compile-time value", "1:213694170604:web:007e3e328d7e8d1a85acc9"),
    measurementId: ("TURBOPACK compile-time value", "G-9NZ9RX2GQL")
};
// Chỉ khởi tạo Firebase trên trình duyệt hoặc khi có đủ biến môi trường.
const isBrowser = "object" !== 'undefined';
let app;
let authInstance;
let dbInstance;
try {
    const hasEnv = Boolean(firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId && firebaseConfig.appId);
    if (isBrowser && hasEnv) {
        // Kiểm tra xem đã có app nào chưa
        const existingApps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getApps"])();
        if (existingApps.length > 0) {
            app = existingApps[0];
        } else {
            app = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["initializeApp"])(firebaseConfig);
        }
        authInstance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getAuth"])(app);
        dbInstance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getFirestore"])(app);
        console.log('Firebase initialized successfully');
    } else {
        console.warn('Firebase not initialized - missing environment variables or not in browser');
    }
} catch (error) {
    console.error('Firebase initialization error:', error);
// Bỏ qua khi build server/CI không có env, tránh crash do auth/invalid-api-key
}
const appClient = app;
const auth = authInstance; // chỉ dùng ở client
const db = dbInstance; // chỉ dùng ở client
const __TURBOPACK__default__export__ = appClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/firebase/client.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "firebase",
    ()=>firebase,
    "firebaseAuth",
    ()=>firebaseAuth,
    "firestore",
    ()=>firestore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/auth/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/auth/dist/esm/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
;
;
;
const firebaseAuth = {
    // Đăng nhập bằng email và mật khẩu
    signInWithPassword: async (email, password)=>{
        try {
            const userCredential = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["signInWithEmailAndPassword"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], email, password);
            return {
                data: {
                    session: {
                        user: userCredential.user,
                        access_token: await userCredential.user.getIdToken()
                    }
                },
                error: null
            };
        } catch (error) {
            return {
                data: {
                    session: null
                },
                error
            };
        }
    },
    // Đăng ký tài khoản mới
    signUp: async (email, password)=>{
        try {
            const userCredential = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createUserWithEmailAndPassword"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], email, password);
            return {
                data: {
                    user: userCredential.user,
                    session: {
                        access_token: await userCredential.user.getIdToken()
                    }
                },
                error: null
            };
        } catch (error) {
            return {
                data: {
                    user: null,
                    session: null
                },
                error
            };
        }
    },
    // Đăng nhập với Google
    signInWithOAuth: async (param)=>{
        let { provider } = param;
        try {
            if (provider === 'google') {
                const googleProvider = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["GoogleAuthProvider"]();
                googleProvider.setCustomParameters({
                    prompt: 'select_account'
                });
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["signInWithPopup"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], googleProvider);
                return {
                    data: result,
                    error: null
                };
            }
            throw new Error("Unsupported provider: ".concat(provider));
        } catch (error) {
            return {
                data: null,
                error
            };
        }
    },
    // Đăng xuất
    signOut: async ()=>{
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["signOut"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"]);
            return {
                error: null
            };
        } catch (error) {
            return {
                error
            };
        }
    },
    // Lấy phiên hiện tại
    getSession: async ()=>{
        return new Promise((resolve)=>{
            const unsubscribe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["onAuthStateChanged"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], async (user)=>{
                unsubscribe();
                if (user) {
                    try {
                        const token = await user.getIdToken(true); // Force refresh token
                        resolve({
                            data: {
                                session: {
                                    user: user,
                                    access_token: token
                                }
                            },
                            error: null
                        });
                    } catch (error) {
                        resolve({
                            data: {
                                session: null
                            },
                            error
                        });
                    }
                } else {
                    resolve({
                        data: {
                            session: null
                        },
                        error: null
                    });
                }
            });
        });
    },
    // Theo dõi thay đổi trạng thái xác thực
    onAuthStateChange: (callback)=>{
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["onAuthStateChanged"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], callback);
    }
};
const firestore = {
    // Lấy thông tin profile người dùng
    getProfile: async (userId)=>{
        try {
            const docRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'profiles', userId);
            const docSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(docRef);
            if (docSnap.exists()) {
                return {
                    profile: docSnap.data(),
                    error: null
                };
            } else {
                return {
                    profile: null,
                    error: null
                };
            }
        } catch (error) {
            return {
                profile: null,
                error
            };
        }
    },
    // Cập nhật thông tin profile người dùng
    updateProfile: async (userId, data)=>{
        try {
            const docRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'profiles', userId);
            const docSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(docRef);
            if (docSnap.exists()) {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(docRef, data);
            } else {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(docRef, data);
            }
            return {
                error: null
            };
        } catch (error) {
            return {
                error
            };
        }
    },
    // Lấy danh sách flashcard
    getFlashcards: async (userId)=>{
        try {
            const decksRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'flashcard_decks');
            const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(decksRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId));
            const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
            const decks = [];
            querySnapshot.forEach((doc)=>{
                decks.push({
                    id: doc.id,
                    ...doc.data()
                });
            });
            return {
                decks,
                error: null
            };
        } catch (error) {
            return {
                decks: [],
                error
            };
        }
    },
    // Lấy danh sách habits
    getHabits: async (userId)=>{
        try {
            const habitsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habits');
            const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(habitsRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId));
            const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
            const habits = [];
            querySnapshot.forEach((doc)=>{
                habits.push({
                    id: doc.id,
                    ...doc.data()
                });
            });
            return {
                habits,
                error: null
            };
        } catch (error) {
            return {
                habits: [],
                error
            };
        }
    },
    // Cập nhật tiến độ học tập
    updateProgress: async (userId, data)=>{
        try {
            const today = new Date().toISOString().split('T')[0];
            const progressRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'progress', "".concat(userId, "_").concat(today));
            const docSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(progressRef);
            if (docSnap.exists()) {
                const currentData = docSnap.data();
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(progressRef, {
                    wordsLearned: (currentData.wordsLearned || 0) + (data.wordsLearned || 0),
                    studyTime: (currentData.studyTime || 0) + (data.studyTime || 0),
                    lastUpdated: new Date()
                });
            } else {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(progressRef, {
                    userId,
                    date: today,
                    wordsLearned: data.wordsLearned || 0,
                    studyTime: data.studyTime || 0,
                    createdAt: new Date(),
                    lastUpdated: new Date()
                });
            }
            // Cập nhật profile
            const userRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'profiles', userId);
            const userSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(userRef);
            if (userSnap.exists()) {
                const userData = userSnap.data();
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(userRef, {
                    todayProgress: (userData.todayProgress || 0) + (data.wordsLearned || 0),
                    totalWordsLearned: (userData.totalWordsLearned || 0) + (data.wordsLearned || 0),
                    lastActive: new Date()
                });
            }
            return {
                error: null
            };
        } catch (error) {
            return {
                error
            };
        }
    }
};
const firebase = {
    auth: firebaseAuth,
    firestore: firestore
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/ai/chatNaming.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "detectMessageLanguage",
    ()=>detectMessageLanguage,
    "generateChatTitle",
    ()=>generateChatTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$ai$2f$index$2e$ts__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/services/ai/index.ts [client] (ecmascript) <locals>");
;
async function generateChatTitle(firstMessage) {
    try {
        const prompt = 'Phân tích tin nhắn sau và tạo một tiêu đề ngắn gọn (tối đa 50 ký tự) cho cuộc trò chuyện. Tiêu đề nên thể hiện chủ đề chính hoặc ý định của người dùng. Chỉ trả về tiêu đề, không cần giải thích thêm:\n\n"'.concat(firstMessage, '"\n\nMột số ví dụ:\n- "How to learn English?" → "Học tiếng Anh"\n- "Tôi muốn cải thiện phát âm" → "Cải thiện phát âm"  \n- "What is the difference between..." → "So sánh ngữ pháp"\n- "Can you help me with homework?" → "Giúp bài tập"\n\nTiêu đề cho tin nhắn trên:');
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$ai$2f$index$2e$ts__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateTutorResponse"])(prompt, []);
        // Làm sạch response - loại bỏ dấu ngoặc kép và ký tự không cần thiết
        let title = response.replace(/^["']|["']$/g, '') // Loại bỏ dấu ngoặc kép ở đầu/cuối
        .replace(/\n[\s\S]*$/, '') // Chỉ lấy dòng đầu tiên (không dùng flag s)
        .trim();
        // Đảm bảo không quá dài
        if (title.length > 50) {
            title = title.substring(0, 47) + '...';
        }
        // Fallback nếu AI không tạo được tên hợp lý
        if (!title || title.length < 3) {
            title = firstMessage.length > 30 ? firstMessage.substring(0, 30) + '...' : firstMessage;
        }
        return title;
    } catch (error) {
        console.error('Error generating chat title:', error);
        // Fallback về cách cũ
        return firstMessage.length > 30 ? firstMessage.substring(0, 30) + '...' : firstMessage;
    }
}
function detectMessageLanguage(message) {
    // Kiểm tra ký tự tiếng Việt (có dấu)
    const vietnameseRegex = /[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]/i;
    if (vietnameseRegex.test(message)) {
        return 'vi';
    }
    // Kiểm tra từ khóa tiếng Việt không dấu phổ biến
    const vietnameseWords = [
        'toi',
        'ban',
        'la',
        'co',
        'khong',
        'gi',
        'nao',
        'nhu',
        'voi',
        'cua',
        'trong',
        'ngoai',
        'tren',
        'duoi',
        'hay',
        'hoac',
        'neu',
        'ma',
        'vi',
        'de'
    ];
    const lowerMessage = message.toLowerCase();
    const hasVietnameseWords = vietnameseWords.some((word)=>lowerMessage.includes(' ' + word + ' ') || lowerMessage.startsWith(word + ' ') || lowerMessage.endsWith(' ' + word));
    return hasVietnameseWords ? 'vi' : 'en';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/ai/index.ts [client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * Main AI Service for StudyFlow App
 * Centralized AI interactions with fallback system
 */ __turbopack_context__.s([
    "aiService",
    ()=>aiService,
    "default",
    ()=>__TURBOPACK__default__export__,
    "generateAISuggestions",
    ()=>generateAISuggestions,
    "generateTutorResponse",
    ()=>generateTutorResponse
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$google$2f$generative$2d$ai$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@google/generative-ai/dist/index.mjs [client] (ecmascript)");
// Export chat naming functions
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$ai$2f$chatNaming$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/ai/chatNaming.ts [client] (ecmascript)");
;
;
class AIService {
    initialize() {
        try {
            const apiKey = ("TURBOPACK compile-time value", "AIzaSyBpA2--PFTJ8Lrdl4YIH_Il7lCYlzuADWU");
            if ("TURBOPACK compile-time truthy", 1) {
                this.genAI = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$google$2f$generative$2d$ai$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["GoogleGenerativeAI"](apiKey);
                this.model = this.genAI.getGenerativeModel({
                    model: ("TURBOPACK compile-time value", "gemini-2.5-flash") || 'gemini-1.5-flash'
                });
                this.isInitialized = true;
                console.log('✅ AI Service initialized with Gemini');
            } else //TURBOPACK unreachable
            ;
        } catch (error) {
            console.error('❌ Failed to initialize AI Service:', error);
        }
    }
    /**
   * Generate AI response for English tutoring
   */ async generateTutorResponse(userMessage) {
        let history = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
        if (!this.isInitialized || !this.model) {
            return this.getFallbackResponse(userMessage);
        }
        try {
            const prompt = this.buildTutorPrompt(userMessage, history);
            const result = await this.model.generateContent(prompt);
            const response = await result.response;
            const text = response.text();
            return (text === null || text === void 0 ? void 0 : text.trim()) || this.getFallbackResponse(userMessage);
        } catch (error) {
            console.error('🔥 AI Generation Error:', error);
            return this.getFallbackResponse(userMessage);
        }
    }
    /**
   * Generate study suggestions
   */ async generateSuggestions() {
        let context = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        if (!this.isInitialized || !this.model) {
            return this.getFallbackSuggestions();
        }
        try {
            const prompt = this.buildSuggestionsPrompt(context);
            const result = await this.model.generateContent(prompt);
            const response = await result.response;
            const text = response.text();
            return this.parseSuggestions(text) || this.getFallbackSuggestions();
        } catch (error) {
            console.error('🔥 Suggestions Error:', error);
            return this.getFallbackSuggestions();
        }
    }
    /**
   * Build tutor prompt with system context
   */ buildTutorPrompt(message) {
        let history = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
        const systemPrompt = "Bạn là StudyFlow AI - trợ lý học tiếng Anh thông minh và thân thiện.\n\n🎯 VAI TRÒ:\n- Giáo viên tiếng Anh nhiệt tình, kiên nhẫn \n- Luôn khuyến khích và tạo động lực\n- Cung cấp phản hồi chi tiết và xây dựng\n\n📚 CHỨC NĂNG:\n1. GIẢI THÍCH TỪ VỰNG & NGỮ PHÁP\n2. LUYỆN TẬP HỘI THOẠI\n3. TẠO BÀI TẬP THỰC HÀNH  \n4. SỬA LỖI VÀ GỢI Ý\n5. ĐỘNG VIÊN HỌC TẬP\n\n💬 PHONG CÁCH:\n- Thân thiện, dễ hiểu\n- Sử dụng emoji phù hợp \n- Trả lời ngắn gọn nhưng đầy đủ\n- Ưu tiên tiếng Việt khi cần giải thích\n\n🌟 LƯU Ý:\n- Luôn khuyến khích thử thách mới\n- Phản hồi tích cực trước khi chỉ lỗi  \n- Bài tập phù hợp với trình độ\n- Giải thích từ khó bằng từ đơn giản";
        const historyText = history.slice(-6) // Giới hạn history để tránh token limit
        .map((msg)=>"".concat(msg.role === 'user' ? 'Học viên' : 'StudyFlow AI', ": ").concat(msg.content)).join('\n');
        return "".concat(systemPrompt, "\n\n").concat(historyText ? '📋 LỊCH SỬ HỘI THOẠI:\n' + historyText + '\n\n' : '', "💬 TIN NHẮN MỚI:\nHọc viên: ").concat(message, "\n\nStudyFlow AI:");
    }
    /**
   * Build suggestions prompt
   */ buildSuggestionsPrompt(_context) {
        const timeOfDay = new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening';
        return "Tạo 6 gợi ý học tập tiếng Anh cho ".concat(timeOfDay, '. Format JSON:\n[{"id":"1","title":"Tiêu đề ngắn","prompt":"Câu hỏi cụ thể","category":"vocabulary|grammar|conversation|writing"}]\n\nYêu cầu:\n- Phù hợp với thời gian ').concat(timeOfDay, "\n- Đa dạng về chủ đề và mức độ\n- Câu hỏi thú vị, thực tế\n- Tiêu đề thu hút, dễ hiểu\n\nVí dụ buổi sáng: từ vựng energy, grammar present tense\nVí dụ buổi chiều: conversation topics, writing skills  \nVí dụ buổi tối: review exercises, relaxing topics");
    }
    /**
   * Parse AI suggestions response
   */ parseSuggestions(response) {
        try {
            // Extract JSON from response
            const jsonMatch = response.match(/\[[\s\S]*\]/);
            if (jsonMatch) {
                const suggestions = JSON.parse(jsonMatch[0]);
                return suggestions.map((s, index)=>({
                        id: s.id || "suggestion-".concat(index + 1),
                        title: s.title || 'Gợi ý học tập',
                        prompt: s.prompt || 'Hãy cùng học tiếng Anh!',
                        category: s.category || 'general'
                    }));
            }
            return null;
        } catch (error) {
            console.error('Parse suggestions error:', error);
            return null;
        }
    }
    /**
   * Fallback response when AI is not available
   */ getFallbackResponse(message) {
        const responses = [
            '😊 Tôi hiểu bạn đang muốn học về: "' + message.slice(0, 50) + '...". Hãy thử hỏi cụ thể hơn nhé!',
            '🌟 Đây là câu hỏi hay! Tôi sẽ giúp bạn tìm hiểu về chủ đề này.',
            '📚 Cảm ơn bạn đã chia sẻ! Hãy cùng khám phá tiếng Anh nhé.',
            '💡 Tôi thấy bạn quan tâm đến việc học. Đó là điều tuyệt vời!',
            '🎯 Hãy cùng thực hành để cải thiện kỹ năng tiếng Anh của bạn!'
        ];
        return responses[Math.floor(Math.random() * responses.length)];
    }
    /**
   * Fallback suggestions when AI is not available
   */ getFallbackSuggestions() {
        const timeOfDay = new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening';
        const suggestions = {
            morning: [
                {
                    id: '1',
                    title: 'Từ vựng buổi sáng',
                    prompt: 'Dạy tôi 5 từ vựng về hoạt động buổi sáng',
                    category: 'vocabulary'
                },
                {
                    id: '2',
                    title: 'Chào hỏi tiếng Anh',
                    prompt: 'Cách chào hỏi lịch sự trong tiếng Anh',
                    category: 'conversation'
                },
                {
                    id: '3',
                    title: 'Present Simple',
                    prompt: 'Giải thích thì hiện tại đơn với ví dụ',
                    category: 'grammar'
                }
            ],
            afternoon: [
                {
                    id: '1',
                    title: 'Đàm thoại công việc',
                    prompt: 'Mô phỏng cuộc trò chuyện trong môi trường làm việc',
                    category: 'conversation'
                },
                {
                    id: '2',
                    title: 'Viết email',
                    prompt: 'Hướng dẫn viết email tiếng Anh chuyên nghiệp',
                    category: 'writing'
                },
                {
                    id: '3',
                    title: 'Từ vựng thức ăn',
                    prompt: 'Dạy tôi từ vựng về món ăn phổ biến',
                    category: 'vocabulary'
                }
            ],
            evening: [
                {
                    id: '1',
                    title: 'Ôn tập ngữ pháp',
                    prompt: 'Tạo bài tập ôn tập ngữ pháp cơ bản',
                    category: 'grammar'
                },
                {
                    id: '2',
                    title: 'Trò chuyện thư giãn',
                    prompt: 'Nói về sở thích và thời gian rảnh',
                    category: 'conversation'
                },
                {
                    id: '3',
                    title: 'Từ vựng cảm xúc',
                    prompt: 'Học từ vựng diễn tả cảm xúc và tâm trạng',
                    category: 'vocabulary'
                }
            ]
        };
        return suggestions[timeOfDay] || suggestions.afternoon;
    }
    /**
   * Check if AI service is available
   */ isAvailable() {
        return this.isInitialized && this.model !== null;
    }
    /**
   * Get service status
   */ getStatus() {
        return {
            available: this.isAvailable(),
            provider: this.isAvailable() ? 'Gemini AI' : 'Fallback System'
        };
    }
    constructor(){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__["_"])(this, "genAI", null);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__["_"])(this, "model", null);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__["_"])(this, "isInitialized", false);
        this.initialize();
    }
}
const aiService = new AIService();
const generateTutorResponse = function(message) {
    let history = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
    return aiService.generateTutorResponse(message, history);
};
;
const generateAISuggestions = function() {
    let context = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    return aiService.generateSuggestions(context);
};
const __TURBOPACK__default__export__ = aiService;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/fileProcessor.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * File Processing Service for AI Chat
 * Handles file upload and content extraction for AI processing
 */ __turbopack_context__.s([
    "createFilePreviewMessage",
    ()=>createFilePreviewMessage,
    "formatFileForAI",
    ()=>formatFileForAI,
    "processFile",
    ()=>processFile
]);
/**
 * Đọc nội dung file text (txt, js, ts, css, html, etc.)
 * Tích hợp AI analysis cho code files
 */ async function readTextFile(file) {
    return new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.onload = async (e)=>{
            var _e_target;
            const content = (_e_target = e.target) === null || _e_target === void 0 ? void 0 : _e_target.result;
            try {
                // Phân tích với AI dựa trên loại file
                const analysis = await analyzeTextFileWithAI(content, file.name);
                resolve("[File: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n\n📄 **Nội dung file:**\n```").concat(getFileLanguage(file.name), "\n").concat(content, "\n```\n\n🤖 **Phân tích AI:**\n").concat(analysis));
            } catch (error) {
                // Fallback nếu không thể phân tích với AI
                console.warn('Không thể phân tích file với AI:', error);
                resolve("[File: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n\n📄 **Nội dung file:**\n```").concat(getFileLanguage(file.name), "\n").concat(content, "\n```\n\n💡 **File đã được upload thành công. Bạn có thể hỏi AI về nội dung này.**"));
            }
        };
        reader.onerror = ()=>reject(new Error('Không thể đọc file text'));
        reader.readAsText(file, 'UTF-8');
    });
}
/**
 * Phân tích file text với AI dựa trên loại file
 */ async function analyzeTextFileWithAI(content, fileName) {
    try {
        const { analyzeCodeWithGemini, analyzeHTMLWithGemini, analyzeJSONWithGemini, analyzeMarkdownWithGemini } = await __turbopack_context__.A("[project]/src/services/ai/gemini.ts [client] (ecmascript, async loader)");
        const language = getFileLanguage(fileName);
        // Phân tích dựa trên loại file
        if ([
            'js',
            'ts',
            'jsx',
            'tsx',
            'py',
            'java',
            'cpp',
            'c',
            'php'
        ].includes(language)) {
            return await analyzeCodeWithGemini(content, language);
        } else if ([
            'html',
            'css'
        ].includes(language)) {
            return await analyzeHTMLWithGemini(content);
        } else if (language === 'json') {
            return await analyzeJSONWithGemini(content);
        } else if (language === 'md') {
            return await analyzeMarkdownWithGemini(content);
        } else {
            // Default analysis cho text files
            return "📝 **File text đã được đọc thành công.**\nNội dung: ".concat(content.length > 200 ? content.substring(0, 200) + '...' : content, "\n\n💡 **Bạn có thể hỏi AI về nội dung cụ thể trong file này.**");
        }
    } catch (error) {
        console.error('Error analyzing text file with AI:', error);
        throw error;
    }
}
/**
 * Lấy ngôn ngữ từ tên file
 */ function getFileLanguage(fileName) {
    var _fileName_split_pop;
    const ext = (_fileName_split_pop = fileName.split('.').pop()) === null || _fileName_split_pop === void 0 ? void 0 : _fileName_split_pop.toLowerCase();
    const languageMap = {
        js: 'javascript',
        ts: 'typescript',
        jsx: 'jsx',
        tsx: 'tsx',
        py: 'python',
        java: 'java',
        cpp: 'cpp',
        c: 'c',
        php: 'php',
        html: 'html',
        css: 'css',
        json: 'json',
        md: 'markdown',
        sql: 'sql',
        yaml: 'yaml',
        yml: 'yaml'
    };
    return languageMap[ext || ''] || 'text';
}
/**
 * Đọc nội dung hình ảnh và chuyển thành base64
 * Tích hợp với Gemini Vision API để phân tích nội dung hình ảnh
 */ async function readImageFile(file) {
    return new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.onload = async (e)=>{
            var _e_target;
            const result = (_e_target = e.target) === null || _e_target === void 0 ? void 0 : _e_target.result;
            try {
                // Gọi Gemini Vision API để phân tích hình ảnh
                const imageAnalysis = await analyzeImageWithGemini(result);
                resolve({
                    content: "[Hình ảnh: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n\n📸 **Phân tích hình ảnh:**\n").concat(imageAnalysis, "\n\n💡 **Lưu ý:** AI đã phân tích nội dung hình ảnh này. Bạn có thể hỏi thêm về chi tiết cụ thể."),
                    preview: result
                });
            } catch (error) {
                // Nếu không thể phân tích với AI, fallback về cách cũ
                console.warn('Không thể phân tích hình ảnh với AI:', error);
                // Thử phân tích cơ bản với AI text-based
                try {
                    const basicAnalysis = await analyzeImageBasic(file.name, file.size);
                    resolve({
                        content: "[Hình ảnh: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n\n📸 **Thông tin hình ảnh:**\n").concat(basicAnalysis, "\n\n💡 **Lưu ý:** Bạn có thể mô tả hình ảnh này để AI hỗ trợ tốt hơn."),
                        preview: result
                    });
                } catch (fallbackError) {
                    resolve({
                        content: "[Hình ảnh: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n\n📸 **Hình ảnh đã được upload thành công.**\nBạn có thể mô tả hình ảnh này hoặc hỏi AI về nội dung trong hình."),
                        preview: result
                    });
                }
            }
        };
        reader.onerror = ()=>reject(new Error('Không thể đọc file hình ảnh'));
        reader.readAsDataURL(file);
    });
}
/**
 * Phân tích hình ảnh với Gemini Vision API
 */ async function analyzeImageWithGemini(imageDataUrl) {
    try {
        // Import Gemini service dynamically để tránh circular dependency
        const { generateImageAnalysis } = await __turbopack_context__.A("[project]/src/services/ai/gemini.ts [client] (ecmascript, async loader)");
        // Extract base64 data từ data URL
        const base64Data = imageDataUrl.split(',')[1];
        const analysis = await generateImageAnalysis(base64Data);
        return analysis;
    } catch (error) {
        console.error('Error analyzing image with Gemini:', error);
        throw error;
    }
}
/**
 * Phân tích hình ảnh cơ bản với AI text-based
 */ async function analyzeImageBasic(fileName, fileSize) {
    try {
        const { analyzeMarkdownWithGemini } = await __turbopack_context__.A("[project]/src/services/ai/gemini.ts [client] (ecmascript, async loader)");
        const metadata = "Hình ảnh: ".concat(fileName, "\nKích thước: ").concat((fileSize / 1024).toFixed(1), " KB\nLoại: Image file\n\nĐây là một hình ảnh đã được upload. AI có thể giúp:\n- Hướng dẫn cách mô tả hình ảnh\n- Gợi ý câu hỏi về hình ảnh\n- Hỗ trợ phân tích nội dung khi được mô tả\n- Đề xuất cách sử dụng hình ảnh trong học tập");
        return await analyzeMarkdownWithGemini(metadata);
    } catch (error) {
        console.error('Error analyzing image basic:', error);
        return "📸 **Hình ảnh đã được nhận thành công.**\n\n💡 **AI có thể giúp bạn:**\n- Hướng dẫn cách mô tả hình ảnh\n- Gợi ý câu hỏi về hình ảnh\n- Hỗ trợ phân tích nội dung khi được mô tả\n\nHãy mô tả hình ảnh để AI có thể hỗ trợ tốt hơn.";
    }
}
/**
 * Xử lý file PDF với PDF.js
 */ async function readPdfFile(file) {
    try {
        // Import PDF.js dynamically
        const pdfjsLib = await __turbopack_context__.A("[project]/node_modules/pdfjs-dist/build/pdf.mjs [client] (ecmascript, async loader)");
        // Set worker source
        pdfjsLib.GlobalWorkerOptions.workerSrc = "//cdnjs.cloudflare.com/ajax/libs/pdf.js/".concat(pdfjsLib.version, "/pdf.worker.min.js");
        // Read file as ArrayBuffer
        const arrayBuffer = await file.arrayBuffer();
        // Load PDF
        const pdf = await pdfjsLib.getDocument({
            data: arrayBuffer
        }).promise;
        let fullText = '';
        // Extract text from all pages
        for(let pageNum = 1; pageNum <= pdf.numPages; pageNum++){
            const page = await pdf.getPage(pageNum);
            const textContent = await page.getTextContent();
            const pageText = textContent.items.map((item)=>item.str).join(' ');
            fullText += "\n--- Trang ".concat(pageNum, " ---\n").concat(pageText, "\n");
        }
        // Analyze PDF content with AI
        const analysis = await analyzePDFWithAI(fullText, file.name);
        return "[File PDF: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB - ").concat(pdf.numPages, " trang\n\n📄 **Nội dung PDF (đầy đủ):**\n").concat(fullText, "\n\n🤖 **Phân tích AI:**\n").concat(analysis);
    } catch (error) {
        console.error('Error reading PDF:', error);
        return "[File PDF: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n  \n❌ **Không thể đọc nội dung PDF tự động.**\nLỗi: ").concat(error instanceof Error ? error.message : 'Không xác định', "\n\n💡 **Gợi ý:** Bạn có thể copy-paste nội dung từ PDF hoặc chuyển đổi sang file text để AI có thể phân tích.");
    }
}
/**
 * Phân tích nội dung PDF với AI
 */ async function analyzePDFWithAI(content, fileName) {
    try {
        const { analyzeMarkdownWithGemini } = await __turbopack_context__.A("[project]/src/services/ai/gemini.ts [client] (ecmascript, async loader)");
        const enhancedContent = "PDF Analysis for: ".concat(fileName, "\n\n").concat(content, '\n\nĐây là nội dung từ file PDF "').concat(fileName, '". AI có thể giúp:\n- Tóm tắt nội dung chính\n- Trích xuất thông tin quan trọng\n- Phân tích và giải thích nội dung\n- Trả lời câu hỏi về nội dung PDF');
        return await analyzeMarkdownWithGemini(enhancedContent);
    } catch (error) {
        console.error('Error analyzing PDF with AI:', error);
        return '📄 **PDF "'.concat(fileName, '" đã được đọc thành công.**\nNội dung: ').concat(content.length > 200 ? content.substring(0, 200) + '...' : content, "\n\n💡 **Bạn có thể hỏi AI về nội dung cụ thể trong PDF này.**");
    }
}
/**
 * Xử lý file Word với mammoth.js
 */ async function readWordFile(file) {
    try {
        // Import mammoth dynamically
        const mammoth = await __turbopack_context__.A("[project]/node_modules/mammoth/lib/index.js [client] (ecmascript, async loader)");
        // Read file as ArrayBuffer
        const arrayBuffer = await file.arrayBuffer();
        // Convert Word to HTML
        const result = await mammoth.convertToHtml({
            arrayBuffer
        });
        // Extract text content (remove HTML tags)
        const textContent = result.value.replace(/<[^>]*>/g, '') // Remove HTML tags
        .replace(/\s+/g, ' ') // Normalize whitespace
        .trim();
        // Analyze Word content with AI
        const analysis = await analyzeWordWithAI(textContent, file.name);
        return "[File Word: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n\n📝 **Nội dung Word:**\n").concat(textContent.substring(0, 1000)).concat(textContent.length > 1000 ? '...' : '', "\n\n🤖 **Phân tích AI:**\n").concat(analysis);
    } catch (error) {
        console.error('Error reading Word file:', error);
        return "[File Word: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n  \n❌ **Không thể đọc nội dung Word tự động.**\nLỗi: ").concat(error instanceof Error ? error.message : 'Không xác định', "\n\n💡 **Gợi ý:** Bạn có thể copy-paste nội dung từ Word hoặc lưu file dưới dạng text để AI có thể phân tích.");
    }
}
/**
 * Phân tích nội dung Word với AI
 */ async function analyzeWordWithAI(content, fileName) {
    try {
        const { analyzeMarkdownWithGemini } = await __turbopack_context__.A("[project]/src/services/ai/gemini.ts [client] (ecmascript, async loader)");
        const enhancedContent = "Word Document Analysis for: ".concat(fileName, "\n\n").concat(content, '\n\nĐây là nội dung từ file Word "').concat(fileName, '". AI có thể giúp:\n- Tóm tắt nội dung chính\n- Phân tích cấu trúc document\n- Đề xuất cải thiện nội dung\n- Trả lời câu hỏi về nội dung document');
        return await analyzeMarkdownWithGemini(enhancedContent);
    } catch (error) {
        console.error('Error analyzing Word with AI:', error);
        return '📝 **Word document "'.concat(fileName, '" đã được đọc thành công.**\nNội dung: ').concat(content.length > 200 ? content.substring(0, 200) + '...' : content, "\n\n💡 **Bạn có thể hỏi AI về nội dung cụ thể trong document này.**");
    }
}
/**
 * Xử lý file Excel/CSV với SheetJS
 */ async function readExcelFile(file) {
    try {
        if (file.name.toLowerCase().endsWith('.csv')) {
            // Đọc file CSV như text file
            const content = await readTextFile(file);
            return content;
        } else {
            // Import SheetJS dynamically
            const XLSX = await __turbopack_context__.A("[project]/node_modules/xlsx/xlsx.mjs [client] (ecmascript, async loader)");
            // Read file as ArrayBuffer
            const arrayBuffer = await file.arrayBuffer();
            // Parse Excel file
            const workbook = XLSX.read(arrayBuffer, {
                type: 'array'
            });
            let excelContent = '';
            // Process each worksheet
            workbook.SheetNames.forEach((sheetName)=>{
                const worksheet = workbook.Sheets[sheetName];
                const jsonData = XLSX.utils.sheet_to_json(worksheet, {
                    header: 1
                });
                excelContent += "\n--- Sheet: ".concat(sheetName, " ---\n");
                // Convert to readable format
                jsonData.forEach((row, index)=>{
                    if (Array.isArray(row) && row.length > 0) {
                        excelContent += "Row ".concat(index + 1, ": ").concat(row.join(' | '), "\n");
                    }
                });
            });
            // Analyze Excel content with AI
            const analysis = await analyzeExcelWithAI(excelContent, file.name);
            return "[File Excel: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB - ").concat(workbook.SheetNames.length, " sheet(s)\n\n📊 **Nội dung Excel:**\n").concat(excelContent.substring(0, 1000)).concat(excelContent.length > 1000 ? '...' : '', "\n\n🤖 **Phân tích AI:**\n").concat(analysis);
        }
    } catch (error) {
        console.error('Error reading Excel file:', error);
        return "[File Excel: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n\n❌ **Không thể đọc nội dung Excel tự động.**\nLỗi: ").concat(error instanceof Error ? error.message : 'Không xác định', "\n\n💡 **Gợi ý:** Bạn có thể export file thành CSV hoặc copy-paste dữ liệu để AI có thể phân tích.");
    }
}
/**
 * Phân tích nội dung Excel với AI
 */ async function analyzeExcelWithAI(content, fileName) {
    try {
        const { analyzeJSONWithGemini } = await __turbopack_context__.A("[project]/src/services/ai/gemini.ts [client] (ecmascript, async loader)");
        const enhancedContent = "Excel Data Analysis for: ".concat(fileName, "\n\n").concat(content, '\n\nĐây là dữ liệu từ file Excel "').concat(fileName, '". AI có thể giúp:\n- Phân tích dữ liệu và xu hướng\n- Tạo báo cáo và thống kê\n- Đề xuất biểu đồ phù hợp\n- Trả lời câu hỏi về dữ liệu');
        return await analyzeJSONWithGemini(enhancedContent);
    } catch (error) {
        console.error('Error analyzing Excel with AI:', error);
        return '📊 **Excel file "'.concat(fileName, '" đã được đọc thành công.**\nNội dung: ').concat(content.length > 200 ? content.substring(0, 200) + '...' : content, "\n\n💡 **Bạn có thể hỏi AI về dữ liệu cụ thể trong Excel này.**");
    }
}
/**
 * Xử lý file PowerPoint
 */ async function readPowerPointFile(file) {
    try {
        // PowerPoint files are complex binary format, chúng ta sẽ phân tích metadata
        const analysis = await analyzePowerPointWithAI(file.name, file.size);
        return "[File PowerPoint: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n\n📊 **Thông tin file PowerPoint:**\n- Tên file: ").concat(file.name, "\n- Kích thước: ").concat((file.size / 1024).toFixed(1), " KB\n- Loại file: Microsoft PowerPoint Presentation\n\n🤖 **Phân tích AI:**\n").concat(analysis, "\n\n💡 **Lưu ý:** Để AI có thể phân tích nội dung chi tiết, bạn có thể:\n1. Copy-paste nội dung từ slides\n2. Export thành PDF và upload lại\n3. Mô tả nội dung slides cho AI");
    } catch (error) {
        console.error('Error analyzing PowerPoint file:', error);
        return "[File PowerPoint: ".concat(file.name, "] - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n\n📊 **File PowerPoint đã được nhận thành công.**\nHiện tại chưa hỗ trợ đọc nội dung PowerPoint tự động.\n\n💡 **Gợi ý:** Bạn có thể copy-paste nội dung từ slides hoặc export thành file text để AI có thể phân tích.");
    }
}
/**
 * Phân tích file PowerPoint với AI
 */ async function analyzePowerPointWithAI(fileName, fileSize) {
    try {
        const { analyzeMarkdownWithGemini } = await __turbopack_context__.A("[project]/src/services/ai/gemini.ts [client] (ecmascript, async loader)");
        const metadata = "File PowerPoint: ".concat(fileName, "\nKích thước: ").concat((fileSize / 1024).toFixed(1), " KB\nLoại: Microsoft PowerPoint Presentation\n\nĐây là một file PowerPoint. Để phân tích nội dung chi tiết, người dùng cần:\n1. Mô tả nội dung slides\n2. Copy-paste text từ slides\n3. Export thành PDF để AI có thể đọc\n\nAI có thể giúp:\n- Tạo outline cho presentation\n- Viết script cho slides\n- Đề xuất cải thiện nội dung\n- Tạo slide mới dựa trên yêu cầu");
        return await analyzeMarkdownWithGemini(metadata);
    } catch (error) {
        console.error('Error analyzing PowerPoint with AI:', error);
        return "📊 **File PowerPoint đã được nhận thành công.**\n\n💡 **AI có thể giúp bạn:**\n- Tạo outline cho presentation\n- Viết script cho slides  \n- Đề xuất cải thiện nội dung\n- Tạo slide mới dựa trên yêu cầu\n\nHãy mô tả nội dung slides hoặc yêu cầu cụ thể để AI hỗ trợ tốt hơn.";
    }
}
/**
 * Phân tích file không xác định với AI
 */ async function analyzeUnknownFileWithAI(file) {
    try {
        var _file_name_split_pop;
        const { analyzeMarkdownWithGemini } = await __turbopack_context__.A("[project]/src/services/ai/gemini.ts [client] (ecmascript, async loader)");
        const metadata = "File: ".concat(file.name, "\nLoại: ").concat(file.type || 'Không xác định', "\nKích thước: ").concat((file.size / 1024).toFixed(1), " KB\nExtension: ").concat(((_file_name_split_pop = file.name.split('.').pop()) === null || _file_name_split_pop === void 0 ? void 0 : _file_name_split_pop.toLowerCase()) || 'không có', "\n\nĐây là một file không được hỗ trợ đọc nội dung tự động. AI có thể giúp:\n1. Đề xuất cách xử lý file này\n2. Gợi ý công cụ phù hợp để mở file\n3. Hướng dẫn chuyển đổi sang format được hỗ trợ\n4. Phân tích metadata và đưa ra lời khuyên");
        return await analyzeMarkdownWithGemini(metadata);
    } catch (error) {
        console.error('Error analyzing unknown file with AI:', error);
        return "📁 **File không được hỗ trợ đọc tự động.**\n\n💡 **AI có thể giúp bạn:**\n- Đề xuất cách xử lý file này\n- Gợi ý công cụ phù hợp để mở file\n- Hướng dẫn chuyển đổi sang format được hỗ trợ\n\nHãy mô tả file hoặc yêu cầu cụ thể để AI hỗ trợ tốt hơn.";
    }
}
async function processFile(file) {
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
        throw new Error('File quá lớn (tối đa 10MB)');
    }
    const fileContent = {
        name: file.name,
        type: file.type,
        size: file.size,
        content: ''
    };
    try {
        // Text files
        if (file.type.startsWith('text/') || file.name.match(/\.(txt|js|ts|jsx|tsx|css|html|xml|json|md|py|java|cpp|c|php|sql|yaml|yml|ini|conf|log)$/i)) {
            fileContent.content = await readTextFile(file);
        } else if (file.type.startsWith('image/')) {
            const { content, preview } = await readImageFile(file);
            fileContent.content = content;
            fileContent.preview = preview;
        } else if (file.type === 'application/pdf') {
            fileContent.content = await readPdfFile(file);
        } else if (file.type.includes('word') || file.name.match(/\.(doc|docx)$/i)) {
            fileContent.content = await readWordFile(file);
        } else if (file.type.includes('spreadsheet') || file.type.includes('excel') || file.name.match(/\.(xlsx|xls|csv)$/i)) {
            fileContent.content = await readExcelFile(file);
        } else if (file.type.includes('presentation') || file.name.match(/\.(ppt|pptx)$/i)) {
            fileContent.content = await readPowerPointFile(file);
        } else if (file.type.includes('zip') || file.type.includes('rar') || file.type.includes('7z') || file.name.match(/\.(zip|rar|7z|tar|gz)$/i)) {
            throw new Error('File nén (zip, rar, 7z) không được hỗ trợ. Vui lòng giải nén và gửi file riêng lẻ.');
        } else {
            // Thử phân tích với AI dựa trên metadata
            try {
                const analysis = await analyzeUnknownFileWithAI(file);
                fileContent.content = "[File: ".concat(file.name, "] - Loại: ").concat(file.type || 'Không xác định', " - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n\n📁 **Thông tin file:**\n- Tên: ").concat(file.name, "\n- Loại: ").concat(file.type || 'Không xác định', "\n- Kích thước: ").concat((file.size / 1024).toFixed(1), " KB\n\n🤖 **Phân tích AI:**\n").concat(analysis, "\n\n💡 **Gợi ý:** Các loại file được hỗ trợ đầy đủ: text, code, hình ảnh, PDF, Word, Excel, PowerPoint.\nBạn có thể copy-paste nội dung vào tin nhắn để AI phân tích chi tiết hơn.");
            } catch (error) {
                fileContent.content = "[File: ".concat(file.name, "] - Loại: ").concat(file.type || 'Không xác định', " - Kích thước: ").concat((file.size / 1024).toFixed(1), "KB\n      \n      File này chưa được hỗ trợ đọc nội dung tự động. \n      Các loại file được hỗ trợ: text, code, hình ảnh, PDF, Word, Excel, PowerPoint.\n      Bạn có thể copy-paste nội dung vào tin nhắn để AI phân tích.");
            }
        }
        return fileContent;
    } catch (error) {
        throw new Error("Lỗi xử lý file: ".concat(error instanceof Error ? error.message : 'Không xác định'));
    }
}
function formatFileForAI(fileContent, userMessage) {
    const separator = '\n' + '='.repeat(50) + '\n';
    let prompt = "Người dùng đã gửi một file kèm tin nhắn. Hãy phân tích nội dung file và trả lời theo yêu cầu.\n\n📁 **Thông tin file:**\n- Tên: ".concat(fileContent.name, "\n- Loại: ").concat(fileContent.type, "\n- Kích thước: ").concat((fileContent.size / 1024).toFixed(1), "KB\n\n💬 **Tin nhắn từ người dùng:**\n").concat(userMessage, "\n\n").concat(separator, "\n📄 **Nội dung file:**\n").concat(fileContent.content, "\n").concat(separator, "\n\nHãy phân tích file và trả lời câu hỏi của người dùng một cách chi tiết và hữu ích.");
    return prompt;
}
function createFilePreviewMessage(fileContent, userMessage) {
    const fileEmoji = getFileEmoji(fileContent.type, fileContent.name);
    let message = "".concat(fileEmoji, " **").concat(fileContent.name, "** (").concat((fileContent.size / 1024).toFixed(1), "KB)");
    // Nicely format a short preview depending on file type for better aesthetics
    const lowerName = fileContent.name.toLowerCase();
    const isImage = fileContent.type.startsWith('image/');
    const isPdf = fileContent.type.includes('pdf') || /\.pdf$/i.test(lowerName);
    const isWord = fileContent.type.includes('word') || /\.(doc|docx)$/i.test(lowerName);
    const isExcel = fileContent.type.includes('sheet') || /\.(xlsx|xls|csv)$/i.test(lowerName);
    const isText = fileContent.type.startsWith('text/') || /\.(txt|md)$/i.test(lowerName);
    const isCode = /\.(js|ts|jsx|tsx|css|html|json|xml|py|java|cpp|c|php|sql)$/i.test(lowerName);
    const previewLimit = 800; // characters to preview inside message bubble
    if (isImage) {
    // Keep compact for images (preview shown separately by UI if needed)
    } else if (isPdf) {
        message += "\n\n> PDF attached. I will read and analyze its content.";
    } else if (isWord) {
        message += "\n\n> Word document attached. I will extract and analyze its content.";
    } else if (isExcel) {
        message += "\n\n> Spreadsheet attached. I will parse and analyze its data.";
    } else if (isText || isCode) {
        const lang = getFileLanguage(fileContent.name) || 'text';
        const snippet = (fileContent.content || '').slice(0, previewLimit);
        if (snippet.trim()) {
            message += "\n\nPreview:\n\n```".concat(lang, "\n").concat(snippet, "\n```");
            if ((fileContent.content || '').length > previewLimit) {
                message += "\n\n… (truncated preview)";
            }
        }
    }
    if (userMessage.trim()) {
        message += "\n\n".concat(userMessage);
    }
    return message;
}
/**
 * Lấy emoji phù hợp cho loại file
 */ function getFileEmoji(type, name) {
    if (type.startsWith('image/')) return '🖼️';
    if (type.includes('pdf')) return '📄';
    if (type.includes('word') || name.match(/\.(doc|docx)$/i)) return '📝';
    if (type.startsWith('text/') || name.match(/\.(txt|md)$/i)) return '📃';
    if (name.match(/\.(js|ts|jsx|tsx|css|html)$/i)) return '💻';
    if (name.match(/\.(json|xml)$/i)) return '📊';
    if (name.match(/\.(xlsx|xls|csv)$/i)) return '📊';
    if (name.match(/\.(ppt|pptx)$/i)) return '📊';
    if (name.match(/\.(py|java|cpp|c|php|sql)$/i)) return '💻';
    if (name.match(/\.(zip|rar|7z|tar|gz)$/i)) return '🗜️';
    return '📁';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/fileDownload.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * File Download Service
 * Xử lý việc tạo và download file từ AI responses
 */ __turbopack_context__.s([
    "createFileFromContent",
    ()=>createFileFromContent,
    "createFilesFromAIResponse",
    ()=>createFilesFromAIResponse,
    "downloadFile",
    ()=>downloadFile,
    "extractCodeBlocks",
    ()=>extractCodeBlocks
]);
function downloadFile(file) {
    try {
        let blob;
        if (file.mimeType.startsWith('text/') || file.mimeType === 'application/json') {
            // Text files
            blob = new Blob([
                file.content
            ], {
                type: file.mimeType
            });
        } else if (file.mimeType.startsWith('image/')) {
            // Image files (base64)
            const base64Data = file.content.replace(/^data:image\/[a-z]+;base64,/, '');
            const byteCharacters = atob(base64Data);
            const byteNumbers = new Array(byteCharacters.length);
            for(let i = 0; i < byteCharacters.length; i++){
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            blob = new Blob([
                byteArray
            ], {
                type: file.mimeType
            });
        } else {
            // Default to text
            blob = new Blob([
                file.content
            ], {
                type: 'text/plain'
            });
        }
        // Tạo URL và download
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = file.name;
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        // Cleanup
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error('Error downloading file:', error);
        throw new Error('Không thể tải file xuống');
    }
}
function createFileFromContent(content, fileName) {
    let fileType = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 'txt';
    const mimeTypes = {
        txt: 'text/plain',
        js: 'text/javascript',
        ts: 'text/typescript',
        jsx: 'text/javascript',
        tsx: 'text/typescript',
        css: 'text/css',
        html: 'text/html',
        json: 'application/json',
        xml: 'application/xml',
        md: 'text/markdown',
        py: 'text/x-python',
        java: 'text/x-java-source',
        cpp: 'text/x-c++src',
        c: 'text/x-csrc',
        php: 'text/x-php',
        sql: 'text/x-sql',
        csv: 'text/csv',
        yaml: 'text/yaml',
        yml: 'text/yaml'
    };
    return {
        name: fileName,
        content,
        type: fileType,
        mimeType: mimeTypes[fileType] || 'text/plain'
    };
}
function extractCodeBlocks(content) {
    const files = [];
    // Regex để tìm code blocks với filename
    const codeBlockRegex = /```(\w+)?\s*([^\n]*)\n([\s\S]*?)```/g;
    let match;
    while((match = codeBlockRegex.exec(content)) !== null){
        const language = match[1] || 'txt';
        const filename = match[2].trim() || "code.".concat(language);
        const code = match[3].trim();
        if (code) {
            files.push(createFileFromContent(code, filename, language));
        }
    }
    return files;
}
function createFilesFromAIResponse(content) {
    let baseFileName = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'ai_response';
    const files = [];
    // Thử extract code blocks trước
    const codeFiles = extractCodeBlocks(content);
    if (codeFiles.length > 0) {
        files.push(...codeFiles);
    } else {
        // Nếu không có code blocks, tạo file text
        files.push(createFileFromContent(content, "".concat(baseFileName, ".txt")));
    }
    return files;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/firebase/firestore.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createChatSession",
    ()=>createChatSession,
    "deleteChatSession",
    ()=>deleteChatSession,
    "getChatMessages",
    ()=>getChatMessages,
    "getChatSessions",
    ()=>getChatSessions,
    "getUserProfile",
    ()=>getUserProfile,
    "renameChatSession",
    ()=>renameChatSession,
    "saveMessage",
    ()=>saveMessage,
    "updateUserProfile",
    ()=>updateUserProfile,
    "updateUserProgress",
    ()=>updateUserProgress
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
;
;
/**
 * Gói tiện ích chạy một promise với timeout an toàn, luôn clearTimeout để tránh unhandled rejection.
 */ async function raceWithTimeout(promise) {
    let ms = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 10000;
    let timer;
    const timeoutPromise = new Promise((_, reject)=>{
        timer = setTimeout(()=>reject(new Error('Operation timeout')), ms);
    });
    try {
        const result = await Promise.race([
            promise,
            timeoutPromise
        ]);
        return result;
    } finally{
        if (timer) {
            clearTimeout(timer);
        }
    }
}
async function getUserProfile(userId) {
    try {
        const profileRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'user_profiles', userId);
        const profileDoc = await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(profileRef));
        if (profileDoc.exists()) {
            return {
                profile: {
                    id: profileDoc.id,
                    ...profileDoc.data()
                },
                error: null
            };
        } else {
            return {
                profile: null,
                error: null
            };
        }
    } catch (error) {
        console.error('Error getting user profile:', error);
        return {
            profile: null,
            error
        };
    }
}
async function updateUserProfile(userId, profileData) {
    try {
        const profileRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'user_profiles', userId);
        await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(profileRef, {
            ...profileData,
            updatedAt: new Date().toISOString()
        }));
        return {
            success: true,
            error: null
        };
    } catch (error) {
        console.error('Error updating user profile:', error);
        return {
            success: false,
            error
        };
    }
}
async function updateUserProgress(userId, progress) {
    try {
        const profileRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'user_profiles', userId);
        const profileDoc = await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(profileRef));
        if (profileDoc.exists()) {
            const profileData = profileDoc.data();
            const currentDate = new Date().toISOString().split('T')[0];
            const lastUpdateDate = profileData.lastUpdateDate || '';
            // Kiểm tra xem đã cập nhật streak hôm nay chưa
            let newStreak = profileData.streak || 0;
            if (lastUpdateDate !== currentDate) {
                // Nếu hôm qua đã cập nhật thì tăng streak
                const yesterday = new Date();
                yesterday.setDate(yesterday.getDate() - 1);
                const yesterdayStr = yesterday.toISOString().split('T')[0];
                if (lastUpdateDate === yesterdayStr) {
                    newStreak++;
                } else if (lastUpdateDate !== currentDate) {
                    // Nếu không phải hôm qua, reset streak
                    newStreak = 1;
                }
            }
            await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(profileRef, {
                totalWordsLearned: (profileData.totalWordsLearned || 0) + progress.wordsLearned,
                totalStudyTime: (profileData.totalStudyTime || 0) + progress.studyTime,
                todayProgress: (profileData.todayProgress || 0) + progress.wordsLearned,
                streak: newStreak,
                lastUpdateDate: currentDate,
                updatedAt: new Date().toISOString()
            }));
            return {
                success: true,
                error: null
            };
        } else {
            return {
                success: false,
                error: 'Profile not found'
            };
        }
    } catch (error) {
        console.error('Error updating user progress:', error);
        return {
            success: false,
            error
        };
    }
}
async function getChatSessions(userId) {
    try {
        const sessionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'chat_sessions');
        const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(sessionsRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId));
        const querySnapshot = await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(q));
        const sessions = [];
        querySnapshot.forEach((doc)=>{
            sessions.push({
                id: doc.id,
                ...doc.data()
            });
        });
        return sessions.sort((a, b)=>{
            return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
        });
    } catch (error) {
        console.error('Error getting chat sessions:', error);
        return [];
    }
}
async function createChatSession(userId) {
    try {
        const sessionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'chat_sessions');
        const newSession = {
            userId: userId,
            title: 'Cuộc trò chuyện mới',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            messageCount: 0
        };
        const docRef = await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["addDoc"])(sessionsRef, newSession));
        return docRef.id;
    } catch (error) {
        console.error('Error creating chat session:', error);
        throw error;
    }
}
async function deleteChatSession(chatId) {
    try {
        await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["deleteDoc"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'chat_sessions', chatId)));
    } catch (error) {
        console.error('Error deleting chat session:', error);
        throw error;
    }
}
async function renameChatSession(chatId, newTitle) {
    try {
        const sessionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'chat_sessions', chatId);
        await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(sessionRef, {
            title: newTitle,
            updatedAt: new Date().toISOString()
        }));
    } catch (error) {
        console.error('Error renaming chat session:', error);
        throw error;
    }
}
async function getChatMessages(chatId) {
    try {
        const messagesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'chat_messages');
        const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(messagesRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('chatId', '==', chatId));
        const querySnapshot = await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(q));
        const messages = [];
        querySnapshot.forEach((doc)=>{
            messages.push({
                id: doc.id,
                ...doc.data()
            });
        });
        return messages.sort((a, b)=>{
            return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
        });
    } catch (error) {
        console.error('Error getting chat messages:', error);
        return [];
    }
}
async function saveMessage(chatId, message) {
    try {
        var _sessionDoc_data;
        // Lưu tin nhắn
        const messagesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'chat_messages');
        const messageDataRaw = {
            ...message,
            chatId,
            // Firestore không cho phép undefined; mặc định attachments là mảng rỗng
            attachments: Array.isArray(message === null || message === void 0 ? void 0 : message.attachments) ? message.attachments : []
        };
        // Loại bỏ các field undefined ở mức shallow
        const messageData = Object.fromEntries(Object.entries(messageDataRaw).filter((param)=>{
            let [, v] = param;
            return v !== undefined;
        }));
        const docRef = await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["addDoc"])(messagesRef, messageData));
        // Cập nhật session
        const sessionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'chat_sessions', chatId);
        const sessionDoc = await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(sessionRef));
        await raceWithTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(sessionRef, {
            updatedAt: new Date().toISOString(),
            messageCount: ((_sessionDoc_data = sessionDoc.data()) === null || _sessionDoc_data === void 0 ? void 0 : _sessionDoc_data.messageCount) + 1 || 1
        }));
        return docRef.id;
    } catch (error) {
        console.error('Error saving message:', error);
        throw error;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/gemini/config.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "geminiConfig",
    ()=>geminiConfig,
    "genAI",
    ()=>genAI,
    "generateGeminiResponse",
    ()=>generateGeminiResponse,
    "generateLocalAIResponse",
    ()=>generateLocalAIResponse,
    "getGeminiModel",
    ()=>getGeminiModel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$google$2f$generative$2d$ai$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@google/generative-ai/dist/index.mjs [client] (ecmascript)");
;
// Lấy API key từ biến môi trường
const apiKey = ("TURBOPACK compile-time value", "AIzaSyBpA2--PFTJ8Lrdl4YIH_Il7lCYlzuADWU") || '';
const genAI = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$google$2f$generative$2d$ai$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["GoogleGenerativeAI"](apiKey);
const geminiConfig = {
    // Sử dụng model công khai khuyến nghị (latest) nếu không cấu hình ENV
    model: ("TURBOPACK compile-time value", "gemini-2.5-flash") || 'gemini-2.5-flash',
    maxOutputTokens: 1000,
    temperature: 0.9,
    topP: 0.95,
    topK: 40
};
// Preamble hệ thống: hướng dẫn AI luôn hỗ trợ mọi môn học, tiếng Việt, tuân thủ StudyFlow
const SYSTEM_PROMPT = "Bạn là trợ lý học tập của StudyFlow.\n- Hỗ trợ TẤT CẢ môn học/kiến thức (ngôn ngữ, STEM, xã hội, kỹ năng mềm, v.v.).\n- Luôn trả lời bằng tiếng Việt, rõ ràng, ngắn gọn, có cấu trúc, ưu tiên từng bước dễ hiểu cho sinh viên năm 1.\n- Tuân thủ quy tắc UI/UX của ứng dụng khi cần tạo dữ liệu (không dùng markdown không cần thiết khi yêu cầu dữ liệu máy đọc).\n- Khi người dùng yêu cầu tạo flashcards hoặc dữ liệu có cấu trúc, trả về đúng định dạng mà client mong đợi.";
const getGeminiModel = ()=>{
    return genAI.getGenerativeModel({
        model: geminiConfig.model
    });
};
const generateGeminiResponse = async function(prompt) {
    let _chatHistory = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
    try {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        // Không log nội dung prompt để bảo mật system prompt và dữ liệu người dùng
        if ("TURBOPACK compile-time truthy", 1) {
            console.log('Calling Gemini API');
        }
        // Gọi đúng một model đã cấu hình (hoặc default). Nếu lỗi, rơi về local ngay để tránh spam 404
        const modelId = geminiConfig.model || 'gemini-1.5-flash';
        try {
            const model = genAI.getGenerativeModel({
                model: modelId
            });
            const combinedPrompt = "".concat(SYSTEM_PROMPT, "\n\n").concat(prompt);
            const result = await model.generateContent(combinedPrompt);
            const response = await result.response;
            const text = response.text();
            return text;
        } catch (error) {
            if ("TURBOPACK compile-time truthy", 1) {
                console.error('Error generating content with model "'.concat(modelId, '":'), error);
            }
            return generateLocalAIResponse(prompt);
        }
    } catch (error) {
        if ("TURBOPACK compile-time truthy", 1) {
            console.error('Error generating Gemini response:', error);
        }
        // Luôn trả fallback để không chặn luồng UX
        return generateLocalAIResponse(prompt);
    }
};
const generateLocalAIResponse = (userMessage)=>{
    // Nếu người dùng yêu cầu tạo flashcards, trả về JSON chuẩn để UI có thể parse sử dụng luôn
    const lower = userMessage.toLowerCase();
    if (lower.includes('flashcard')) {
        const items = Array.from({
            length: 10
        }).map((_, i)=>({
                front: "Grammar Tip ".concat(i + 1),
                back: "Basic English grammar rule #".concat(i + 1, "."),
                example: "This is example sentence #".concat(i + 1, "."),
                exampleTranslation: "Đây là câu ví dụ số ".concat(i + 1, ".")
            }));
        return JSON.stringify({
            flashcards: items
        });
    }
    const responses = [
        '🔌 Hiện tại tôi không thể kết nối tới máy chủ AI. Trong lúc chờ đợi, bạn có thể:\n\n📚 Ôn tập flashcards đã tạo\n⏰ Sử dụng Pomodoro timer để học tập\n✅ Hoàn thành thói quen học tập hàng ngày\n\n🔄 Vui lòng kiểm tra kết nối internet và thử lại sau!',
        '💡 Tôi đang gặp sự cố kỹ thuật tạm thời. Đây là một số gợi ý học tiếng Anh bạn có thể thử:\n\n🎧 Nghe podcast tiếng Anh 15-20 phút/ngày\n📖 Đọc tin tức trên BBC Learning English\n✍️ Viết nhật ký bằng tiếng Anh\n🗣️ Nói chuyện với bản thân bằng tiếng Anh\n\n⚡ Hãy thử lại sau vài phút nhé!',
        '🚧 Đường truyền tới AI server đang được bảo trì. Trong khi chờ đợi:\n\n📱 Hãy thử các chức năng khác trong app\n📝 Tạo flashcards thủ công\n⏲️ Luyện tập với Pomodoro timer\n📊 Kiểm tra tiến độ học tập của bạn\n\n🔄 Tôi sẽ quay lại sớm thôi!'
    ];
    return responses[Math.floor(Math.random() * responses.length)];
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/level/levelSystem.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LEVEL_THRESHOLDS",
    ()=>LEVEL_THRESHOLDS,
    "XP_ACTIONS",
    ()=>XP_ACTIONS,
    "addXP",
    ()=>addXP,
    "calculateLevel",
    ()=>calculateLevel,
    "getLevelColor",
    ()=>getLevelColor,
    "getLevelIcon",
    ()=>getLevelIcon,
    "getLevelInfo",
    ()=>getLevelInfo,
    "getProgressText",
    ()=>getProgressText,
    "getXPProgress",
    ()=>getXPProgress
]);
const XP_ACTIONS = {
    COMPLETE_FLASHCARD: {
        amount: 5,
        description: 'Hoàn thành flashcard'
    },
    COMPLETE_POMODORO: {
        amount: 25,
        description: 'Hoàn thành phiên pomodoro'
    },
    CHAT_WITH_AI: {
        amount: 3,
        description: 'Trò chuyện với AI'
    },
    COMPLETE_HABIT: {
        amount: 10,
        description: 'Hoàn thành thói quen hàng ngày'
    },
    CREATE_FLASHCARD_DECK: {
        amount: 15,
        description: 'Tạo bộ flashcard mới'
    },
    DAILY_LOGIN: {
        amount: 5,
        description: 'Đăng nhập hàng ngày'
    },
    STREAK_BONUS_3: {
        amount: 20,
        description: 'Bonus 3 ngày liên tiếp'
    },
    STREAK_BONUS_7: {
        amount: 50,
        description: 'Bonus 7 ngày liên tiếp'
    },
    STREAK_BONUS_30: {
        amount: 200,
        description: 'Bonus 30 ngày liên tiếp'
    }
};
const LEVEL_THRESHOLDS = [
    {
        level: 1,
        xpRequired: 0,
        title: 'Người mới bắt đầu'
    },
    {
        level: 2,
        xpRequired: 100,
        title: 'Học viên tập sự'
    },
    {
        level: 3,
        xpRequired: 250,
        title: 'Học viên chăm chỉ'
    },
    {
        level: 4,
        xpRequired: 500,
        title: 'Học sinh giỏi'
    },
    {
        level: 5,
        xpRequired: 800,
        title: 'Học sinh xuất sắc'
    },
    {
        level: 6,
        xpRequired: 1200,
        title: 'Chuyên gia nhỏ'
    },
    {
        level: 7,
        xpRequired: 1700,
        title: 'Chuyên gia'
    },
    {
        level: 8,
        xpRequired: 2300,
        title: 'Cao thủ'
    },
    {
        level: 9,
        xpRequired: 3000,
        title: 'Bậc thầy'
    },
    {
        level: 10,
        xpRequired: 4000,
        title: 'Đại sư'
    },
    {
        level: 11,
        xpRequired: 5200,
        title: 'Truyền thuyết'
    },
    {
        level: 12,
        xpRequired: 6600,
        title: 'Huyền thoại'
    },
    {
        level: 13,
        xpRequired: 8200,
        title: 'Thần thoại'
    },
    {
        level: 14,
        xpRequired: 10000,
        title: 'Vô địch thiên hạ'
    },
    {
        level: 15,
        xpRequired: 12000,
        title: 'Siêu phàm'
    }
];
function calculateLevel(totalXP) {
    let userLevel = LEVEL_THRESHOLDS[0];
    // Tìm level hiện tại
    for(let i = LEVEL_THRESHOLDS.length - 1; i >= 0; i--){
        if (totalXP >= LEVEL_THRESHOLDS[i].xpRequired) {
            userLevel = LEVEL_THRESHOLDS[i];
            break;
        }
    }
    // Tìm level tiếp theo
    const nextLevelIndex = LEVEL_THRESHOLDS.findIndex((l)=>l.level === userLevel.level + 1);
    const nextLevel = nextLevelIndex !== -1 ? LEVEL_THRESHOLDS[nextLevelIndex] : null;
    const currentLevelXP = userLevel.xpRequired;
    const nextLevelXP = (nextLevel === null || nextLevel === void 0 ? void 0 : nextLevel.xpRequired) || totalXP;
    const currentXP = totalXP - currentLevelXP;
    const xpToNextLevel = nextLevelXP - totalXP;
    return {
        level: userLevel.level,
        currentXP: Math.max(0, currentXP),
        xpToNextLevel: Math.max(0, xpToNextLevel),
        totalXP,
        title: userLevel.title
    };
}
function addXP(currentTotalXP, xpGain) {
    const oldLevel = calculateLevel(currentTotalXP);
    const newTotalXP = currentTotalXP + xpGain;
    const newLevel = calculateLevel(newTotalXP);
    return {
        oldLevel,
        newLevel,
        levelUp: newLevel.level > oldLevel.level,
        xpGained: xpGain
    };
}
function getLevelInfo(level) {
    // Import React icons locally if needed or use emoji
    const levelData = LEVEL_THRESHOLDS.find((l)=>l.level === level) || LEVEL_THRESHOLDS[0];
    // Define icon classes based on level for now, can be improved with actual React icons
    let iconClass = 'User';
    let bgColor = 'bg-gray-100';
    let color = 'text-gray-600';
    if (level >= 15) {
        iconClass = 'Crown';
        bgColor = 'bg-purple-100';
        color = 'text-purple-600';
    } else if (level >= 12) {
        iconClass = 'Trophy';
        bgColor = 'bg-yellow-100';
        color = 'text-yellow-600';
    } else if (level >= 10) {
        iconClass = 'Award';
        bgColor = 'bg-orange-100';
        color = 'text-orange-600';
    } else if (level >= 8) {
        iconClass = 'Star';
        bgColor = 'bg-red-100';
        color = 'text-red-600';
    } else if (level >= 6) {
        iconClass = 'Target';
        bgColor = 'bg-blue-100';
        color = 'text-blue-600';
    } else if (level >= 4) {
        iconClass = 'BookOpen';
        bgColor = 'bg-green-100';
        color = 'text-green-600';
    } else if (level >= 2) {
        iconClass = 'Zap';
        bgColor = 'bg-yellow-100';
        color = 'text-yellow-600';
    }
    return {
        level,
        name: levelData.title,
        icon: iconClass,
        bgColor,
        color
    };
}
function getXPProgress(totalXP) {
    const userLevel = calculateLevel(totalXP);
    const current = userLevel.currentXP;
    const required = current + userLevel.xpToNextLevel;
    const percentage = required > 0 ? current / required * 100 : 100;
    return {
        current,
        required,
        percentage
    };
}
function getLevelColor(level) {
    if (level >= 15) return 'from-purple-600 to-pink-600'; // Siêu phàm
    if (level >= 12) return 'from-purple-500 to-indigo-600'; // Huyền thoại+
    if (level >= 10) return 'from-yellow-500 to-orange-500'; // Đại sư+
    if (level >= 8) return 'from-red-500 to-pink-500'; // Cao thủ+
    if (level >= 6) return 'from-blue-500 to-purple-500'; // Chuyên gia+
    if (level >= 4) return 'from-green-500 to-blue-500'; // Học sinh giỏi+
    if (level >= 2) return 'from-yellow-400 to-green-500'; // Học viên+
    return 'from-gray-400 to-blue-400'; // Người mới
}
function getLevelIcon(level) {
    if (level >= 15) return '👑'; // Siêu phàm
    if (level >= 12) return '🏆'; // Huyền thoại+
    if (level >= 10) return '🥇'; // Đại sư+
    if (level >= 8) return '🥈'; // Cao thủ+
    if (level >= 6) return '🥉'; // Chuyên gia+
    if (level >= 4) return '🎖️'; // Học sinh giỏi+
    if (level >= 2) return '🏅'; // Học viên+
    return '🌟'; // Người mới
}
function getProgressText(userLevel) {
    if (userLevel.xpToNextLevel === 0) {
        return 'Cấp độ tối đa!';
    }
    return "".concat(userLevel.currentXP, " / ").concat(userLevel.currentXP + userLevel.xpToNextLevel, " XP");
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/dashboard/userProgressService.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getUserProgress",
    ()=>getUserProgress,
    "getWeeklyStats",
    ()=>getWeeklyStats,
    "updateDailyGoal",
    ()=>updateDailyGoal,
    "updateTodayProgress",
    ()=>updateTodayProgress,
    "updateXP",
    ()=>updateXP
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
;
;
async function withTimeout(promise, ms) {
    let timer;
    try {
        const value = await Promise.race([
            promise,
            new Promise((resolve)=>{
                timer = setTimeout(()=>resolve('___timeout___'), ms);
            })
        ]);
        if (value === '___timeout___') {
            return {
                ok: false,
                reason: 'timeout'
            };
        }
        return {
            ok: true,
            value
        };
    } finally{
        if (timer) clearTimeout(timer);
    }
}
async function getUserProgress(userId) {
    try {
        // Timeout wrapper for Firestore operations
        const progressRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'user_progress', userId);
        const progressResult = await withTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(progressRef), 8000);
        if (!progressResult.ok) {
            // Graceful fallback on timeout
            return {
                id: userId,
                userId,
                todayProgress: 0,
                dailyGoal: 20,
                totalWordsLearned: 0,
                streak: 0,
                level: 1,
                xp: 0,
                lastActiveDate: new Date().toISOString().split('T')[0],
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
        }
        const progressSnap = progressResult.value;
        if (progressSnap.exists()) {
            return progressSnap.data();
        } else {
            // Tạo progress mới
            const newProgress = {
                id: userId,
                userId,
                todayProgress: 0,
                dailyGoal: 20,
                totalWordsLearned: 0,
                streak: 0,
                level: 1,
                xp: 0,
                lastActiveDate: new Date().toISOString().split('T')[0],
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            const createResult = await withTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(progressRef, newProgress), 8000);
            if (!createResult.ok) {
                // Still return newly created default in memory; backend will catch up later
                return newProgress;
            }
            return newProgress;
        }
    } catch (error) {
        console.error('Error getting user progress:', error);
        // Return default values on network error instead of throwing
        if (error.message === 'Operation timeout' || error.code === 'unavailable') {
            return {
                id: userId,
                userId,
                todayProgress: 0,
                dailyGoal: 20,
                totalWordsLearned: 0,
                streak: 0,
                level: 1,
                xp: 0,
                lastActiveDate: new Date().toISOString().split('T')[0],
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
        }
        throw error;
    }
}
async function updateTodayProgress(userId, wordsLearned) {
    let studyTimeMinutes = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0;
    try {
        const progressRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'user_progress', userId);
        const today = new Date().toISOString().split('T')[0];
        // Lấy progress hiện tại
        const currentProgress = await getUserProgress(userId);
        // Kiểm tra nếu là ngày mới
        const isNewDay = currentProgress.lastActiveDate !== today;
        if (isNewDay) {
            // Reset progress hôm nay và cập nhật streak
            const newStreak = currentProgress.lastActiveDate === new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0] ? currentProgress.streak + 1 : 1;
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(progressRef, {
                todayProgress: wordsLearned,
                totalWordsLearned: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["increment"])(wordsLearned),
                streak: newStreak,
                lastActiveDate: today,
                updatedAt: new Date().toISOString()
            });
        } else {
            // Cập nhật progress hiện tại
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(progressRef, {
                todayProgress: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["increment"])(wordsLearned),
                totalWordsLearned: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["increment"])(wordsLearned),
                updatedAt: new Date().toISOString()
            });
        }
        // Lưu daily stats
        await saveDailyStats(userId, today, wordsLearned, studyTimeMinutes);
        return await getUserProgress(userId);
    } catch (error) {
        console.error('Error updating today progress:', error);
        throw error;
    }
}
// Lưu daily stats
async function saveDailyStats(userId, date, wordsLearned, studyTimeMinutes) {
    try {
        const statsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'daily_stats', "".concat(userId, "_").concat(date));
        const statsSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(statsRef);
        if (statsSnap.exists()) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(statsRef, {
                wordsLearned: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["increment"])(wordsLearned),
                studyTime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["increment"])(studyTimeMinutes),
                updatedAt: new Date().toISOString()
            });
        } else {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(statsRef, {
                userId,
                date,
                wordsLearned,
                studyTime: studyTimeMinutes,
                missionsCompleted: 0,
                xpEarned: 0,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            });
        }
    } catch (error) {
        console.error('Error saving daily stats:', error);
        throw error;
    }
}
async function updateXP(userId, xpEarned) {
    try {
        const progressRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'user_progress', userId);
        const currentProgress = await getUserProgress(userId);
        const newXP = currentProgress.xp + xpEarned;
        const newLevel = Math.floor(newXP / 100) + 1; // Mỗi 100 XP = 1 level
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(progressRef, {
            xp: newXP,
            level: newLevel,
            updatedAt: new Date().toISOString()
        });
        return await getUserProgress(userId);
    } catch (error) {
        console.error('Error updating XP:', error);
        throw error;
    }
}
async function getWeeklyStats(userId) {
    try {
        const today = new Date();
        const weekStart = new Date(today.setDate(today.getDate() - today.getDay()));
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekEnd.getDate() + 6);
        const statsQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'daily_stats'), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('date', '>=', weekStart.toISOString().split('T')[0]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('date', '<=', weekEnd.toISOString().split('T')[0]));
        const statsResult = await withTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(statsQuery), 8000);
        if (!statsResult.ok) {
            // Graceful default on timeout
            return {
                weekStart: weekStart.toISOString().split('T')[0],
                weekEnd: weekEnd.toISOString().split('T')[0],
                totalWords: 0,
                totalStudyTime: 0,
                totalMissions: 0,
                totalXP: 0,
                averageDailyWords: 0
            };
        }
        const statsSnap = statsResult.value;
        let totalWords = 0;
        let totalStudyTime = 0;
        let totalMissions = 0;
        let totalXP = 0;
        let dayCount = 0;
        statsSnap.forEach((doc)=>{
            const data = doc.data();
            totalWords += data.wordsLearned || 0;
            totalStudyTime += data.studyTime || 0;
            totalMissions += data.missionsCompleted || 0;
            totalXP += data.xpEarned || 0;
            dayCount++;
        });
        return {
            weekStart: weekStart.toISOString().split('T')[0],
            weekEnd: weekEnd.toISOString().split('T')[0],
            totalWords,
            totalStudyTime,
            totalMissions,
            totalXP,
            averageDailyWords: dayCount > 0 ? Math.round(totalWords / dayCount) : 0
        };
    } catch (error) {
        console.error('Error getting weekly stats:', error);
        // Return default stats on network error
        if (error.message === 'Operation timeout' || error.code === 'unavailable') {
            const today = new Date();
            const weekStart = new Date(today.setDate(today.getDate() - today.getDay()));
            const weekEnd = new Date(weekStart);
            weekEnd.setDate(weekEnd.getDate() + 6);
            return {
                weekStart: weekStart.toISOString().split('T')[0],
                weekEnd: weekEnd.toISOString().split('T')[0],
                totalWords: 0,
                totalStudyTime: 0,
                totalMissions: 0,
                totalXP: 0,
                averageDailyWords: 0
            };
        }
        throw error;
    }
}
async function updateDailyGoal(userId, newGoal) {
    try {
        const progressRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'user_progress', userId);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(progressRef, {
            dailyGoal: newGoal,
            updatedAt: new Date().toISOString()
        });
        return await getUserProgress(userId);
    } catch (error) {
        console.error('Error updating daily goal:', error);
        throw error;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/dashboard/missionsService.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "completeMission",
    ()=>completeMission,
    "completeMissionByType",
    ()=>completeMissionByType,
    "getDailyMissions",
    ()=>getDailyMissions,
    "getMissionsHistory",
    ()=>getMissionsHistory,
    "getMissionsStats",
    ()=>getMissionsStats,
    "resetDailyMissions",
    ()=>resetDailyMissions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
;
;
// Mission templates
const MISSION_TEMPLATES = [
    {
        text: 'Ôn tập 5 từ vựng đã học',
        xp: 10,
        type: 'review'
    },
    {
        text: 'Làm quiz kiểm tra nhanh',
        xp: 15,
        type: 'quiz'
    },
    {
        text: 'Thử thách 5 phút',
        xp: 8,
        type: 'challenge'
    },
    {
        text: 'Hoàn thành 1 Pomodoro',
        xp: 20,
        type: 'pomodoro'
    },
    {
        text: 'Cập nhật thói quen học tập',
        xp: 12,
        type: 'habit'
    }
];
async function getDailyMissions(userId) {
    try {
        const today = new Date().toISOString().split('T')[0];
        const missionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'daily_missions', "".concat(userId, "_").concat(today));
        const timeoutPromise = new Promise((_, reject)=>{
            setTimeout(()=>reject(new Error('Operation timeout')), 10000);
        });
        const missionsSnap = await Promise.race([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(missionsRef),
            timeoutPromise
        ]);
        if (missionsSnap.exists()) {
            return missionsSnap.data();
        } else {
            // Tạo missions mới cho ngày hôm nay
            const newMissions = MISSION_TEMPLATES.map((template, index)=>({
                    id: "".concat(today, "_").concat(index + 1),
                    ...template,
                    completed: false
                }));
            const dailyMissions = {
                id: "".concat(userId, "_").concat(today),
                userId,
                date: today,
                missions: newMissions,
                completedCount: 0,
                totalXP: 0,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            await Promise.race([
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(missionsRef, dailyMissions),
                timeoutPromise
            ]);
            return dailyMissions;
        }
    } catch (error) {
        console.error('Error getting daily missions:', error);
        // Return default missions on network error
        if (error.message === 'Operation timeout' || error.code === 'unavailable') {
            const today = new Date().toISOString().split('T')[0];
            return {
                id: "".concat(userId, "_").concat(today),
                userId,
                date: today,
                missions: [],
                completedCount: 0,
                totalXP: 0,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
        }
        throw error;
    }
}
async function completeMission(userId, missionId) {
    try {
        const today = new Date().toISOString().split('T')[0];
        const missionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'daily_missions', "".concat(userId, "_").concat(today));
        const currentMissions = await getDailyMissions(userId);
        const missionIndex = currentMissions.missions.findIndex((m)=>m.id === missionId);
        if (missionIndex === -1) {
            throw new Error('Mission not found');
        }
        const mission = currentMissions.missions[missionIndex];
        if (mission.completed) {
            return {
                missions: currentMissions,
                success: false,
                xpEarned: 0,
                message: 'Mission already completed',
                completedMissions: currentMissions.missions.filter((m)=>m.completed).length,
                totalXP: currentMissions.missions.filter((m)=>m.completed).reduce((sum, m)=>sum + m.xp, 0)
            };
        }
        // Cập nhật mission
        const updatedMissions = [
            ...currentMissions.missions
        ];
        updatedMissions[missionIndex] = {
            ...mission,
            completed: true,
            completedAt: new Date().toISOString()
        };
        const completedCount = updatedMissions.filter((m)=>m.completed).length;
        const totalXP = updatedMissions.filter((m)=>m.completed).reduce((sum, m)=>sum + m.xp, 0);
        const timeoutPromise = new Promise((_, reject)=>{
            setTimeout(()=>reject(new Error('Operation timeout')), 10000);
        });
        const updatePromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(missionsRef, {
            missions: updatedMissions,
            completedCount,
            totalXP,
            updatedAt: new Date().toISOString()
        });
        await Promise.race([
            updatePromise,
            timeoutPromise
        ]);
        return {
            missions: {
                ...currentMissions,
                missions: updatedMissions,
                completedCount,
                totalXP
            },
            xpEarned: mission.xp
        };
    } catch (error) {
        console.error('Error completing mission:', error);
        throw error;
    }
}
async function completeMissionByType(userId, type) {
    try {
        const currentMissions = await getDailyMissions(userId);
        const mission = currentMissions.missions.find((m)=>m.type === type && !m.completed);
        if (!mission) {
            return null; // Không có mission nào của type này chưa hoàn thành
        }
        return await completeMission(userId, mission.id);
    } catch (error) {
        console.error('Error completing mission by type:', error);
        throw error;
    }
}
async function resetDailyMissions(userId) {
    try {
        const today = new Date().toISOString().split('T')[0];
        const missionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'daily_missions', "".concat(userId, "_").concat(today));
        const newMissions = MISSION_TEMPLATES.map((template, index)=>({
                id: "".concat(today, "_").concat(index + 1),
                ...template,
                completed: false
            }));
        const dailyMissions = {
            id: "".concat(userId, "_").concat(today),
            userId,
            date: today,
            missions: newMissions,
            completedCount: 0,
            totalXP: 0,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(missionsRef, dailyMissions);
        return dailyMissions;
    } catch (error) {
        console.error('Error resetting daily missions:', error);
        throw error;
    }
}
async function getMissionsHistory(userId) {
    let days = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 7;
    try {
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);
        const missionsQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'daily_missions'), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('date', '>=', startDate.toISOString().split('T')[0]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('date', '<=', endDate.toISOString().split('T')[0]));
        const missionsSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(missionsQuery);
        const missions = [];
        missionsSnap.forEach((doc)=>{
            missions.push(doc.data());
        });
        return missions.sort((a, b)=>b.date.localeCompare(a.date));
    } catch (error) {
        console.error('Error getting missions history:', error);
        throw error;
    }
}
async function getMissionsStats(userId) {
    try {
        const history = await getMissionsHistory(userId, 30);
        let totalCompleted = 0;
        let totalXP = 0;
        let totalPossible = 0;
        let currentStreak = 0;
        let maxStreak = 0;
        // Tính toán từ ngày gần nhất
        const today = new Date().toISOString().split('T')[0];
        let currentDate = new Date(today);
        for(let i = 0; i < 30; i++){
            const dateStr = currentDate.toISOString().split('T')[0];
            const dayMissions = history.find((h)=>h.date === dateStr);
            if (dayMissions) {
                totalCompleted += dayMissions.completedCount;
                totalXP += dayMissions.totalXP;
                totalPossible += dayMissions.missions.length;
                if (dayMissions.completedCount === dayMissions.missions.length) {
                    currentStreak++;
                    maxStreak = Math.max(maxStreak, currentStreak);
                } else {
                    currentStreak = 0;
                }
            } else {
                currentStreak = 0;
            }
            currentDate.setDate(currentDate.getDate() - 1);
        }
        return {
            totalCompleted,
            totalXP,
            averageCompletion: totalPossible > 0 ? Math.round(totalCompleted / totalPossible * 100) : 0,
            streak: maxStreak
        };
    } catch (error) {
        console.error('Error getting missions stats:', error);
        throw error;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/dashboard/achievementsService.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAchievementStats",
    ()=>getAchievementStats,
    "getUnlockedAchievements",
    ()=>getUnlockedAchievements,
    "getUpcomingAchievements",
    ()=>getUpcomingAchievements,
    "getUserAchievements",
    ()=>getUserAchievements,
    "initializeUserAchievements",
    ()=>initializeUserAchievements,
    "updateAchievementProgress",
    ()=>updateAchievementProgress
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
;
;
// Achievement templates
const ACHIEVEMENT_TEMPLATES = [
    // Words achievements
    {
        title: 'Học 10 từ',
        description: 'Học được 10 từ vựng đầu tiên',
        icon: '📚',
        category: 'words',
        requirement: 10,
        xpReward: 50,
        rarity: 'common'
    },
    {
        title: 'Học 50 từ',
        description: 'Học được 50 từ vựng',
        icon: '📖',
        category: 'words',
        requirement: 50,
        xpReward: 100,
        rarity: 'common'
    },
    {
        title: 'Học 100 từ',
        description: 'Học được 100 từ vựng',
        icon: '📚',
        category: 'words',
        requirement: 100,
        xpReward: 200,
        rarity: 'rare'
    },
    {
        title: 'Học 500 từ',
        description: 'Học được 500 từ vựng',
        icon: '📚',
        category: 'words',
        requirement: 500,
        xpReward: 500,
        rarity: 'epic'
    },
    {
        title: 'Học 1000 từ',
        description: 'Học được 1000 từ vựng',
        icon: '📚',
        category: 'words',
        requirement: 1000,
        xpReward: 1000,
        rarity: 'legendary'
    },
    // Streak achievements
    {
        title: 'Streak 3 ngày',
        description: 'Học liên tiếp 3 ngày',
        icon: '🔥',
        category: 'streak',
        requirement: 3,
        xpReward: 30,
        rarity: 'common'
    },
    {
        title: 'Streak 7 ngày',
        description: 'Học liên tiếp 7 ngày',
        icon: '🔥',
        category: 'streak',
        requirement: 7,
        xpReward: 100,
        rarity: 'rare'
    },
    {
        title: 'Streak 30 ngày',
        description: 'Học liên tiếp 30 ngày',
        icon: '🔥',
        category: 'streak',
        requirement: 30,
        xpReward: 500,
        rarity: 'epic'
    },
    {
        title: 'Streak 100 ngày',
        description: 'Học liên tiếp 100 ngày',
        icon: '🔥',
        category: 'streak',
        requirement: 100,
        xpReward: 1000,
        rarity: 'legendary'
    },
    // Pomodoro achievements
    {
        title: '5 Pomodoro',
        description: 'Hoàn thành 5 phiên Pomodoro',
        icon: '🍅',
        category: 'pomodoro',
        requirement: 5,
        xpReward: 50,
        rarity: 'common'
    },
    {
        title: '10 Pomodoro',
        description: 'Hoàn thành 10 phiên Pomodoro',
        icon: '🍅',
        category: 'pomodoro',
        requirement: 10,
        xpReward: 100,
        rarity: 'rare'
    },
    {
        title: '50 Pomodoro',
        description: 'Hoàn thành 50 phiên Pomodoro',
        icon: '🍅',
        category: 'pomodoro',
        requirement: 50,
        xpReward: 300,
        rarity: 'epic'
    },
    {
        title: '100 Pomodoro',
        description: 'Hoàn thành 100 phiên Pomodoro',
        icon: '🍅',
        category: 'pomodoro',
        requirement: 100,
        xpReward: 500,
        rarity: 'legendary'
    },
    // Level achievements
    {
        title: 'Level 5',
        description: 'Đạt level 5',
        icon: '⭐',
        category: 'level',
        requirement: 5,
        xpReward: 100,
        rarity: 'common'
    },
    {
        title: 'Level 10',
        description: 'Đạt level 10',
        icon: '⭐',
        category: 'level',
        requirement: 10,
        xpReward: 200,
        rarity: 'rare'
    },
    {
        title: 'Level 25',
        description: 'Đạt level 25',
        icon: '⭐',
        category: 'level',
        requirement: 25,
        xpReward: 500,
        rarity: 'epic'
    },
    {
        title: 'Level 50',
        description: 'Đạt level 50',
        icon: '⭐',
        category: 'level',
        requirement: 50,
        xpReward: 1000,
        rarity: 'legendary'
    },
    // Missions achievements
    {
        title: 'Hoàn thành 10 nhiệm vụ',
        description: 'Hoàn thành 10 nhiệm vụ hàng ngày',
        icon: '🎯',
        category: 'missions',
        requirement: 10,
        xpReward: 100,
        rarity: 'common'
    },
    {
        title: 'Hoàn thành 50 nhiệm vụ',
        description: 'Hoàn thành 50 nhiệm vụ hàng ngày',
        icon: '🎯',
        category: 'missions',
        requirement: 50,
        xpReward: 300,
        rarity: 'rare'
    },
    {
        title: 'Hoàn thành 100 nhiệm vụ',
        description: 'Hoàn thành 100 nhiệm vụ hàng ngày',
        icon: '🎯',
        category: 'missions',
        requirement: 100,
        xpReward: 500,
        rarity: 'epic'
    },
    {
        title: 'Hoàn thành 500 nhiệm vụ',
        description: 'Hoàn thành 500 nhiệm vụ hàng ngày',
        icon: '🎯',
        category: 'missions',
        requirement: 500,
        xpReward: 1000,
        rarity: 'legendary'
    },
    // Time achievements
    {
        title: 'Học 1 giờ',
        description: 'Tổng thời gian học 1 giờ',
        icon: '⏰',
        category: 'time',
        requirement: 60,
        xpReward: 50,
        rarity: 'common'
    },
    {
        title: 'Học 10 giờ',
        description: 'Tổng thời gian học 10 giờ',
        icon: '⏰',
        category: 'time',
        requirement: 600,
        xpReward: 200,
        rarity: 'rare'
    },
    {
        title: 'Học 50 giờ',
        description: 'Tổng thời gian học 50 giờ',
        icon: '⏰',
        category: 'time',
        requirement: 3000,
        xpReward: 500,
        rarity: 'epic'
    },
    {
        title: 'Học 100 giờ',
        description: 'Tổng thời gian học 100 giờ',
        icon: '⏰',
        category: 'time',
        requirement: 6000,
        xpReward: 1000,
        rarity: 'legendary'
    }
];
async function initializeUserAchievements(userId) {
    try {
        const userAchievements = [];
        for (const template of ACHIEVEMENT_TEMPLATES){
            const achievementId = template.title.toLowerCase().replace(/\s+/g, '_');
            const userAchievementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'user_achievements', "".concat(userId, "_").concat(achievementId));
            const userAchievement = {
                id: "".concat(userId, "_").concat(achievementId),
                userId,
                achievementId,
                unlocked: false,
                progress: 0,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(userAchievementRef, userAchievement);
            userAchievements.push(userAchievement);
        }
        return userAchievements;
    } catch (error) {
        console.error('Error initializing user achievements:', error);
        throw error;
    }
}
async function getUserAchievements(userId) {
    try {
        const achievements = [];
        for (const template of ACHIEVEMENT_TEMPLATES){
            const achievementId = template.title.toLowerCase().replace(/\s+/g, '_');
            const userAchievementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'user_achievements', "".concat(userId, "_").concat(achievementId));
            const userAchievementSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(userAchievementRef);
            if (userAchievementSnap.exists()) {
                const userAchievement = userAchievementSnap.data();
                achievements.push({
                    id: achievementId,
                    ...template,
                    unlocked: userAchievement.unlocked,
                    unlockedAt: userAchievement.unlockedAt,
                    progress: userAchievement.progress
                });
            } else {
                // Tạo mới nếu chưa có
                const userAchievement = {
                    id: "".concat(userId, "_").concat(achievementId),
                    userId,
                    achievementId,
                    unlocked: false,
                    progress: 0,
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                };
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(userAchievementRef, userAchievement);
                achievements.push({
                    id: achievementId,
                    ...template,
                    unlocked: false,
                    progress: 0
                });
            }
        }
        return achievements;
    } catch (error) {
        console.error('Error getting user achievements:', error);
        throw error;
    }
}
async function updateAchievementProgress(userId, category, progressIncrement) {
    try {
        const achievements = await getUserAchievements(userId);
        const categoryAchievements = achievements.filter((a)=>a.category === category);
        const unlockedAchievements = [];
        let totalXPEarned = 0;
        for (const achievement of categoryAchievements){
            if (achievement.unlocked) continue;
            const achievementId = achievement.id;
            const userAchievementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'user_achievements', "".concat(userId, "_").concat(achievementId));
            const newProgress = achievement.progress + progressIncrement;
            const shouldUnlock = newProgress >= achievement.requirement;
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(userAchievementRef, {
                progress: newProgress,
                unlocked: shouldUnlock,
                unlockedAt: shouldUnlock ? new Date().toISOString() : undefined,
                updatedAt: new Date().toISOString()
            });
            if (shouldUnlock) {
                unlockedAchievements.push({
                    ...achievement,
                    unlocked: true,
                    unlockedAt: new Date().toISOString(),
                    progress: newProgress
                });
                totalXPEarned += achievement.xpReward;
            }
        }
        return {
            unlockedAchievements,
            totalXPEarned
        };
    } catch (error) {
        console.error('Error updating achievement progress:', error);
        throw error;
    }
}
async function getUpcomingAchievements(userId) {
    let limit = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 4;
    try {
        const achievements = await getUserAchievements(userId);
        const upcomingAchievements = achievements.filter((a)=>!a.unlocked && a.progress > 0).sort((a, b)=>{
            const aRemaining = a.requirement - a.progress;
            const bRemaining = b.requirement - b.progress;
            return aRemaining - bRemaining;
        }).slice(0, limit);
        return upcomingAchievements;
    } catch (error) {
        console.error('Error getting upcoming achievements:', error);
        // Return empty array on network error
        if (error.message === 'Operation timeout' || error.code === 'unavailable') {
            return [];
        }
        throw error;
    }
}
async function getUnlockedAchievements(userId) {
    try {
        const achievements = await getUserAchievements(userId);
        return achievements.filter((a)=>a.unlocked);
    } catch (error) {
        console.error('Error getting unlocked achievements:', error);
        throw error;
    }
}
async function getAchievementStats(userId) {
    try {
        const achievements = await getUserAchievements(userId);
        const unlockedAchievements = achievements.filter((a)=>a.unlocked);
        const stats = {
            totalUnlocked: unlockedAchievements.length,
            totalXP: unlockedAchievements.reduce((sum, a)=>sum + a.xpReward, 0),
            byRarity: {
                common: 0,
                rare: 0,
                epic: 0,
                legendary: 0
            },
            byCategory: {
                words: 0,
                streak: 0,
                pomodoro: 0,
                level: 0,
                missions: 0,
                time: 0
            }
        };
        unlockedAchievements.forEach((achievement)=>{
            stats.byRarity[achievement.rarity]++;
            stats.byCategory[achievement.category]++;
        });
        return stats;
    } catch (error) {
        console.error('Error getting achievement stats:', error);
        throw error;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/dashboard/integrationService.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getIntegratedProgress",
    ()=>getIntegratedProgress,
    "resetWeeklyHabits",
    ()=>resetWeeklyHabits,
    "updateFlashcardProgress",
    ()=>updateFlashcardProgress,
    "updateHabitProgress",
    ()=>updateHabitProgress,
    "updatePomodoroProgress",
    ()=>updatePomodoroProgress
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/dashboard/userProgressService.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$missionsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/dashboard/missionsService.ts [client] (ecmascript)");
;
;
;
;
async function updateFlashcardProgress(userId, wordsLearned) {
    let studyTimeMinutes = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0;
    try {
        // Cập nhật progress tổng thể và stats flashcard
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updateTodayProgress"])(userId, wordsLearned, studyTimeMinutes);
        await updateFlashcardStats(userId, wordsLearned, studyTimeMinutes);
        // Chỉ cộng XP khi thực sự học từ vựng (dựa trên số từ)
        const perWordXP = 5; // đồng bộ với XP_ACTIONS.COMPLETE_FLASHCARD
        const earned = Math.max(0, Math.floor(wordsLearned) * perWordXP);
        if (earned > 0) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updateXP"])(userId, earned);
        // Gây sát thương lên Boss tương ứng XP kiếm được
        // Boss attack removed
        }
        // Không cộng XP thêm từ mission để tránh cộng chồng
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$missionsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["completeMissionByType"])(userId, 'review');
        return {
            success: true,
            xpEarned: earned,
            progressUpdated: true,
            message: "Đã học ".concat(wordsLearned, " từ vựng mới! +").concat(earned, " XP")
        };
    } catch (error) {
        console.error('Error updating flashcard progress:', error);
        return {
            success: false,
            xpEarned: 0,
            progressUpdated: false,
            message: 'Có lỗi khi cập nhật tiến độ flashcard'
        };
    }
}
async function updatePomodoroProgress(userId) {
    let pomodorosCompleted = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1, focusTimeMinutes = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 25;
    try {
        // Cập nhật stats pomodoro
        await updatePomodoroStats(userId, pomodorosCompleted, focusTimeMinutes);
        // Cộng XP dựa trên số pomodoro (hành động thực tế)
        const pomodoroXP = Math.max(0, Math.floor(pomodorosCompleted) * 20);
        if (pomodoroXP > 0) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updateXP"])(userId, pomodoroXP);
        // Boss attack removed
        }
        // Hoàn thành mission nhưng không cộng thêm XP từ mission
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$missionsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["completeMissionByType"])(userId, 'pomodoro');
        return {
            success: true,
            xpEarned: pomodoroXP,
            progressUpdated: true,
            message: "Hoàn thành ".concat(pomodorosCompleted, " Pomodoro! +").concat(pomodoroXP, " XP")
        };
    } catch (error) {
        console.error('Error updating pomodoro progress:', error);
        return {
            success: false,
            xpEarned: 0,
            progressUpdated: false,
            message: 'Có lỗi khi cập nhật tiến độ Pomodoro'
        };
    }
}
async function updateHabitProgress(userId, habitId, completed) {
    try {
        // Cập nhật habit completion
        await updateHabitCompletion(userId, habitId, completed);
        // Cộng XP chỉ khi đánh dấu hoàn thành
        const habitXP = completed ? 10 : 0;
        if (habitXP > 0) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updateXP"])(userId, habitXP);
        // Boss attack removed
        }
        // Hoàn thành mission nhưng không cộng XP từ mission
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$missionsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["completeMissionByType"])(userId, 'habit');
        return {
            success: true,
            xpEarned: habitXP,
            progressUpdated: true,
            message: completed ? "Hoàn thành thói quen! +".concat(habitXP, " XP") : "Đã bỏ đánh dấu thói quen"
        };
    } catch (error) {
        console.error('Error updating habit progress:', error);
        return {
            success: false,
            xpEarned: 0,
            progressUpdated: false,
            message: 'Có lỗi khi cập nhật tiến độ thói quen'
        };
    }
}
async function getIntegratedProgress(userId) {
    try {
        const [userProgress, flashcardStats, pomodoroStats, habitStats] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getUserProgress"])(userId),
            getFlashcardStats(userId),
            getPomodoroStats(userId),
            getHabitStats(userId)
        ]);
        return {
            wordsLearnedToday: flashcardStats.wordsLearnedToday,
            totalWordsLearned: userProgress.totalWordsLearned,
            flashcardsCompleted: flashcardStats.flashcardsCompleted,
            pomodorosCompletedToday: pomodoroStats.pomodorosCompletedToday,
            totalFocusTimeMinutes: pomodoroStats.totalFocusTimeMinutes,
            currentStreak: userProgress.streak,
            habitsCompletedToday: habitStats.habitsCompletedToday,
            totalHabits: habitStats.totalHabits,
            weeklyHabitProgress: habitStats.weeklyHabitProgress,
            dailyGoal: userProgress.dailyGoal,
            dailyProgress: userProgress.todayProgress,
            level: userProgress.level,
            xp: userProgress.xp,
            streak: userProgress.streak
        };
    } catch (error) {
        console.error('Error getting integrated progress:', error);
        // Return default values
        return {
            wordsLearnedToday: 0,
            totalWordsLearned: 0,
            flashcardsCompleted: 0,
            pomodorosCompletedToday: 0,
            totalFocusTimeMinutes: 0,
            currentStreak: 0,
            habitsCompletedToday: 0,
            totalHabits: 0,
            weeklyHabitProgress: 0,
            dailyGoal: 20,
            dailyProgress: 0,
            level: 1,
            xp: 0,
            streak: 0
        };
    }
}
async function resetWeeklyHabits(userId) {
    try {
        var _lastResetSnap_data;
        const today = new Date();
        const startOfWeek = new Date(today);
        startOfWeek.setDate(today.getDate() - today.getDay() + 1); // Monday
        startOfWeek.setHours(0, 0, 0, 0);
        // Kiểm tra nếu đã reset tuần này chưa
        const lastResetRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habit_resets', userId);
        const lastResetSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(lastResetRef);
        const lastResetDate = lastResetSnap.exists() ? new Date(((_lastResetSnap_data = lastResetSnap.data()) === null || _lastResetSnap_data === void 0 ? void 0 : _lastResetSnap_data.lastResetDate) || 0) : new Date(0);
        if (lastResetDate < startOfWeek) {
            // Reset habits cho tuần mới
            await resetHabitsForWeek(userId);
            // Cập nhật ngày reset cuối
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(lastResetRef, {
                userId,
                lastResetDate: startOfWeek.toISOString(),
                createdAt: new Date().toISOString()
            });
        }
    } catch (error) {
        console.error('Error resetting weekly habits:', error);
    }
}
// Helper functions
async function updateFlashcardStats(userId, wordsLearned, studyTimeMinutes) {
    const today = new Date().toISOString().split('T')[0];
    const statsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'flashcard_stats', "".concat(userId, "_").concat(today));
    const statsSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(statsRef);
    if (statsSnap.exists()) {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(statsRef, {
            wordsLearned: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["increment"])(wordsLearned),
            studyTime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["increment"])(studyTimeMinutes),
            flashcardsCompleted: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["increment"])(1),
            updatedAt: new Date().toISOString()
        });
    } else {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(statsRef, {
            userId,
            date: today,
            wordsLearned,
            studyTime: studyTimeMinutes,
            flashcardsCompleted: 1,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        });
    }
}
async function updatePomodoroStats(userId, pomodorosCompleted, focusTimeMinutes) {
    const today = new Date().toISOString().split('T')[0];
    const statsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'pomodoro_stats', "".concat(userId, "_").concat(today));
    const statsSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(statsRef);
    if (statsSnap.exists()) {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(statsRef, {
            pomodorosCompleted: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["increment"])(pomodorosCompleted),
            focusTime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["increment"])(focusTimeMinutes),
            updatedAt: new Date().toISOString()
        });
    } else {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(statsRef, {
            userId,
            date: today,
            pomodorosCompleted,
            focusTime: focusTimeMinutes,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        });
    }
}
async function updateHabitCompletion(userId, habitId, completed) {
    const today = new Date().toISOString().split('T')[0];
    const completionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habit_completions', "".concat(userId, "_").concat(habitId, "_").concat(today));
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(completionRef, {
        userId,
        habitId,
        date: today,
        completed,
        completedAt: completed ? new Date().toISOString() : null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    });
}
async function getFlashcardStats(userId) {
    const today = new Date().toISOString().split('T')[0];
    const statsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'flashcard_stats', "".concat(userId, "_").concat(today));
    const statsSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(statsRef);
    if (statsSnap.exists()) {
        const data = statsSnap.data();
        return {
            wordsLearnedToday: data.wordsLearned || 0,
            flashcardsCompleted: data.flashcardsCompleted || 0
        };
    }
    return {
        wordsLearnedToday: 0,
        flashcardsCompleted: 0
    };
}
async function getPomodoroStats(userId) {
    const today = new Date().toISOString().split('T')[0];
    const statsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'pomodoro_stats', "".concat(userId, "_").concat(today));
    const statsSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(statsRef);
    if (statsSnap.exists()) {
        const data = statsSnap.data();
        return {
            pomodorosCompletedToday: data.pomodorosCompleted || 0,
            totalFocusTimeMinutes: data.focusTime || 0
        };
    }
    return {
        pomodorosCompletedToday: 0,
        totalFocusTimeMinutes: 0
    };
}
async function getHabitStats(userId) {
    const today = new Date().toISOString().split('T')[0];
    // Lấy tất cả habits của user
    const habitsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habits');
    const habitsQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(habitsRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId));
    const habitsSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(habitsQuery);
    const totalHabits = habitsSnap.size;
    let habitsCompletedToday = 0;
    // Đếm habits hoàn thành hôm nay
    for (const habitDoc of habitsSnap.docs){
        var _completionSnap_data;
        const completionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habit_completions', "".concat(userId, "_").concat(habitDoc.id, "_").concat(today));
        const completionSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(completionRef);
        if (completionSnap.exists() && ((_completionSnap_data = completionSnap.data()) === null || _completionSnap_data === void 0 ? void 0 : _completionSnap_data.completed)) {
            habitsCompletedToday++;
        }
    }
    // Tính weekly progress (7 ngày gần nhất)
    const weeklyHabitProgress = await calculateWeeklyHabitProgress(userId);
    return {
        habitsCompletedToday,
        totalHabits,
        weeklyHabitProgress
    };
}
async function calculateWeeklyHabitProgress(userId) {
    const today = new Date();
    let totalProgress = 0;
    for(let i = 0; i < 7; i++){
        const date = new Date(today);
        date.setDate(today.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        // Lấy habits hoàn thành trong ngày này
        const habitsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habits');
        const habitsQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(habitsRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId));
        const habitsSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(habitsQuery);
        let dayProgress = 0;
        for (const habitDoc of habitsSnap.docs){
            var _completionSnap_data;
            const completionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habit_completions', "".concat(userId, "_").concat(habitDoc.id, "_").concat(dateStr));
            const completionSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(completionRef);
            if (completionSnap.exists() && ((_completionSnap_data = completionSnap.data()) === null || _completionSnap_data === void 0 ? void 0 : _completionSnap_data.completed)) {
                dayProgress++;
            }
        }
        totalProgress += dayProgress;
    }
    return totalProgress;
}
async function resetHabitsForWeek(userId) {
    // Reset weekly progress cho tất cả habits
    const habitsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habits');
    const habitsQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(habitsRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId));
    const habitsSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(habitsQuery);
    for (const habitDoc of habitsSnap.docs){
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habits', habitDoc.id), {
            weeklyProgress: [
                false,
                false,
                false,
                false,
                false,
                false,
                false
            ],
            updatedAt: new Date().toISOString()
        });
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/firebase/userMapping.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getEmailFromUsername",
    ()=>getEmailFromUsername,
    "saveUsernameMapping",
    ()=>saveUsernameMapping
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
;
;
async function saveUsernameMapping(username, email) {
    try {
        const timeoutPromise = new Promise((_, reject)=>{
            setTimeout(()=>reject(new Error('Operation timeout')), 10000);
        });
        const setPromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'username_mappings', username), {
            email: email,
            createdAt: new Date()
        });
        await Promise.race([
            setPromise,
            timeoutPromise
        ]);
    } catch (error) {
        console.error('Error saving username mapping:', error);
        throw error;
    }
}
async function getEmailFromUsername(username) {
    try {
        const docRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'username_mappings', username);
        const timeoutPromise = new Promise((_, reject)=>{
            setTimeout(()=>reject(new Error('Operation timeout')), 10000);
        });
        const getPromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(docRef);
        const docSnap = await Promise.race([
            getPromise,
            timeoutPromise
        ]);
        if (docSnap.exists()) {
            return docSnap.data().email;
        } else {
            return null;
        }
    } catch (error) {
        console.error('Error getting email from username:', error);
        throw error;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/firebase/auth.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loginWithEmail",
    ()=>loginWithEmail,
    "loginWithGoogle",
    ()=>loginWithGoogle,
    "logout",
    ()=>logout,
    "registerWithEmail",
    ()=>registerWithEmail,
    "resetPassword",
    ()=>resetPassword
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/auth/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/auth/dist/esm/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$userMapping$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/userMapping.ts [client] (ecmascript)");
;
;
;
async function registerWithEmail(email, password, username) {
    try {
        const userCredential = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createUserWithEmailAndPassword"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], email, password);
        // Cập nhật tên hiển thị với username
        if (userCredential.user) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateProfile"])(userCredential.user, {
                displayName: username
            });
            // Lưu mapping username -> email
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$userMapping$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["saveUsernameMapping"])(username, email);
        }
        return userCredential.user;
    } catch (error) {
        console.error('Error registering with email:', error);
        throw error;
    }
}
async function loginWithEmail(loginInput, password) {
    try {
        // Validate input
        if (!loginInput || !password) {
            throw new Error('auth/invalid-credential');
        }
        // Trim whitespace
        const trimmedInput = loginInput.trim();
        const trimmedPassword = password.trim();
        if (!trimmedInput || !trimmedPassword) {
            throw new Error('auth/invalid-credential');
        }
        // Kiểm tra xem input có phải là email không (chứa @)
        const isEmail = trimmedInput.includes('@');
        if (isEmail) {
            // Validate email format
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(trimmedInput)) {
                throw new Error('auth/invalid-email');
            }
            // Nếu là email, đăng nhập trực tiếp
            const userCredential = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["signInWithEmailAndPassword"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], trimmedInput, trimmedPassword);
            return userCredential.user;
        } else {
            // Validate username format
            if (trimmedInput.length < 3) {
                throw new Error('auth/invalid-credential');
            }
            // Nếu là username, tìm email tương ứng
            const email = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$userMapping$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getEmailFromUsername"])(trimmedInput);
            if (!email) {
                throw new Error('auth/user-not-found');
            }
            // Đăng nhập bằng email tìm được
            const userCredential = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["signInWithEmailAndPassword"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], email, trimmedPassword);
            return userCredential.user;
        }
    } catch (error) {
        console.error('Error logging in with email/username:', error);
        // Map Firebase error codes to user-friendly messages
        if (error.code === 'auth/invalid-credential') {
            throw new Error('auth/invalid-credential');
        } else if (error.code === 'auth/user-not-found') {
            throw new Error('auth/user-not-found');
        } else if (error.code === 'auth/wrong-password') {
            throw new Error('auth/invalid-credential');
        } else if (error.code === 'auth/invalid-email') {
            throw new Error('auth/invalid-email');
        } else if (error.code === 'auth/user-disabled') {
            throw new Error('auth/user-disabled');
        } else if (error.code === 'auth/too-many-requests') {
            throw new Error('auth/too-many-requests');
        } else {
            throw error;
        }
    }
}
async function loginWithGoogle() {
    try {
        const provider = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["GoogleAuthProvider"]();
        const userCredential = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["signInWithPopup"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], provider);
        return userCredential.user;
    } catch (error) {
        console.error('Error logging in with Google:', error);
        throw error;
    }
}
async function logout() {
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["signOut"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"]);
    } catch (error) {
        console.error('Error signing out:', error);
        throw error;
    }
}
async function resetPassword(email) {
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["sendPasswordResetEmail"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], email);
    } catch (error) {
        console.error('Error sending password reset email:', error);
        throw error;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_services_cfdd15dd._.js.map