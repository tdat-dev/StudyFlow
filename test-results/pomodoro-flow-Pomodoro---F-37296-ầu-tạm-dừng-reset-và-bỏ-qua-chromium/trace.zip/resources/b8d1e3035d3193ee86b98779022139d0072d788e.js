(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_37759e4c._.js",
  "static/chunks/node_modules_next_dist_shared_lib_2c2ec201._.js",
  "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm_a0b02df4._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm_a1d87665.js",
  "static/chunks/node_modules_21ad10d8._.js",
  "static/chunks/[root-of-the-server]__1253443a._.js",
  "static/chunks/_3ced5b62._.css"
],
    source: "entry"
});
