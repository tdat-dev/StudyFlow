(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/features/flashcards/SwipeableFlashcard.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SwipeableFlashcard",
    ()=>SwipeableFlashcard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [client] (ecmascript) <export default as X>");
;
var _s = __turbopack_context__.k.signature();
;
;
function SwipeableFlashcard(param) {
    let { front, back, example, exampleTranslation, onSwipeLeft, onSwipeRight, disabled = false } = param;
    _s();
    const [isFlipped, setIsFlipped] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [dragStartX, setDragStartX] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [dragOffset, setDragOffset] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [swipeIndicator, setSwipeIndicator] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const cardRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Reset card position when card changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SwipeableFlashcard.useEffect": ()=>{
            setIsFlipped(false);
            setDragOffset(0);
            setSwipeIndicator(null);
        }
    }["SwipeableFlashcard.useEffect"], [
        front,
        back
    ]);
    // Đảm bảo chỉ mặt đang hiển thị nhận tương tác chuột (tránh giật do hover chồng lớp)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SwipeableFlashcard.useEffect": ()=>{
            var _cardRef_current, _cardRef_current1;
            const frontEl = (_cardRef_current = cardRef.current) === null || _cardRef_current === void 0 ? void 0 : _cardRef_current.querySelector('.card-face-front');
            const backEl = (_cardRef_current1 = cardRef.current) === null || _cardRef_current1 === void 0 ? void 0 : _cardRef_current1.querySelector('.card-face-back');
            if (!frontEl || !backEl) return;
            if (isFlipped) {
                frontEl.style.pointerEvents = 'none';
                frontEl.setAttribute('aria-hidden', 'true');
                backEl.style.pointerEvents = 'auto';
                backEl.removeAttribute('aria-hidden');
            } else {
                backEl.style.pointerEvents = 'none';
                backEl.setAttribute('aria-hidden', 'true');
                frontEl.style.pointerEvents = 'auto';
                frontEl.removeAttribute('aria-hidden');
            }
        }
    }["SwipeableFlashcard.useEffect"], [
        isFlipped
    ]);
    const handleTouchStart = (e)=>{
        if (disabled) return;
        setDragStartX(e.touches[0].clientX);
    };
    const handleMouseDown = (e)=>{
        if (disabled) return;
        setDragStartX(e.clientX);
    };
    const handleTouchMove = (e)=>{
        if (disabled) return;
        if (dragStartX === null) return;
        const currentX = e.touches[0].clientX;
        const newOffset = currentX - dragStartX;
        updateDragPosition(newOffset);
    };
    const handleMouseMove = (e)=>{
        if (disabled) return;
        if (dragStartX === null) return;
        const currentX = e.clientX;
        const newOffset = currentX - dragStartX;
        updateDragPosition(newOffset);
    };
    const updateDragPosition = (offset)=>{
        // Limit the drag distance
        const maxDrag = 150;
        const limitedOffset = Math.max(Math.min(offset, maxDrag), -maxDrag);
        setDragOffset(limitedOffset);
        // Show swipe indicator based on drag direction and distance
        if (limitedOffset > 80) {
            setSwipeIndicator('right');
        } else if (limitedOffset < -80) {
            setSwipeIndicator('left');
        } else {
            setSwipeIndicator(null);
        }
    };
    const handleDragEnd = ()=>{
        if (disabled) return;
        if (dragStartX === null) return;
        // If dragged far enough, trigger the appropriate action
        if (dragOffset > 100) {
            onSwipeRight();
        } else if (dragOffset < -100) {
            onSwipeLeft();
        } else {
            // Reset position with animation
            setDragOffset(0);
        }
        setDragStartX(null);
        setSwipeIndicator(null);
    };
    const handleClick = ()=>{
        if (disabled) return;
        // Only flip if not dragging
        if (Math.abs(dragOffset) < 5) {
            setIsFlipped(!isFlipped);
        }
    };
    // Tạo lớp transform theo bậc để tránh inline style
    const dragClass = (()=>{
        if (dragOffset > 100) return 'translate-x-24 rotate-3 drop-shadow-lg';
        if (dragOffset > 60) return 'translate-x-16 rotate-2 drop-shadow';
        if (dragOffset > 20) return 'translate-x-8 rotate-1';
        if (dragOffset < -100) return '-translate-x-24 -rotate-3 drop-shadow-lg';
        if (dragOffset < -60) return '-translate-x-16 -rotate-2 drop-shadow';
        if (dragOffset < -20) return '-translate-x-8 -rotate-1';
        return 'translate-x-0 rotate-0';
    })();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative w-full max-w-sm md:max-w-md lg:max-w-lg xl:max-w-xl aspect-[4/3] perspective-1000 select-none mx-auto",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute left-4 top-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-gradient-to-br from-red-500/20 to-red-600/30 backdrop-blur-sm border border-red-500/30 flex items-center justify-center transition-all duration-300 z-10 ".concat(swipeIndicator === 'left' ? 'opacity-100 scale-110 shadow-[0_0_30px_rgba(239,68,68,0.5)]' : 'opacity-0 scale-90'),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                    className: "text-red-400 h-8 w-8 drop-shadow-lg"
                }, void 0, false, {
                    fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                    lineNumber: 151,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                lineNumber: 144,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute right-4 top-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-gradient-to-br from-green-500/20 to-green-600/30 backdrop-blur-sm border border-green-500/30 flex items-center justify-center transition-all duration-300 z-10 ".concat(swipeIndicator === 'right' ? 'opacity-100 scale-110 shadow-[0_0_30px_rgba(34,197,94,0.5)]' : 'opacity-0 scale-90'),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                    className: "text-green-400 h-8 w-8 drop-shadow-lg"
                }, void 0, false, {
                    fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                    lineNumber: 161,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                lineNumber: 154,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: cardRef,
                className: "relative w-full h-full transition-all duration-300 ".concat(dragOffset !== 0 ? 'z-20' : 'z-10', " ").concat(dragClass),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative w-full h-full transition-transform duration-500 will-change-transform [transform-style:preserve-3d] ".concat(isFlipped ? '[transform:rotateY(180deg)]' : ''),
                    onClick: handleClick,
                    onTouchStart: handleTouchStart,
                    onTouchMove: handleTouchMove,
                    onTouchEnd: handleDragEnd,
                    onMouseDown: handleMouseDown,
                    onMouseMove: handleMouseMove,
                    onMouseUp: handleDragEnd,
                    onMouseLeave: handleDragEnd,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "card-face-front absolute inset-0 [backface-visibility:hidden] flashcard-enhanced",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col h-full min-h-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flashcard-label flex-shrink-0",
                                        children: "English"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                        lineNumber: 187,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-grow flex items-center justify-center min-h-0 py-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "flashcard-title text-center",
                                            children: front
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                            lineNumber: 189,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                        lineNumber: 188,
                                        columnNumber: 15
                                    }, this),
                                    example && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flashcard-example flex-shrink-0",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-[var(--text)]/90 text-sm italic leading-relaxed",
                                            children: [
                                                '"',
                                                example,
                                                '"'
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                            lineNumber: 194,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                        lineNumber: 193,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flashcard-hint flex-shrink-0",
                                        children: "Tap to see Vietnamese meaning"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                        lineNumber: 200,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                lineNumber: 186,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                            lineNumber: 185,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "card-face-back absolute inset-0 [backface-visibility:hidden] flashcard-enhanced [transform:rotateY(180deg)]",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col h-full min-h-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flashcard-label flex-shrink-0",
                                        children: "Vietnamese"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                        lineNumber: 209,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-grow flex items-center justify-center min-h-0 py-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "flashcard-title text-center",
                                            children: back
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                            lineNumber: 211,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                        lineNumber: 210,
                                        columnNumber: 15
                                    }, this),
                                    exampleTranslation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flashcard-example flex-shrink-0",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-[var(--text)]/90 text-sm italic leading-relaxed",
                                            children: [
                                                '"',
                                                exampleTranslation,
                                                '"'
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                            lineNumber: 216,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                        lineNumber: 215,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flashcard-hint flex-shrink-0",
                                        children: "Tap to see English word"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                        lineNumber: 222,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                lineNumber: 208,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                            lineNumber: 207,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                    lineNumber: 171,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                lineNumber: 165,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center gap-4 mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>!disabled && onSwipeLeft(),
                        className: "flex items-center gap-2 px-6 py-3 bg-red-500/20 hover:bg-red-500/30    border border-red-500/30 rounded-xl transition-all duration-200   backdrop-blur-sm hover:scale-105 hover:shadow-[0_0_20px_rgba(239,68,68,0.3)]   text-red-300 font-medium disabled:opacity-50 disabled:cursor-not-allowed",
                        disabled: disabled,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xl",
                                children: "✖"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                lineNumber: 240,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Chưa nhớ"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                lineNumber: 241,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                        lineNumber: 232,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>!disabled && onSwipeRight(),
                        className: "flex items-center gap-2 px-6 py-3 bg-green-500/20 hover:bg-green-500/30    border border-green-500/30 rounded-xl transition-all duration-200   backdrop-blur-sm hover:scale-105 hover:shadow-[0_0_20px_rgba(34,197,94,0.3)]   text-green-300 font-medium disabled:opacity-50 disabled:cursor-not-allowed",
                        disabled: disabled,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xl",
                                children: "✓"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                lineNumber: 252,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Đã nhớ"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                                lineNumber: 253,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                        lineNumber: 244,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
                lineNumber: 231,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/features/flashcards/SwipeableFlashcard.tsx",
        lineNumber: 142,
        columnNumber: 5
    }, this);
}
_s(SwipeableFlashcard, "dXp0qkrC7MVNA0oplEnXe8LQVkc=");
_c = SwipeableFlashcard;
var _c;
__turbopack_context__.k.register(_c, "SwipeableFlashcard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/features/flashcards/QuickReview.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QuickReview",
    ()=>QuickReview
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/badge.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$progress$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/progress.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shuffle$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Shuffle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shuffle.js [client] (ecmascript) <export default as Shuffle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [client] (ecmascript) <export default as CheckCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-x.js [client] (ecmascript) <export default as XCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-left.js [client] (ecmascript) <export default as ArrowLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-right.js [client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Brain$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/brain.js [client] (ecmascript) <export default as Brain>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$target$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Target$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/target.js [client] (ecmascript) <export default as Target>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/zap.js [client] (ecmascript) <export default as Zap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$features$2f$flashcards$2f$SwipeableFlashcard$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/features/flashcards/SwipeableFlashcard.tsx [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function QuickReview(param) {
    let { learnedCards, onComplete, onBack } = param;
    _s();
    const [session, setSession] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isReviewing, setIsReviewing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showAnswer, setShowAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reviewMode, setReviewMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('random');
    const [sessionStats, setSessionStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])({
        totalCards: 0,
        reviewedCards: 0,
        correctAnswers: 0,
        incorrectAnswers: 0
    });
    // Khởi tạo session ôn tập
    const startReview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuickReview.useCallback[startReview]": ()=>{
            if (learnedCards.length === 0) return;
            const shuffledCards = reviewMode === 'random' ? [
                ...learnedCards
            ].sort({
                "QuickReview.useCallback[startReview]": ()=>Math.random() - 0.5
            }["QuickReview.useCallback[startReview]"]) : learnedCards;
            const newSession = {
                cards: shuffledCards,
                currentIndex: 0,
                correctCount: 0,
                incorrectCount: 0,
                startTime: new Date(),
                completedCards: new Set()
            };
            setSession(newSession);
            setIsReviewing(true);
            setShowAnswer(false);
            setSessionStats({
                totalCards: shuffledCards.length,
                reviewedCards: 0,
                correctAnswers: 0,
                incorrectAnswers: 0
            });
        }
    }["QuickReview.useCallback[startReview]"], [
        learnedCards,
        reviewMode
    ]);
    // Xử lý khi người dùng đánh giá câu trả lời
    const handleAnswer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuickReview.useCallback[handleAnswer]": (isCorrect)=>{
            if (!session) return;
            const currentCard = session.cards[session.currentIndex];
            const newCompletedCards = new Set(session.completedCards);
            newCompletedCards.add(currentCard.id);
            const newSession = {
                ...session,
                correctCount: isCorrect ? session.correctCount + 1 : session.correctCount,
                incorrectCount: isCorrect ? session.incorrectCount : session.incorrectCount + 1,
                completedCards: newCompletedCards
            };
            setSession(newSession);
            setSessionStats({
                "QuickReview.useCallback[handleAnswer]": (prev)=>({
                        ...prev,
                        reviewedCards: prev.reviewedCards + 1,
                        correctAnswers: isCorrect ? prev.correctAnswers + 1 : prev.correctAnswers,
                        incorrectAnswers: isCorrect ? prev.incorrectAnswers : prev.incorrectAnswers + 1
                    })
            }["QuickReview.useCallback[handleAnswer]"]);
            // Chuyển sang card tiếp theo
            setTimeout({
                "QuickReview.useCallback[handleAnswer]": ()=>{
                    if (session.currentIndex < session.cards.length - 1) {
                        setSession({
                            "QuickReview.useCallback[handleAnswer]": (prev)=>prev ? {
                                    ...prev,
                                    currentIndex: prev.currentIndex + 1
                                } : null
                        }["QuickReview.useCallback[handleAnswer]"]);
                        setShowAnswer(false);
                    } else {
                        // Hoàn thành session
                        finishReview();
                    }
                }
            }["QuickReview.useCallback[handleAnswer]"], 1000);
        }
    }["QuickReview.useCallback[handleAnswer]"], [
        session
    ]);
    // Hoàn thành session ôn tập
    const finishReview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuickReview.useCallback[finishReview]": ()=>{
            if (!session) return;
            const totalCards = session.cards.length;
            const correctCount = session.correctCount;
            setIsReviewing(false);
            setSession(null);
            onComplete(correctCount, totalCards);
        }
    }["QuickReview.useCallback[finishReview]"], [
        session,
        onComplete
    ]);
    // Chuyển card trước/sau
    const navigateCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuickReview.useCallback[navigateCard]": (direction)=>{
            if (!session) return;
            const newIndex = direction === 'prev' ? Math.max(0, session.currentIndex - 1) : Math.min(session.cards.length - 1, session.currentIndex + 1);
            setSession({
                "QuickReview.useCallback[navigateCard]": (prev)=>prev ? {
                        ...prev,
                        currentIndex: newIndex
                    } : null
            }["QuickReview.useCallback[navigateCard]"]);
            setShowAnswer(false);
        }
    }["QuickReview.useCallback[navigateCard]"], [
        session
    ]);
    // Toggle hiển thị đáp án
    const toggleAnswer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuickReview.useCallback[toggleAnswer]": ()=>{
            setShowAnswer({
                "QuickReview.useCallback[toggleAnswer]": (prev)=>!prev
            }["QuickReview.useCallback[toggleAnswer]"]);
        }
    }["QuickReview.useCallback[toggleAnswer]"], []);
    // Tính toán thời gian đã ôn tập
    const getElapsedTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuickReview.useCallback[getElapsedTime]": ()=>{
            if (!session) return '0:00';
            const elapsed = Date.now() - session.startTime.getTime();
            const minutes = Math.floor(elapsed / 60000);
            const seconds = Math.floor(elapsed % 60000 / 1000);
            return "".concat(minutes, ":").concat(seconds.toString().padStart(2, '0'));
        }
    }["QuickReview.useCallback[getElapsedTime]"], [
        session
    ]);
    // Tính toán độ chính xác
    const getAccuracy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "QuickReview.useCallback[getAccuracy]": ()=>{
            const total = sessionStats.correctAnswers + sessionStats.incorrectAnswers;
            return total > 0 ? Math.round(sessionStats.correctAnswers / total * 100) : 0;
        }
    }["QuickReview.useCallback[getAccuracy]"], [
        sessionStats
    ]);
    if (!isReviewing || !session) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "ghost",
                            onClick: onBack,
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__["ArrowLeft"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                    lineNumber: 204,
                                    columnNumber: 13
                                }, this),
                                "Quay lại"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                            lineNumber: 199,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Badge"], {
                            variant: "secondary",
                            className: "flex items-center gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Brain$3e$__["Brain"], {
                                    className: "h-3 w-3"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                    lineNumber: 208,
                                    columnNumber: 13
                                }, this),
                                learnedCards.length,
                                " từ đã học"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                            lineNumber: 207,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                    lineNumber: 198,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Card"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$target$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Target$3e$__["Target"], {
                                        className: "h-5 w-5 text-blue-500"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                        lineNumber: 217,
                                        columnNumber: 15
                                    }, this),
                                    "Ôn tập nhanh"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 216,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                            lineNumber: 215,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardContent"], {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600 dark:text-gray-400",
                                    children: "Ôn tập lại các từ vựng bạn đã học để củng cố kiến thức"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                    lineNumber: 222,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-medium",
                                            children: "Chế độ ôn tập:"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                            lineNumber: 228,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                                    variant: reviewMode === 'random' ? 'default' : 'outline',
                                                    size: "sm",
                                                    onClick: ()=>setReviewMode('random'),
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shuffle$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Shuffle$3e$__["Shuffle"], {
                                                            className: "h-4 w-4"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                                            lineNumber: 236,
                                                            columnNumber: 19
                                                        }, this),
                                                        "Ngẫu nhiên"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                                    lineNumber: 230,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                                    variant: reviewMode === 'sequential' ? 'default' : 'outline',
                                                    size: "sm",
                                                    onClick: ()=>setReviewMode('sequential'),
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                            className: "h-4 w-4"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                                            lineNumber: 245,
                                                            columnNumber: 19
                                                        }, this),
                                                        "Tuần tự"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                                    lineNumber: 239,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                            lineNumber: 229,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                    lineNumber: 227,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                    onClick: startReview,
                                    disabled: learnedCards.length === 0,
                                    className: "w-full",
                                    size: "lg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__["Zap"], {
                                            className: "h-4 w-4 mr-2"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                            lineNumber: 258,
                                            columnNumber: 15
                                        }, this),
                                        "Bắt đầu ôn tập (",
                                        learnedCards.length,
                                        " từ)"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                    lineNumber: 252,
                                    columnNumber: 13
                                }, this),
                                learnedCards.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-500 text-center",
                                    children: "Bạn chưa có từ nào đã học để ôn tập"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                    lineNumber: 263,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                            lineNumber: 221,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                    lineNumber: 214,
                    columnNumber: 9
                }, this),
                sessionStats.totalCards > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Card"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                className: "text-sm",
                                children: "Thống kê gần đây"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 274,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                            lineNumber: 273,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardContent"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-4 text-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-gray-500",
                                                children: "Độ chính xác"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                                lineNumber: 279,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-semibold",
                                                children: [
                                                    getAccuracy(),
                                                    "%"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                                lineNumber: 280,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                        lineNumber: 278,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-gray-500",
                                                children: "Từ đã ôn"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                                lineNumber: 283,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-semibold",
                                                children: sessionStats.reviewedCards
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                                lineNumber: 284,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                        lineNumber: 282,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 277,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                            lineNumber: 276,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                    lineNumber: 272,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
            lineNumber: 196,
            columnNumber: 7
        }, this);
    }
    const currentCard = session.cards[session.currentIndex];
    const progress = (session.currentIndex + 1) / session.cards.length * 100;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "ghost",
                        onClick: ()=>setIsReviewing(false),
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__["ArrowLeft"], {
                                className: "h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 308,
                                columnNumber: 11
                            }, this),
                            "Thoát"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                        lineNumber: 303,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4 text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                        lineNumber: 314,
                                        columnNumber: 13
                                    }, this),
                                    getElapsedTime()
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 313,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                                        className: "h-4 w-4 text-green-500"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                        lineNumber: 318,
                                        columnNumber: 13
                                    }, this),
                                    sessionStats.correctAnswers
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 317,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__["XCircle"], {
                                        className: "h-4 w-4 text-red-500"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                        lineNumber: 322,
                                        columnNumber: 13
                                    }, this),
                                    sessionStats.incorrectAnswers
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 321,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                        lineNumber: 312,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                lineNumber: 302,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Tiến độ ôn tập"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 331,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    session.currentIndex + 1,
                                    " / ",
                                    session.cards.length
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 332,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                        lineNumber: 330,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$progress$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Progress"], {
                        value: progress,
                        className: "h-2"
                    }, void 0, false, {
                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                        lineNumber: 336,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                lineNumber: 329,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full max-w-md",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$features$2f$flashcards$2f$SwipeableFlashcard$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["SwipeableFlashcard"], {
                        front: currentCard.front,
                        back: currentCard.back,
                        example: currentCard.example,
                        exampleTranslation: currentCard.exampleTranslation,
                        onSwipeLeft: ()=>handleAnswer(false),
                        onSwipeRight: ()=>handleAnswer(true),
                        disabled: false
                    }, void 0, false, {
                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                        lineNumber: 342,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                    lineNumber: 341,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                lineNumber: 340,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "outline",
                        onClick: ()=>navigateCard('prev'),
                        disabled: session.currentIndex === 0,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__["ArrowLeft"], {
                                className: "h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 361,
                                columnNumber: 11
                            }, this),
                            "Trước"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                        lineNumber: 356,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "outline",
                        onClick: toggleAnswer,
                        children: showAnswer ? 'Ẩn đáp án' : 'Xem đáp án'
                    }, void 0, false, {
                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                        lineNumber: 365,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "outline",
                        onClick: ()=>navigateCard('next'),
                        disabled: session.currentIndex === session.cards.length - 1,
                        children: [
                            "Sau",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                className: "h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 375,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                        lineNumber: 369,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                lineNumber: 355,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "destructive",
                        onClick: ()=>handleAnswer(false),
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__["XCircle"], {
                                className: "h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 386,
                                columnNumber: 11
                            }, this),
                            "Sai"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                        lineNumber: 381,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "default",
                        onClick: ()=>handleAnswer(true),
                        className: "flex items-center gap-2 bg-green-600 hover:bg-green-700",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                                className: "h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                                lineNumber: 394,
                                columnNumber: 11
                            }, this),
                            "Đúng"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                        lineNumber: 389,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
                lineNumber: 380,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/features/flashcards/QuickReview.tsx",
        lineNumber: 300,
        columnNumber: 5
    }, this);
}
_s(QuickReview, "tbkbFumrotnVs8wEDlx5MiDuOLk=");
_c = QuickReview;
var _c;
__turbopack_context__.k.register(_c, "QuickReview");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/features/flashcards/FlashcardScreen.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FlashcardScreen",
    ()=>FlashcardScreen
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$progress$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/progress.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/badge.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-left.js [client] (ecmascript) <export default as ArrowLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2d$circuit$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BrainCircuit$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/brain-circuit.js [client] (ecmascript) <export default as BrainCircuit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [client] (ecmascript) <export default as AlertTriangle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/minus.js [client] (ecmascript) <export default as Minus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/square-pen.js [client] (ecmascript) <export default as Edit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/save.js [client] (ecmascript) <export default as Save>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RotateCcw$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/rotate-ccw.js [client] (ecmascript) <export default as RotateCcw>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [client] (ecmascript) <export default as CheckCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-x.js [client] (ecmascript) <export default as XCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/dialog.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/input.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$features$2f$flashcards$2f$SwipeableFlashcard$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/features/flashcards/SwipeableFlashcard.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$features$2f$flashcards$2f$QuickReview$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/features/flashcards/QuickReview.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/alert-dialog.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$gemini$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/gemini/config.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$LevelContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/LevelContext.tsx [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function FlashcardScreen(param) {
    let { user, onTabChange, startQuickReview, onMarkQuickReviewUsed } = param;
    var _auth_currentUser, _selectedDeck_cards, _selectedDeck_cards_currentCardIndex, _selectedDeck_cards_currentCardIndex1, _selectedDeck_cards_currentCardIndex2, _selectedDeck_cards_currentCardIndex3;
    _s();
    const [currentView, setCurrentView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('list');
    const [decks, setDecks] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedDeck, setSelectedDeck] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentCardIndex, setCurrentCardIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [generatingExample, setGeneratingExample] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { addUserXP, updateStats, userStats } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$LevelContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["useLevel"])();
    const [pendingDecision, setPendingDecision] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isMarking, setIsMarking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // State cho AI Flashcard Creator
    const [aiDialogOpen, setAiDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [creatingDeck, setCreatingDeck] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [newDeckTitle, setNewDeckTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [newDeckTopic, setNewDeckTopic] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [newDeckSubject, setNewDeckSubject] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [cardCount, setCardCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(5);
    const [generatedCards, setGeneratedCards] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [showEditDialog, setShowEditDialog] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // State cho xóa deck
    const [deleteDialogOpen, setDeleteDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [deckToDelete, setDeckToDelete] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Định nghĩa hàm loadFlashcards
    const loadFlashcards = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FlashcardScreen.useCallback[loadFlashcards]": async ()=>{
            // Đợi auth.currentUser sẵn sàng (không set decks = [] ngay khi chưa có user)
            if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) {
                // Nếu chưa có user, chỉ skip load (không xóa decks hiện tại)
                setLoading(false);
                return;
            }
            // Kiểm tra user.accessToken (có thể null khi đang load)
            if (!(user === null || user === void 0 ? void 0 : user.accessToken)) {
                // Nếu user chưa có accessToken, đợi một chút rồi thử lại
                setLoading(false);
                return;
            }
            setLoading(true);
            try {
                // Tải dữ liệu từ Firestore
                const flashcardsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'flashcard_decks');
                const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(flashcardsRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser.uid));
                const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
                const serverDecks = [];
                querySnapshot.forEach({
                    "FlashcardScreen.useCallback[loadFlashcards]": (doc)=>{
                        serverDecks.push({
                            id: doc.id,
                            ...doc.data()
                        });
                    }
                }["FlashcardScreen.useCallback[loadFlashcards]"]);
                // Thêm màu sắc cho các deck
                const decksWithColors = serverDecks.map({
                    "FlashcardScreen.useCallback[loadFlashcards].decksWithColors": (deck, index)=>({
                            ...deck,
                            color: index % 3 === 0 ? 'bg-[var(--primary)]' : index % 3 === 1 ? 'bg-[var(--success)]' : 'bg-[var(--warning)]'
                        })
                }["FlashcardScreen.useCallback[loadFlashcards].decksWithColors"]);
                setDecks(decksWithColors);
            } catch (error) {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.error('Failed to load flashcards:', error);
                }
                // Nếu có lỗi, chỉ để empty state
                setDecks([]);
            } finally{
                setLoading(false);
            }
        }
    }["FlashcardScreen.useCallback[loadFlashcards]"], [
        user === null || user === void 0 ? void 0 : user.accessToken
    ]);
    // Lấy tất cả các từ đã học từ tất cả decks
    const getAllLearnedCards = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FlashcardScreen.useCallback[getAllLearnedCards]": ()=>{
            const learnedCards = [];
            decks.forEach({
                "FlashcardScreen.useCallback[getAllLearnedCards]": (deck)=>{
                    if (deck.cards && Array.isArray(deck.cards)) {
                        deck.cards.forEach({
                            "FlashcardScreen.useCallback[getAllLearnedCards]": (card)=>{
                                if (card.learned) {
                                    learnedCards.push({
                                        ...card,
                                        deckTitle: deck.title,
                                        deckId: deck.id
                                    });
                                }
                            }
                        }["FlashcardScreen.useCallback[getAllLearnedCards]"]);
                    }
                }
            }["FlashcardScreen.useCallback[getAllLearnedCards]"]);
            return learnedCards;
        }
    }["FlashcardScreen.useCallback[getAllLearnedCards]"], [
        decks
    ]);
    // Load flashcards khi user hoặc auth.currentUser thay đổi
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FlashcardScreen.useEffect": ()=>{
            // Chỉ load khi đã có user và auth.currentUser
            if ((user === null || user === void 0 ? void 0 : user.accessToken) && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) {
                loadFlashcards();
            }
        }
    }["FlashcardScreen.useEffect"], [
        user === null || user === void 0 ? void 0 : user.accessToken,
        (_auth_currentUser = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) === null || _auth_currentUser === void 0 ? void 0 : _auth_currentUser.uid,
        loadFlashcards
    ]);
    // Xử lý khi startQuickReview được set từ bên ngoài
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FlashcardScreen.useEffect": ()=>{
            if (startQuickReview && getAllLearnedCards().length > 0) {
                setCurrentView('review');
                // Reset prop sau khi đã sử dụng
                if (onTabChange) {
                    onTabChange('flashcards');
                }
            }
        }
    }["FlashcardScreen.useEffect"], [
        startQuickReview,
        getAllLearnedCards,
        onTabChange
    ]);
    const startDeck = (deck)=>{
        setSelectedDeck(deck);
        setCurrentView('player');
        setCurrentCardIndex(0);
    };
    const nextCard = ()=>{
        var _selectedDeck_cards;
        if (currentCardIndex < ((selectedDeck === null || selectedDeck === void 0 ? void 0 : (_selectedDeck_cards = selectedDeck.cards) === null || _selectedDeck_cards === void 0 ? void 0 : _selectedDeck_cards.length) || 0) - 1) {
            setCurrentCardIndex(currentCardIndex + 1);
        }
    };
    const prevCard = ()=>{
        if (currentCardIndex > 0) {
            setCurrentCardIndex(currentCardIndex - 1);
        }
    };
    const doMarkCardAsLearned = async (learned)=>{
        if (!selectedDeck || !selectedDeck.cards) return;
        // Chụp chỉ số thẻ hiện tại để dùng nhất quán
        const cardIndex = currentCardIndex;
        const card = selectedDeck.cards[cardIndex];
        if (!card) return;
        if (isMarking) return;
        setIsMarking(true);
        // Update card trong state theo chỉ số đã chụp
        const updatedDecks = decks.map((deck)=>{
            if (deck.id === selectedDeck.id) {
                const updatedCards = deck.cards.map((c, idx)=>{
                    if (idx === cardIndex) {
                        return {
                            ...c,
                            learned
                        };
                    }
                    return c;
                });
                return {
                    ...deck,
                    cards: updatedCards,
                    learned: learned ? deck.learned + (card.learned ? 0 : 1) : deck.learned - (card.learned ? 1 : 0)
                };
            }
            return deck;
        });
        setDecks(updatedDecks);
        // Update selected deck
        const updatedDeck = updatedDecks.find((d)=>d.id === selectedDeck.id);
        if (updatedDeck) {
            setSelectedDeck(updatedDeck);
        }
        // Award XP cho thẻ mới được đánh dấu là đã nhớ
        if (learned && !card.learned) {
            await addUserXP('COMPLETE_FLASHCARD');
            await updateStats({
                flashcardsStudied: userStats.flashcardsStudied + 1
            });
        }
        // Update Firestore trước khi chuyển thẻ để đảm bảo chỉ số đúng
        if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser && selectedDeck.id && !selectedDeck.id.startsWith('local-')) {
            try {
                const deckRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'flashcard_decks', selectedDeck.id);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(deckRef, {
                    ["cards.".concat(cardIndex, ".learned")]: learned,
                    learned: learned ? selectedDeck.learned + (card.learned ? 0 : 1) : selectedDeck.learned - (card.learned ? 1 : 0)
                });
            } catch (error) {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.error('Failed to update card status:', error);
                }
            }
        }
        // Chuyển sang thẻ tiếp theo sau khi cập nhật xong
        nextCard();
        setIsMarking(false);
    };
    const markCardAsLearned = (learned)=>{
        // Trong chế độ player: cập nhật ngay để không chặn flow học
        if (currentView === 'player') {
            void doMarkCardAsLearned(learned);
            return;
        }
        // Ở các view khác (list/review) mới yêu cầu xác nhận
        setPendingDecision({
            learned
        });
    };
    // Bắt đầu ôn tập
    const handleStartQuickReview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FlashcardScreen.useCallback[handleStartQuickReview]": ()=>{
            setCurrentView('review');
        }
    }["FlashcardScreen.useCallback[handleStartQuickReview]"], []);
    // Xử lý khi hoàn thành ôn tập
    const handleReviewComplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FlashcardScreen.useCallback[handleReviewComplete]": async (correctCount, totalCount)=>{
            // Award XP based on performance
            const accuracy = correctCount / totalCount;
            if (accuracy >= 0.8) {
                await addUserXP('COMPLETE_FLASHCARD');
            } else if (accuracy >= 0.6) {
                await addUserXP('COMPLETE_FLASHCARD');
            } else {
                await addUserXP('COMPLETE_FLASHCARD');
            }
            // Update stats
            await updateStats({
                flashcardsStudied: userStats.flashcardsStudied + totalCount
            });
            // Complete mission "Ôn tập 5 từ vựng đã học" nếu đủ điều kiện
            if (totalCount >= 5 && (user === null || user === void 0 ? void 0 : user.uid)) {
                try {
                    // Gọi completeMissionByType để hoàn thành mission
                    const { completeMissionByType } = await __turbopack_context__.A("[project]/src/services/dashboard/missionsService.ts [client] (ecmascript, async loader)");
                    const result = await completeMissionByType(user.uid, 'review');
                    if (result) {
                        console.log('Mission "Ôn tập 5 từ vựng đã học" đã hoàn thành!', result);
                        // Mark quick review as used today
                        if (onMarkQuickReviewUsed) {
                            onMarkQuickReviewUsed();
                        }
                    }
                } catch (error) {
                    console.error('Error completing mission:', error);
                }
            }
            // Quay lại danh sách
            setCurrentView('list');
        }
    }["FlashcardScreen.useCallback[handleReviewComplete]"], [
        addUserXP,
        updateStats,
        userStats.flashcardsStudied,
        onMarkQuickReviewUsed,
        user === null || user === void 0 ? void 0 : user.uid
    ]);
    // Quay lại từ ôn tập
    const handleBackFromReview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FlashcardScreen.useCallback[handleBackFromReview]": ()=>{
            setCurrentView('list');
        }
    }["FlashcardScreen.useCallback[handleBackFromReview]"], []);
    const generateNewExample = async ()=>{
        if (!selectedDeck || !selectedDeck.cards) return;
        const card = selectedDeck.cards[currentCardIndex];
        if (!card) return;
        setGeneratingExample(true);
        try {
            // Sử dụng Gemini API để tạo ví dụ mới
            const prompt = 'Tạo một câu ví dụ tiếng Anh KHÁC với câu hiện tại "'.concat(card.example || '', '" sử dụng từ hoặc cụm từ "').concat(card.front, '" (nghĩa: "').concat(card.back, '"). Câu ví dụ nên:\n- Ngắn gọn (10-15 từ)\n- Rõ ràng và dễ hiểu\n- Khác hoàn toàn với ví dụ cũ\n- Phù hợp với ngữ cảnh thông thường\nChỉ trả về MỘT câu ví dụ, không có markdown.');
            let newExample;
            let exampleTranslation;
            try {
                // Gọi API AI để tạo ví dụ mới
                newExample = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$gemini$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["generateGeminiResponse"])(prompt);
                // Loại bỏ các ký hiệu markdown và làm sạch câu ví dụ
                newExample = newExample.replace(/\*\*/g, '') // Loại bỏ dấu **
                .replace(/\*/g, '') // Loại bỏ dấu *
                .replace(/`/g, '') // Loại bỏ dấu `
                .replace(/^["'](.*)["']$/, '$1') // Loại bỏ dấu ngoặc kép/đơn bao quanh
                .trim();
                if (!newExample || newExample.length < 10) {
                    throw new Error('Invalid response from AI');
                }
                // Tạo bản dịch tiếng Việt cho ví dụ mới
                const translationPrompt = 'Hãy dịch câu tiếng Anh sau sang tiếng Việt một cách tự nhiên và dễ hiểu: "'.concat(newExample, '"');
                try {
                    exampleTranslation = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$gemini$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["generateGeminiResponse"])(translationPrompt);
                    exampleTranslation = exampleTranslation.replace(/\*\*/g, '').replace(/\*/g, '').replace(/`/g, '').replace(/^["'](.*)["']$/, '$1').trim();
                } catch (translationError) {
                    console.error('Error translating example:', translationError);
                    exampleTranslation = 'Ví dụ với "'.concat(card.front, '"');
                }
            } catch (aiError) {
                console.error('Error calling AI:', aiError);
                // Fallback nếu API lỗi - tạo ví dụ khác
                const newExamples = [
                    'I often use "'.concat(card.front, '" in my conversations.'),
                    'The word "'.concat(card.front, '" is very useful in daily life.'),
                    'Can you give me another example with "'.concat(card.front, '"?'),
                    '"'.concat(card.front, '" appears frequently in English texts.'),
                    'Let me show you how to use "'.concat(card.front, '" properly.')
                ];
                newExample = newExamples[Math.floor(Math.random() * newExamples.length)];
                exampleTranslation = 'Ví dụ khác với từ "'.concat(card.front, '"');
            }
            // Update the card with new example and translation
            const updatedDecks = decks.map((deck)=>{
                if (deck.id === selectedDeck.id) {
                    const updatedCards = deck.cards.map((c, idx)=>{
                        if (idx === currentCardIndex) {
                            return {
                                ...c,
                                example: newExample,
                                exampleTranslation: exampleTranslation
                            };
                        }
                        return c;
                    });
                    return {
                        ...deck,
                        cards: updatedCards
                    };
                }
                return deck;
            });
            setDecks(updatedDecks);
            // Update selected deck để re-render ngay lập tức
            const updatedDeck = updatedDecks.find((d)=>d.id === selectedDeck.id);
            if (updatedDeck) {
                setSelectedDeck(updatedDeck);
                // Lưu vào Firestore nếu có user và deck không phải local
                if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser && selectedDeck.id && !selectedDeck.id.startsWith('local-')) {
                    try {
                        const deckRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'flashcard_decks', selectedDeck.id);
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(deckRef, {
                            cards: updatedDeck.cards,
                            updatedAt: new Date().toISOString()
                        });
                        console.log('Updated deck in Firestore with new example');
                    } catch (firestoreError) {
                        console.error('Error updating Firestore:', firestoreError);
                    }
                }
            }
        } catch (error) {
            console.error('Failed to generate new example:', error);
        } finally{
            setGeneratingExample(false);
        }
    };
    // Hàm xóa deck
    const handleDeleteDeck = async ()=>{
        if (!deckToDelete) return;
        try {
            // Xóa khỏi state
            setDecks(decks.filter((deck)=>deck.id !== deckToDelete.id));
            // Xóa khỏi Firestore nếu có auth.currentUser và không phải deck local
            if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser && deckToDelete.id && !deckToDelete.id.startsWith('local-')) {
                try {
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["deleteDoc"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'flashcard_decks', deckToDelete.id));
                    // Chỉ log trong môi trường development
                    if ("TURBOPACK compile-time truthy", 1) {
                        console.log("Deleted deck ".concat(deckToDelete.id, " from Firestore"));
                    }
                } catch (error) {
                    // Chỉ log trong môi trường development
                    if ("TURBOPACK compile-time truthy", 1) {
                        console.error('Error deleting deck from Firestore:', error);
                    }
                }
            }
            // Đóng dialog
            setDeleteDialogOpen(false);
            setDeckToDelete(null);
        } catch (error) {
            // Chỉ log trong môi trường development
            if ("TURBOPACK compile-time truthy", 1) {
                console.error('Failed to delete deck:', error);
            }
        }
    };
    // Hàm tạo flashcards mới bằng AI
    const createAIFlashcards = async ()=>{
        if (!newDeckTitle.trim() || !newDeckTopic.trim() || !newDeckSubject.trim()) {
            return;
        }
        setCreatingDeck(true);
        try {
            // Tự động xác định ngôn ngữ dựa vào môn học
            let frontLanguage = 'tiếng Anh';
            let backLanguage = 'tiếng Việt';
            // Bộ nhận diện ngôn ngữ từ chủ đề (không phân biệt hoa/thường, có bỏ dấu)
            const stripAccents = (s)=>(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
            const subjNorm = stripAccents(newDeckSubject);
            const isEnglish = /(tieng anh|english|en\b)/.test(subjNorm);
            const isFrench = /(tieng phap|phap|french|francais|francaise|fr\b)/.test(subjNorm);
            const isJapanese = /(tieng nhat|nhat|japanese|nihongo|jp\b)/.test(subjNorm);
            const isChinese = /(tieng trung|trung|hoa|chinese|mandarin|zh\b|han ngu)/.test(subjNorm);
            const isKorean = /(tieng han|han|korean|hangul|kr\b|han quoc)/.test(subjNorm);
            const isSpanish = /(tieng tay ban nha|tay ban nha|spanish|espanol|es\b)/.test(subjNorm);
            if (isEnglish) {
                frontLanguage = 'tiếng Anh';
                backLanguage = 'tiếng Việt';
            } else if (isFrench) {
                frontLanguage = 'tiếng Pháp';
                backLanguage = 'tiếng Việt';
            } else if (isJapanese) {
                frontLanguage = 'tiếng Nhật';
                backLanguage = 'tiếng Việt';
            } else if (isChinese) {
                frontLanguage = 'tiếng Trung';
                backLanguage = 'tiếng Việt';
            } else if (isKorean) {
                frontLanguage = 'tiếng Hàn';
                backLanguage = 'tiếng Việt';
            } else if (isSpanish) {
                frontLanguage = 'tiếng Tây Ban Nha';
                backLanguage = 'tiếng Việt';
            } else {
                // Đối với các môn khác, mặc định sử dụng tiếng Anh - tiếng Việt
                frontLanguage = 'tiếng Anh';
                backLanguage = 'tiếng Việt';
            }
            // Tạo prompt cho AI để sinh flashcards
            // Xây danh sách loại trừ từ đã có để tránh lặp giữa các lần tạo
            const normalizeForPrompt = (s)=>(s || '').toLowerCase().trim().replace(/[\s\u200B\u200C\u200D\uFEFF]+/g, ' ').replace(RegExp("[^\\p{L}\\p{N}]+", "gu"), ' ');
            const existingFrontsAll = (decks || []).flatMap((d)=>((d === null || d === void 0 ? void 0 : d.cards) || []).map((c)=>c.front || '')).filter(Boolean);
            const existingFrontsUnique = Array.from(new Set(existingFrontsAll.map(normalizeForPrompt)));
            const exclusionSample = existingFrontsUnique.slice(-Math.min(60, existingFrontsUnique.length)).join(', ');
            const exclusionText = exclusionSample ? "\n      9. KHÔNG được dùng bất kỳ từ/cụm từ nào trong danh sách loại trừ sau (nếu có trùng, thay bằng từ khác cùng chủ đề): ".concat(exclusionSample) : '';
            const prompt = "Tạo flashcards môn ".concat(newDeckSubject, ", chủ đề ").concat(newDeckTopic, ". Hãy tạo CHÍNH XÁC ").concat(cardCount, " flashcard có chất lượng cao.\n\n      RÀNG BUỘC NGÔN NGỮ (BẮT BUỘC):\n      - Cột Front: viết bằng ").concat(frontLanguage, ".\n      - Cột Back: viết bằng ").concat(backLanguage, ".\n      - Cột Example: câu ví dụ viết bằng ").concat(frontLanguage, ".\n      - Cột ExampleTranslation: bản dịch của câu ví dụ sang ").concat(backLanguage, ".\n\nLưu ý quan trọng: \n      1. Không sử dụng dấu ** hoặc markdown trong nội dung cell.\n2. Câu ví dụ phải rõ ràng, ngắn gọn và dễ hiểu.\n3. Bản dịch của câu ví dụ phải chính xác và tự nhiên.\n      4. KHÔNG sử dụng dòng phân cách bằng dấu gạch ngang (---) trong bất kỳ phần nào.\n      5. Trả lời DƯỚI DẠNG BẢNG với 4 cột (dùng ký tự | để phân tách cột): Front | Back | Example | ExampleTranslation.\n      6. MỖI THẺ PHẢI LÀ MỘT TỪ/CỤM TỪ KHÁC NHAU – tuyệt đối KHÔNG trùng lặp từ vựng giữa các hàng.\n      7. ĐA DẠNG chủ đề con và ngữ cảnh trong phạm vi chủ đề đã cho; không lặp lại cùng một từ dưới nhiều biến thể.\n      8. Không thêm bất kỳ văn bản nào ngoài bảng.").concat(exclusionText);
            // Gọi API AI
            const aiResponse = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$gemini$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["generateGeminiResponse"])(prompt);
            let cards = [];
            // Xử lý phản hồi từ AI để tạo flashcards
            try {
                // 1) Thử parse JSON fallback dạng { flashcards: [...] }
                try {
                    const asJson = JSON.parse(aiResponse);
                    if (asJson && Array.isArray(asJson.flashcards)) {
                        cards = asJson.flashcards.map((it, idx)=>{
                            var _it_front, _it_back, _it_example, _it_exampleTranslation;
                            return {
                                id: "".concat(Date.now(), "_").concat(idx),
                                front: String((_it_front = it.front) !== null && _it_front !== void 0 ? _it_front : ''),
                                back: String((_it_back = it.back) !== null && _it_back !== void 0 ? _it_back : ''),
                                example: String((_it_example = it.example) !== null && _it_example !== void 0 ? _it_example : ''),
                                exampleTranslation: String((_it_exampleTranslation = it.exampleTranslation) !== null && _it_exampleTranslation !== void 0 ? _it_exampleTranslation : ''),
                                learned: false
                            };
                        });
                    }
                } catch (e) {
                // Không phải JSON, tiếp tục parse Markdown phía dưới
                }
                // 2) Nếu chưa có cards từ JSON, parse bảng Markdown
                if (cards.length === 0) {
                    // Tìm tất cả bảng Markdown trong phản hồi (nếu có nhiều)
                    const tableRegex = /\|.*\|.*\|[\s\S]*?\n([\s\S]*?)(?:\n\n|$)/g;
                    const tableMatches = Array.from(aiResponse.matchAll(tableRegex));
                    const parsedCards = [];
                    const normalize = (s)=>s.toLowerCase().trim().replace(/[\s\u200B\u200C\u200D\uFEFF]+/g, ' ').replace(RegExp("[^\\p{L}\\p{N}]+", "gu"), ' ');
                    const seenFronts = new Set();
                    for (const match of tableMatches){
                        const body = match[1] || '';
                        const rows = body.split('\n').map((r)=>r.trim()).filter((r)=>r && r.includes('|'));
                        rows.forEach((row, index)=>{
                            const columns = row.split('|').map((col)=>col.trim()).filter(Boolean);
                            // Bỏ qua header/tiêu đề nếu có hoặc hàng phân cách
                            const firstCell = (columns[0] || '').toLowerCase();
                            if (firstCell === 'front' || firstCell === 'từ' || /^-+$/.test(columns[0] || '') || /^-+$/.test(columns[1] || '')) {
                                return;
                            }
                            if (columns.length >= 2) {
                                const clean = (v)=>v.replace(/^"(.*)"$/, '$1').replace(/\*\*/g, '').replace(/\*/g, '').replace(/`/g, '').trim();
                                const cleanFront = clean(columns[0]);
                                const cleanBack = clean(columns[1]);
                                const cleanExample = columns.length > 2 ? clean(columns[2]) : '';
                                const cleanExampleTranslation = columns.length > 3 ? clean(columns[3]) : '';
                                if (!cleanFront || !cleanBack) return;
                                const normFront = normalize(cleanFront);
                                if (seenFronts.has(normFront)) return; // loại trùng theo mặt trước
                                seenFronts.add(normFront);
                                parsedCards.push({
                                    id: "ai-card-".concat(Date.now(), "-").concat(parsedCards.length, "-").concat(index),
                                    front: cleanFront,
                                    back: cleanBack,
                                    example: cleanExample,
                                    exampleTranslation: cleanExampleTranslation,
                                    learned: false
                                });
                            }
                        });
                    }
                    cards = parsedCards;
                    // Loại các từ đã từng xuất hiện trong các deck trước để tránh lặp giữa các lần tạo
                    if (existingFrontsUnique.length > 0) {
                        const existingSet = new Set(existingFrontsUnique);
                        const normalize = (s)=>(s || '').toLowerCase().trim().replace(/[\s\u200B\u200C\u200D\uFEFF]+/g, ' ').replace(RegExp("[^\\p{L}\\p{N}]+", "gu"), ' ');
                        cards = cards.filter((c)=>!existingSet.has(normalize(c.front)));
                    }
                    // Xáo trộn ngẫu nhiên để tăng đa dạng trước khi cắt số lượng
                    if (cards.length > 1) {
                        cards = cards.map((c)=>({
                                c,
                                r: Math.random()
                            })).sort((a, b)=>a.r - b.r).map((param)=>{
                            let { c } = param;
                            return c;
                        });
                    }
                    // 3) Nếu không tìm thấy bảng hoặc không có cards hợp lệ, fallback: tìm cặp từ-nghĩa dạng "a - b" hoặc "a: b"
                    if (cards.length === 0) {
                        const lines = aiResponse.split('\n');
                        const seen = new Set();
                        const norm = (s)=>s.toLowerCase().trim().replace(/[\s\u200B\u200C\u200D\uFEFF]+/g, ' ').replace(RegExp("[^\\p{L}\\p{N}]+", "gu"), ' ');
                        for (const line of lines){
                            if (line.includes('-') || line.includes(':')) {
                                const parts = line.split(/[-:]/).map((part)=>part.trim());
                                if (parts.length >= 2) {
                                    const front = parts[0].replace(/^"(.*)"$/, '$1');
                                    const back = parts[1];
                                    const key = norm(front);
                                    if (front && back && !seen.has(key)) {
                                        seen.add(key);
                                        cards.push({
                                            id: "ai-card-".concat(Date.now(), "-").concat(cards.length),
                                            front,
                                            back,
                                            example: '',
                                            exampleTranslation: '',
                                            learned: false
                                        });
                                    }
                                }
                            }
                        }
                    }
                    // Đảm bảo duy nhất theo front và giới hạn số lượng theo cardCount
                    if (cards.length > 0) {
                        const unique = [];
                        const seen = new Set();
                        const keyOf = (s)=>s.toLowerCase().trim().replace(/[\s\u200B\u200C\u200D\uFEFF]+/g, ' ').replace(RegExp("[^\\p{L}\\p{N}]+", "gu"), ' ');
                        for (const c of cards){
                            const k = keyOf(c.front);
                            if (!seen.has(k)) {
                                seen.add(k);
                                unique.push(c);
                            }
                        }
                        cards = unique.slice(0, Math.max(1, cardCount));
                    }
                }
            } catch (parseError) {
                console.error('Error parsing AI response:', parseError);
            }
            // Nếu vẫn không có cards, báo lỗi cho người dùng
            if (cards.length === 0) {
                alert('AI không thể tạo flashcard cho chủ đề này. Vui lòng thử lại hoặc thay đổi chủ đề!');
                setCreatingDeck(false);
                return;
            }
            // Lưu thẻ đã tạo vào state để có thể chỉnh sửa
            setGeneratedCards(cards);
            // Hiển thị dialog chỉnh sửa thẻ
            setShowEditDialog(true);
            setAiDialogOpen(false);
            setCreatingDeck(false);
        // Các bước lưu deck sẽ được thực hiện sau khi người dùng xác nhận từ dialog chỉnh sửa
        } catch (error) {
            console.error('Failed to create AI flashcards:', error);
        } finally{
            setCreatingDeck(false);
        }
    };
    const currentCard = selectedDeck === null || selectedDeck === void 0 ? void 0 : (_selectedDeck_cards = selectedDeck.cards) === null || _selectedDeck_cards === void 0 ? void 0 : _selectedDeck_cards[currentCardIndex];
    if (currentView === 'player' && selectedDeck) {
        var _selectedDeck_cards1, _selectedDeck_cards2;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-dvh flex flex-col bg-[var(--bg)] text-[var(--text)]",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-shrink-0 p-4 md:p-6 pb-2 md:pb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                    variant: "ghost",
                                    onClick: ()=>setCurrentView('list'),
                                    className: "bg-transparent text-[var(--muted)] hover:text-[var(--text)] focus-visible:ring-2 focus-visible:ring-[var(--ring)] flex-shrink-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__["ArrowLeft"], {
                                            className: "h-4 w-4 mr-2"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 855,
                                            columnNumber: 15
                                        }, this),
                                        "Quay lại"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 850,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Badge"], {
                                    variant: "outline",
                                    className: "flex-shrink-0",
                                    children: [
                                        currentCardIndex + 1,
                                        "/",
                                        ((_selectedDeck_cards1 = selectedDeck.cards) === null || _selectedDeck_cards1 === void 0 ? void 0 : _selectedDeck_cards1.length) || 0
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 858,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 849,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-[var(--text)] truncate",
                            children: selectedDeck === null || selectedDeck === void 0 ? void 0 : selectedDeck.title
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 862,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                    lineNumber: 848,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 overflow-y-auto px-4 pb-20 md:pb-24",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-center min-h-full py-6",
                            children: currentCard ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$features$2f$flashcards$2f$SwipeableFlashcard$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["SwipeableFlashcard"], {
                                front: currentCard.front,
                                back: currentCard.back,
                                example: currentCard.example,
                                exampleTranslation: currentCard.exampleTranslation,
                                onSwipeLeft: ()=>markCardAsLearned(false),
                                onSwipeRight: ()=>markCardAsLearned(true),
                                disabled: isMarking
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 870,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center text-[var(--muted)]",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "Không có thẻ nào trong bộ này"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 881,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 880,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 868,
                            columnNumber: 11
                        }, this),
                        currentCard && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-[736px] mx-auto px-4 py-4 space-y-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-center space-x-2 md:space-x-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                        variant: "outline",
                                        onClick: prevCard,
                                        disabled: currentCardIndex === 0,
                                        className: "bg-[var(--surface)] border-[var(--border)] text-[var(--muted)] hover:text-[var(--text)] focus-visible:ring-2 focus-visible:ring-[var(--ring)] rounded-xl flex-shrink-0",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 896,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 890,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                        variant: "outline",
                                        onClick: nextCard,
                                        disabled: currentCardIndex === (((_selectedDeck_cards2 = selectedDeck.cards) === null || _selectedDeck_cards2 === void 0 ? void 0 : _selectedDeck_cards2.length) || 0) - 1,
                                        className: "bg-[var(--surface)] border-[var(--border)] text-[var(--muted)] hover:text-[var(--text)] focus-visible:ring-2 focus-visible:ring-[var(--ring)] rounded-xl flex-shrink-0",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 907,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 899,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 889,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 888,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                    lineNumber: 866,
                    columnNumber: 9
                }, this),
                currentCard && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                    className: "sticky bottom-0 inset-x-0 z-40 border-t border-[var(--border)] bg-[var(--surface)]/95 backdrop-blur supports-[backdrop-filter]:bg-[var(--surface)]/80",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mx-auto max-w-[736px] px-4 py-3 pb-safe",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "w-full h-11 rounded-xl bg-amber-500 text-white font-medium hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--ring)] transition-opacity disabled:opacity-50 disabled:cursor-not-allowed",
                            onClick: generateNewExample,
                            disabled: generatingExample,
                            children: generatingExample ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                        className: "inline h-4 w-4 mr-2 animate-spin"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 927,
                                        columnNumber: 21
                                    }, this),
                                    "Đang tạo..."
                                ]
                            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: "✨ Tạo câu ví dụ khác với AI"
                            }, void 0, false)
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 920,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 919,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                    lineNumber: 918,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
            lineNumber: 846,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-dvh bg-[var(--bg)] text-[var(--text)] overflow-y-auto p-6 pb-20",
        children: [
            currentView === 'review' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$features$2f$flashcards$2f$QuickReview$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["QuickReview"], {
                learnedCards: getAllLearnedCards(),
                onComplete: handleReviewComplete,
                onBack: handleBackFromReview
            }, void 0, false, {
                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                lineNumber: 945,
                columnNumber: 9
            }, this),
            currentView === 'list' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between items-center mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "text-[var(--text)] mb-2",
                                        children: "Flashcards"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 957,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[var(--muted)]",
                                        children: "Chọn bộ thẻ để bắt đầu học"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 958,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 956,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                        onClick: handleStartQuickReview,
                                        disabled: getAllLearnedCards().length === 0,
                                        className: "bg-green-600 hover:bg-green-700 text-white rounded-xl flex items-center focus-visible:ring-2 focus-visible:ring-green-500/40",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RotateCcw$3e$__["RotateCcw"], {
                                                className: "h-4 w-4 mr-2"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                lineNumber: 966,
                                                columnNumber: 17
                                            }, this),
                                            "Ôn tập nhanh (",
                                            getAllLearnedCards().length,
                                            ")"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 961,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                        onClick: ()=>{
                                            setNewDeckTitle('');
                                            setNewDeckTopic('');
                                            setNewDeckSubject('');
                                            setGeneratedCards([
                                                {
                                                    id: "manual-card-".concat(Date.now(), "-0"),
                                                    front: '',
                                                    back: '',
                                                    example: '',
                                                    exampleTranslation: '',
                                                    learned: false
                                                }
                                            ]);
                                            setShowEditDialog(true);
                                        },
                                        className: "bg-blue-600 hover:bg-blue-700 text-white rounded-xl flex items-center focus-visible:ring-2 focus-visible:ring-blue-500/40",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                className: "h-4 w-4 mr-2"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                lineNumber: 988,
                                                columnNumber: 17
                                            }, this),
                                            "Tạo thủ công"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 969,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                        onClick: ()=>setAiDialogOpen(true),
                                        className: "bg-[var(--warning)] hover:bg-[var(--warning)]/90 text-white rounded-xl flex items-center focus-visible:ring-2 focus-visible:ring-[var(--ring)]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2d$circuit$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BrainCircuit$3e$__["BrainCircuit"], {
                                                className: "h-4 w-4 mr-2"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                lineNumber: 995,
                                                columnNumber: 17
                                            }, this),
                                            "Tạo với AI"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 991,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 960,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 955,
                        columnNumber: 11
                    }, this),
                    loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center items-center py-12",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                            className: "h-8 w-8 animate-spin text-[var(--primary)]"
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 1003,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1002,
                        columnNumber: 13
                    }, this) : decks.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-center justify-center py-12 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-gray-100 dark:bg-gray-800 rounded-full p-6 mb-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2d$circuit$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BrainCircuit$3e$__["BrainCircuit"], {
                                    className: "h-12 w-12 text-[var(--muted)]"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1008,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1007,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-medium text-[var(--text)] mb-2",
                                children: "Chưa có flashcard nào"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1010,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-[var(--muted)] mb-6 max-w-sm",
                                children: "Tạo bộ flashcard đầu tiên để bắt đầu học từ vựng hiệu quả"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1013,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex space-x-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                        onClick: ()=>{
                                            // Kiểm tra đăng nhập trước khi tạo flashcards
                                            if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) {
                                                alert('Vui lòng đăng nhập để tạo flashcards và lưu vào database!');
                                                return;
                                            }
                                            setNewDeckTitle('');
                                            setNewDeckTopic('');
                                            setNewDeckSubject('');
                                            setGeneratedCards([
                                                {
                                                    id: "manual-card-".concat(Date.now(), "-0"),
                                                    front: '',
                                                    back: '',
                                                    example: '',
                                                    exampleTranslation: '',
                                                    learned: false
                                                }
                                            ]);
                                            setShowEditDialog(true);
                                        },
                                        className: "bg-blue-600 hover:bg-blue-700 text-white rounded-xl flex items-center focus-visible:ring-2 focus-visible:ring-blue-500/40",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                className: "h-4 w-4 mr-2"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                lineNumber: 1044,
                                                columnNumber: 19
                                            }, this),
                                            "Tạo thủ công"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1017,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                        onClick: ()=>{
                                            // Kiểm tra đăng nhập trước khi tạo flashcards
                                            if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) {
                                                alert('Vui lòng đăng nhập để tạo flashcards và lưu vào database!');
                                                return;
                                            }
                                            setAiDialogOpen(true);
                                        },
                                        className: "bg-[var(--warning)] hover:bg-[var(--warning)]/90 text-white rounded-xl flex items-center focus-visible:ring-2 focus-visible:ring-[var(--ring)]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2d$circuit$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BrainCircuit$3e$__["BrainCircuit"], {
                                                className: "h-4 w-4 mr-2"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                lineNumber: 1060,
                                                columnNumber: 19
                                            }, this),
                                            "Tạo với AI"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1047,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1016,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1006,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: decks.map((deck)=>{
                            var _deck_cards;
                            const progress = deck.total > 0 ? deck.learned / deck.total * 100 : 0;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Card"], {
                                className: "bg-[var(--card)] border-[var(--border)] hover:shadow-lg transition-shadow cursor-pointer",
                                onClick: ()=>startDeck(deck),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                        className: "pb-3",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-4 h-4 rounded-full ".concat(deck.color, " mr-3")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1080,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                                                    className: "text-[var(--text)]",
                                                                    children: deck.title
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1084,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                                                    children: deck.description
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1087,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1083,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1079,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center space-x-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                            variant: "secondary",
                                                            children: [
                                                                deck.learned,
                                                                "/",
                                                                deck.total
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1093,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                                            variant: "ghost",
                                                            size: "icon",
                                                            className: "h-8 w-8 text-[var(--danger)] hover:text-[var(--danger)] hover:bg-[rgb(239_68_68/0.06)] focus-visible:ring-2 focus-visible:ring-[var(--ring)]",
                                                            onClick: (e)=>{
                                                                e.stopPropagation();
                                                                setDeckToDelete(deck);
                                                                setDeleteDialogOpen(true);
                                                            },
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                className: "h-4 w-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                lineNumber: 1106,
                                                                columnNumber: 29
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1096,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1092,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1078,
                                            columnNumber: 23
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1077,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardContent"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mb-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex justify-between text-sm mb-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-[var(--muted)]",
                                                                children: "Tiến trình"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                lineNumber: 1115,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-[var(--muted)]",
                                                                children: [
                                                                    Math.round(progress),
                                                                    "%"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                lineNumber: 1118,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                        lineNumber: 1114,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$progress$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Progress"], {
                                                        value: progress
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                        lineNumber: 1122,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                lineNumber: 1113,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                                onClick: (e)=>{
                                                    e.stopPropagation();
                                                    startDeck(deck);
                                                },
                                                className: "h-11 w-full rounded-xl bg-blue-600 text-white font-medium hover:bg-blue-700 focus-visible:ring-2 focus-visible:ring-blue-500/40",
                                                disabled: !deck.cards || deck.cards.length === 0,
                                                children: ((_deck_cards = deck.cards) === null || _deck_cards === void 0 ? void 0 : _deck_cards.length) > 0 ? 'Bắt đầu học' : 'Chưa có thẻ'
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                lineNumber: 1125,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1112,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, deck.id, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1072,
                                columnNumber: 19
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1066,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Dialog"], {
                        open: aiDialogOpen,
                        onOpenChange: setAiDialogOpen,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["DialogContent"], {
                            className: "sm:max-w-[425px] bg-[var(--surface)] border-[var(--border)] shadow-2xl",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                                            className: "text-[var(--text)]",
                                            children: "Tạo flashcards bằng AI"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1146,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["DialogDescription"], {
                                            className: "text-[var(--muted)]",
                                            children: "Nhập thông tin để AI tạo bộ flashcards mới cho bạn"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1149,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1145,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid gap-4 py-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-4 items-center gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "subject",
                                                    className: "text-right text-[var(--text)] font-medium",
                                                    children: "Môn học"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1155,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Input"], {
                                                    id: "subject",
                                                    value: newDeckSubject,
                                                    onChange: (e)=>setNewDeckSubject(e.target.value),
                                                    placeholder: "Ví dụ: Tiếng Anh, Toán học, Vật lý...",
                                                    className: "col-span-3"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1161,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1154,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-4 items-center gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "topic",
                                                    className: "text-right text-[var(--text)] font-medium",
                                                    children: "Chủ đề"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1170,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Input"], {
                                                    id: "topic",
                                                    value: newDeckTopic,
                                                    onChange: (e)=>setNewDeckTopic(e.target.value),
                                                    className: "col-span-3",
                                                    placeholder: "Từ vựng học thuật, Ngữ pháp cơ bản..."
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1176,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1169,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-4 items-center gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "title",
                                                    className: "text-right text-[var(--text)] font-medium",
                                                    children: "Tiêu đề"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1185,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Input"], {
                                                    id: "title",
                                                    value: newDeckTitle,
                                                    onChange: (e)=>setNewDeckTitle(e.target.value),
                                                    className: "col-span-3",
                                                    placeholder: "Tiêu đề cho bộ flashcards"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1191,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1184,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-4 items-center gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "cardCount",
                                                    className: "text-right text-[var(--text)] font-medium",
                                                    children: "Số lượng thẻ"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1200,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center col-span-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                                            variant: "outline",
                                                            size: "icon",
                                                            onClick: ()=>setCardCount(Math.max(1, cardCount - 1)),
                                                            className: "h-8 w-8",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__["Minus"], {
                                                                className: "h-4 w-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                lineNumber: 1213,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1207,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "w-10 text-center",
                                                            children: cardCount
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1215,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                                            variant: "outline",
                                                            size: "icon",
                                                            onClick: ()=>setCardCount(Math.min(20, cardCount + 1)),
                                                            className: "h-8 w-8",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                                className: "h-4 w-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                lineNumber: 1222,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1216,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1206,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1199,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1153,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["DialogFooter"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                        onClick: createAIFlashcards,
                                        disabled: creatingDeck || !newDeckTitle.trim() || !newDeckTopic.trim(),
                                        className: "bg-[var(--warning)] hover:bg-[var(--warning)]/90 text-white font-medium focus-visible:ring-2 focus-visible:ring-[var(--ring)]",
                                        children: creatingDeck ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                                    className: "h-4 w-4 mr-2 animate-spin"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1237,
                                                    columnNumber: 23
                                                }, this),
                                                "Đang tạo..."
                                            ]
                                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2d$circuit$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BrainCircuit$3e$__["BrainCircuit"], {
                                                    className: "h-4 w-4 mr-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1242,
                                                    columnNumber: 23
                                                }, this),
                                                "Tạo flashcards"
                                            ]
                                        }, void 0, true)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1228,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1227,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 1144,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1143,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialog"], {
                        open: deleteDialogOpen,
                        onOpenChange: setDeleteDialogOpen,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogContent"], {
                            className: "bg-[var(--surface)] border-[var(--border)] shadow-2xl",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogHeader"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogTitle"], {
                                            className: "flex items-center text-[var(--text)]",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__["AlertTriangle"], {
                                                    className: "h-5 w-5 text-[var(--danger)] mr-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1259,
                                                    columnNumber: 19
                                                }, this),
                                                "Xác nhận xóa"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1258,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogDescription"], {
                                            className: "text-[var(--muted)]",
                                            children: [
                                                'Bạn có chắc chắn muốn xóa bộ flashcard "',
                                                deckToDelete === null || deckToDelete === void 0 ? void 0 : deckToDelete.title,
                                                '"? Hành động này không thể hoàn tác và tất cả các thẻ trong bộ này sẽ bị mất.'
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1262,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1257,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogFooter"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogCancel"], {
                                            className: "text-[var(--text)] bg-[var(--surface)] border-[var(--border)] hover:bg-[var(--surface)]/80",
                                            children: "Hủy"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1270,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogAction"], {
                                            className: "bg-[var(--danger)] hover:bg-[var(--danger)]/90 text-white font-medium focus-visible:ring-2 focus-visible:ring-[var(--ring)]",
                                            onClick: ()=>handleDeleteDeck(),
                                            children: "Xóa"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1273,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1269,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 1256,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1252,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Dialog"], {
                        open: showEditDialog,
                        onOpenChange: setShowEditDialog,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["DialogContent"], {
                            className: "sm:max-w-[600px] max-h-[80vh] overflow-y-auto bg-[var(--surface)] border-[var(--border)] shadow-2xl",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                                            className: "text-[var(--text)]",
                                            children: "Chỉnh sửa flashcards"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1287,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["DialogDescription"], {
                                            className: "text-gray-600 dark:text-gray-400",
                                            children: "Chỉnh sửa các flashcard trước khi lưu vào bộ sưu tập của bạn"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1290,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1286,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-6 py-4",
                                    children: generatedCards.map((card, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "border rounded-lg p-4 space-y-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex justify-between items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-lg font-medium",
                                                            children: [
                                                                "Thẻ #",
                                                                index + 1
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1302,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center space-x-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    variant: "ghost",
                                                                    size: "icon",
                                                                    className: "h-8 w-8",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__["Edit"], {
                                                                        className: "h-4 w-4"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                        lineNumber: 1305,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1304,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    variant: "ghost",
                                                                    size: "icon",
                                                                    className: "h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50",
                                                                    onClick: ()=>{
                                                                        const updatedCards = generatedCards.filter((_, i)=>i !== index);
                                                                        setGeneratedCards(updatedCards);
                                                                    },
                                                                    disabled: generatedCards.length <= 1,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                        className: "h-4 w-4"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                        lineNumber: 1319,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1307,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1303,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1301,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid grid-cols-2 gap-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Label"], {
                                                                    htmlFor: "front-".concat(index),
                                                                    children: "Mặt trước"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1326,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Input"], {
                                                                    id: "front-".concat(index),
                                                                    value: card.front,
                                                                    onChange: (e)=>{
                                                                        const updatedCards = [
                                                                            ...generatedCards
                                                                        ];
                                                                        updatedCards[index].front = e.target.value;
                                                                        setGeneratedCards(updatedCards);
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1327,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1325,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Label"], {
                                                                    htmlFor: "back-".concat(index),
                                                                    children: "Mặt sau"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1338,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Input"], {
                                                                    id: "back-".concat(index),
                                                                    value: card.back,
                                                                    onChange: (e)=>{
                                                                        const updatedCards = [
                                                                            ...generatedCards
                                                                        ];
                                                                        updatedCards[index].back = e.target.value;
                                                                        setGeneratedCards(updatedCards);
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1339,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1337,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1324,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid grid-cols-2 gap-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Label"], {
                                                                    htmlFor: "example-".concat(index),
                                                                    children: "Ví dụ (mặt trước)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1353,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Input"], {
                                                                    id: "example-".concat(index),
                                                                    value: card.example,
                                                                    onChange: (e)=>{
                                                                        const updatedCards = [
                                                                            ...generatedCards
                                                                        ];
                                                                        updatedCards[index].example = e.target.value;
                                                                        setGeneratedCards(updatedCards);
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1356,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1352,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Label"], {
                                                                    htmlFor: "exampleTranslation-".concat(index),
                                                                    children: "Ví dụ (mặt sau)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1367,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Input"], {
                                                                    id: "exampleTranslation-".concat(index),
                                                                    value: card.exampleTranslation || '',
                                                                    onChange: (e)=>{
                                                                        const updatedCards = [
                                                                            ...generatedCards
                                                                        ];
                                                                        updatedCards[index].exampleTranslation = e.target.value;
                                                                        setGeneratedCards(updatedCards);
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                                    lineNumber: 1370,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                            lineNumber: 1366,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1351,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, card.id, true, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1297,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1295,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between mt-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                            variant: "outline",
                                            onClick: ()=>{
                                                setGeneratedCards([
                                                    ...generatedCards,
                                                    {
                                                        id: "ai-card-".concat(Date.now(), "-").concat(generatedCards.length),
                                                        front: '',
                                                        back: '',
                                                        example: '',
                                                        exampleTranslation: '',
                                                        learned: false
                                                    }
                                                ]);
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                    className: "h-4 w-4 mr-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1403,
                                                    columnNumber: 19
                                                }, this),
                                                " Thêm thẻ mới"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1387,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                            onClick: async ()=>{
                                                // Kiểm tra đăng nhập trước khi tạo flashcards
                                                if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) {
                                                    alert('Vui lòng đăng nhập để tạo flashcards và lưu vào database!');
                                                    return;
                                                }
                                                // Làm sạch và khử trùng lặp trước khi lưu
                                                const normalize = (s)=>(s || '').toLowerCase().trim().replace(/[\s\u200B\u200C\u200D\uFEFF]+/g, ' ').replace(RegExp("[^\\p{L}\\p{N}]+", "gu"), ' ');
                                                const uniqueCards = [];
                                                const seen = new Set();
                                                for (const c of generatedCards){
                                                    const front = (c.front || '').trim();
                                                    const back = (c.back || '').trim();
                                                    if (!front || !back) continue;
                                                    const key = normalize(front);
                                                    if (!seen.has(key)) {
                                                        seen.add(key);
                                                        uniqueCards.push({
                                                            ...c,
                                                            front,
                                                            back,
                                                            example: (c.example || '').trim(),
                                                            exampleTranslation: (c.exampleTranslation || '').trim(),
                                                            learned: !!c.learned
                                                        });
                                                    }
                                                }
                                                const finalCards = uniqueCards.slice(0, Math.max(1, cardCount));
                                                // Tạo deck mới
                                                const newDeck = {
                                                    title: newDeckTitle,
                                                    description: "".concat(newDeckSubject, " - ").concat(newDeckTopic),
                                                    userId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser.uid : 'local-user',
                                                    cards: finalCards,
                                                    total: finalCards.length,
                                                    learned: 0,
                                                    createdAt: new Date()
                                                };
                                                // Tạo ID và color cho deck mới
                                                let deckId = "local-".concat(Date.now());
                                                const randomColor = [
                                                    'blue',
                                                    'green',
                                                    'purple',
                                                    'pink',
                                                    'yellow'
                                                ][Math.floor(Math.random() * 5)];
                                                // Lưu vào Firestore nếu người dùng đã đăng nhập
                                                if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) {
                                                    try {
                                                        const docRef = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["addDoc"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'flashcard_decks'), newDeck);
                                                        deckId = docRef.id;
                                                    } catch (dbError) {
                                                        console.error('Error saving to database:', dbError);
                                                        // Nếu lưu Firestore thất bại, vẫn tạo deck local với ID tạm
                                                        deckId = "local-".concat(Date.now(), "-").concat(Math.random().toString(36).substr(2, 9));
                                                    }
                                                } else {
                                                    // Nếu chưa đăng nhập, tạo deck local với ID tạm
                                                    deckId = "local-".concat(Date.now(), "-").concat(Math.random().toString(36).substr(2, 9));
                                                }
                                                // Thêm deck mới vào state
                                                const deckWithColor = {
                                                    ...newDeck,
                                                    id: deckId,
                                                    color: "bg-".concat(randomColor, "-500")
                                                };
                                                setDecks([
                                                    ...decks,
                                                    deckWithColor
                                                ]);
                                                // Reset form và đóng dialog
                                                setNewDeckTitle('');
                                                setNewDeckTopic('');
                                                setShowEditDialog(false);
                                            },
                                            className: "bg-green-600 hover:bg-green-700",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__["Save"], {
                                                    className: "h-4 w-4 mr-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                                    lineNumber: 1506,
                                                    columnNumber: 19
                                                }, this),
                                                " Lưu bộ thẻ"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                            lineNumber: 1406,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1386,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 1285,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1284,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true),
            currentView === 'player' && selectedDeck && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "ghost",
                                onClick: ()=>setCurrentView('list'),
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__["ArrowLeft"], {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1524,
                                        columnNumber: 15
                                    }, this),
                                    "Quay lại"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1519,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Badge"], {
                                variant: "secondary",
                                className: "flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2d$circuit$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BrainCircuit$3e$__["BrainCircuit"], {
                                        className: "h-3 w-3"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1528,
                                        columnNumber: 15
                                    }, this),
                                    selectedDeck.title
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1527,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1518,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between text-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Tiến độ học tập"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1536,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            currentCardIndex + 1,
                                            " / ",
                                            selectedDeck.cards.length
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1537,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1535,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$progress$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Progress"], {
                                value: (currentCardIndex + 1) / selectedDeck.cards.length * 100,
                                className: "h-2"
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1541,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1534,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full max-w-md",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$features$2f$flashcards$2f$SwipeableFlashcard$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["SwipeableFlashcard"], {
                                front: ((_selectedDeck_cards_currentCardIndex = selectedDeck.cards[currentCardIndex]) === null || _selectedDeck_cards_currentCardIndex === void 0 ? void 0 : _selectedDeck_cards_currentCardIndex.front) || '',
                                back: ((_selectedDeck_cards_currentCardIndex1 = selectedDeck.cards[currentCardIndex]) === null || _selectedDeck_cards_currentCardIndex1 === void 0 ? void 0 : _selectedDeck_cards_currentCardIndex1.back) || '',
                                example: ((_selectedDeck_cards_currentCardIndex2 = selectedDeck.cards[currentCardIndex]) === null || _selectedDeck_cards_currentCardIndex2 === void 0 ? void 0 : _selectedDeck_cards_currentCardIndex2.example) || '',
                                exampleTranslation: ((_selectedDeck_cards_currentCardIndex3 = selectedDeck.cards[currentCardIndex]) === null || _selectedDeck_cards_currentCardIndex3 === void 0 ? void 0 : _selectedDeck_cards_currentCardIndex3.exampleTranslation) || '',
                                onSwipeLeft: ()=>markCardAsLearned(false),
                                onSwipeRight: ()=>markCardAsLearned(true),
                                disabled: isMarking
                            }, void 0, false, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1550,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 1549,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1548,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "outline",
                                onClick: prevCard,
                                disabled: currentCardIndex === 0,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1571,
                                        columnNumber: 15
                                    }, this),
                                    "Trước"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1566,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "outline",
                                onClick: nextCard,
                                disabled: currentCardIndex === selectedDeck.cards.length - 1,
                                children: [
                                    "Sau",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1580,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1574,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1565,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "destructive",
                                onClick: ()=>markCardAsLearned(false),
                                disabled: isMarking,
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__["XCircle"], {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1592,
                                        columnNumber: 15
                                    }, this),
                                    "Chưa thuộc"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1586,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "default",
                                onClick: ()=>markCardAsLearned(true),
                                disabled: isMarking,
                                className: "flex items-center gap-2 bg-green-600 hover:bg-green-700",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                        lineNumber: 1601,
                                        columnNumber: 15
                                    }, this),
                                    "Đã thuộc"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                lineNumber: 1595,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                        lineNumber: 1585,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                lineNumber: 1516,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialog"], {
                open: !!pendingDecision,
                onOpenChange: (open)=>{
                    if (!open) setPendingDecision(null);
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogContent"], {
                    className: "bg-[var(--surface)] border-[var(--border)] shadow-2xl",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogHeader"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogTitle"], {
                                    className: "text-[var(--text)]",
                                    children: "Xác nhận cập nhật tiến độ"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1616,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogDescription"], {
                                    className: "text-[var(--muted)]",
                                    children: (pendingDecision === null || pendingDecision === void 0 ? void 0 : pendingDecision.learned) ? 'Đánh dấu thẻ này là ĐÃ NHỚ?' : 'Đánh dấu thẻ này là CHƯA NHỚ?'
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1619,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 1615,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogFooter"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogCancel"], {
                                    className: "text-[var(--text)] bg-[var(--surface)] border-[var(--border)] hover:bg-[var(--surface)]/80",
                                    children: "Hủy"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1626,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AlertDialogAction"], {
                                    className: "bg-[var(--primary)] hover:bg-[var(--primary)]/90 text-white font-medium focus-visible:ring-2 focus-visible:ring-[var(--ring)]",
                                    onClick: ()=>{
                                        const decision = pendingDecision;
                                        setPendingDecision(null);
                                        if (decision) {
                                            void doMarkCardAsLearned(decision.learned);
                                        }
                                    },
                                    disabled: isMarking,
                                    children: "Xác nhận"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                                    lineNumber: 1629,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                            lineNumber: 1625,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                    lineNumber: 1614,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
                lineNumber: 1608,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/features/flashcards/FlashcardScreen.tsx",
        lineNumber: 942,
        columnNumber: 5
    }, this);
}
_s(FlashcardScreen, "7WN4eqSrKMpMT1Xeoqv9HhXPzrY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$LevelContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["useLevel"]
    ];
});
_c = FlashcardScreen;
var _c;
__turbopack_context__.k.register(_c, "FlashcardScreen");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_features_flashcards_8ba6827a._.js.map