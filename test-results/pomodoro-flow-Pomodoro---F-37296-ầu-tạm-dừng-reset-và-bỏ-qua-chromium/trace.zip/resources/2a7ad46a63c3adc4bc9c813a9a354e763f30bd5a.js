(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[turbopack]/browser/dev/hmr-client/hmr-client.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/// <reference path="../../../shared/runtime-types.d.ts" />
/// <reference path="../../runtime/base/dev-globals.d.ts" />
/// <reference path="../../runtime/base/dev-protocol.d.ts" />
/// <reference path="../../runtime/base/dev-extensions.ts" />
__turbopack_context__.s([
    "connect",
    ()=>connect,
    "setHooks",
    ()=>setHooks,
    "subscribeToUpdate",
    ()=>subscribeToUpdate
]);
function connect(param) {
    let { addMessageListener, sendMessage, onUpdateError = console.error } = param;
    addMessageListener((msg)=>{
        switch(msg.type){
            case 'turbopack-connected':
                handleSocketConnected(sendMessage);
                break;
            default:
                try {
                    if (Array.isArray(msg.data)) {
                        for(let i = 0; i < msg.data.length; i++){
                            handleSocketMessage(msg.data[i]);
                        }
                    } else {
                        handleSocketMessage(msg.data);
                    }
                    applyAggregatedUpdates();
                } catch (e) {
                    console.warn('[Fast Refresh] performing full reload\n\n' + "Fast Refresh will perform a full reload when you edit a file that's imported by modules outside of the React rendering tree.\n" + 'You might have a file which exports a React component but also exports a value that is imported by a non-React component file.\n' + 'Consider migrating the non-React component export to a separate file and importing it into both files.\n\n' + 'It is also possible the parent component of the component you edited is a class component, which disables Fast Refresh.\n' + 'Fast Refresh requires at least one parent function component in your React tree.');
                    onUpdateError(e);
                    location.reload();
                }
                break;
        }
    });
    const queued = globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS;
    if (queued != null && !Array.isArray(queued)) {
        throw new Error('A separate HMR handler was already registered');
    }
    globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS = {
        push: (param)=>{
            let [chunkPath, callback] = param;
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    };
    if (Array.isArray(queued)) {
        for (const [chunkPath, callback] of queued){
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    }
}
const updateCallbackSets = new Map();
function sendJSON(sendMessage, message) {
    sendMessage(JSON.stringify(message));
}
function resourceKey(resource) {
    return JSON.stringify({
        path: resource.path,
        headers: resource.headers || null
    });
}
function subscribeToUpdates(sendMessage, resource) {
    sendJSON(sendMessage, {
        type: 'turbopack-subscribe',
        ...resource
    });
    return ()=>{
        sendJSON(sendMessage, {
            type: 'turbopack-unsubscribe',
            ...resource
        });
    };
}
function handleSocketConnected(sendMessage) {
    for (const key of updateCallbackSets.keys()){
        subscribeToUpdates(sendMessage, JSON.parse(key));
    }
}
// we aggregate all pending updates until the issues are resolved
const chunkListsWithPendingUpdates = new Map();
function aggregateUpdates(msg) {
    const key = resourceKey(msg.resource);
    let aggregated = chunkListsWithPendingUpdates.get(key);
    if (aggregated) {
        aggregated.instruction = mergeChunkListUpdates(aggregated.instruction, msg.instruction);
    } else {
        chunkListsWithPendingUpdates.set(key, msg);
    }
}
function applyAggregatedUpdates() {
    if (chunkListsWithPendingUpdates.size === 0) return;
    hooks.beforeRefresh();
    for (const msg of chunkListsWithPendingUpdates.values()){
        triggerUpdate(msg);
    }
    chunkListsWithPendingUpdates.clear();
    finalizeUpdate();
}
function mergeChunkListUpdates(updateA, updateB) {
    let chunks;
    if (updateA.chunks != null) {
        if (updateB.chunks == null) {
            chunks = updateA.chunks;
        } else {
            chunks = mergeChunkListChunks(updateA.chunks, updateB.chunks);
        }
    } else if (updateB.chunks != null) {
        chunks = updateB.chunks;
    }
    let merged;
    if (updateA.merged != null) {
        if (updateB.merged == null) {
            merged = updateA.merged;
        } else {
            // Since `merged` is an array of updates, we need to merge them all into
            // one, consistent update.
            // Since there can only be `EcmascriptMergeUpdates` in the array, there is
            // no need to key on the `type` field.
            let update = updateA.merged[0];
            for(let i = 1; i < updateA.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateA.merged[i]);
            }
            for(let i = 0; i < updateB.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateB.merged[i]);
            }
            merged = [
                update
            ];
        }
    } else if (updateB.merged != null) {
        merged = updateB.merged;
    }
    return {
        type: 'ChunkListUpdate',
        chunks,
        merged
    };
}
function mergeChunkListChunks(chunksA, chunksB) {
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    return chunks;
}
function mergeChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted' || updateA.type === 'deleted' && updateB.type === 'added') {
        return undefined;
    }
    if (updateA.type === 'partial') {
        invariant(updateA.instruction, 'Partial updates are unsupported');
    }
    if (updateB.type === 'partial') {
        invariant(updateB.instruction, 'Partial updates are unsupported');
    }
    return undefined;
}
function mergeChunkListEcmascriptMergedUpdates(mergedA, mergedB) {
    const entries = mergeEcmascriptChunkEntries(mergedA.entries, mergedB.entries);
    const chunks = mergeEcmascriptChunksUpdates(mergedA.chunks, mergedB.chunks);
    return {
        type: 'EcmascriptMergedUpdate',
        entries,
        chunks
    };
}
function mergeEcmascriptChunkEntries(entriesA, entriesB) {
    return {
        ...entriesA,
        ...entriesB
    };
}
function mergeEcmascriptChunksUpdates(chunksA, chunksB) {
    if (chunksA == null) {
        return chunksB;
    }
    if (chunksB == null) {
        return chunksA;
    }
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeEcmascriptChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    if (Object.keys(chunks).length === 0) {
        return undefined;
    }
    return chunks;
}
function mergeEcmascriptChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted') {
        // These two completely cancel each other out.
        return undefined;
    }
    if (updateA.type === 'deleted' && updateB.type === 'added') {
        const added = [];
        const deleted = [];
        var _updateA_modules;
        const deletedModules = new Set((_updateA_modules = updateA.modules) !== null && _updateA_modules !== void 0 ? _updateA_modules : []);
        var _updateB_modules;
        const addedModules = new Set((_updateB_modules = updateB.modules) !== null && _updateB_modules !== void 0 ? _updateB_modules : []);
        for (const moduleId of addedModules){
            if (!deletedModules.has(moduleId)) {
                added.push(moduleId);
            }
        }
        for (const moduleId of deletedModules){
            if (!addedModules.has(moduleId)) {
                deleted.push(moduleId);
            }
        }
        if (added.length === 0 && deleted.length === 0) {
            return undefined;
        }
        return {
            type: 'partial',
            added,
            deleted
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'partial') {
        var _updateA_added, _updateB_added;
        const added = new Set([
            ...(_updateA_added = updateA.added) !== null && _updateA_added !== void 0 ? _updateA_added : [],
            ...(_updateB_added = updateB.added) !== null && _updateB_added !== void 0 ? _updateB_added : []
        ]);
        var _updateA_deleted, _updateB_deleted;
        const deleted = new Set([
            ...(_updateA_deleted = updateA.deleted) !== null && _updateA_deleted !== void 0 ? _updateA_deleted : [],
            ...(_updateB_deleted = updateB.deleted) !== null && _updateB_deleted !== void 0 ? _updateB_deleted : []
        ]);
        if (updateB.added != null) {
            for (const moduleId of updateB.added){
                deleted.delete(moduleId);
            }
        }
        if (updateB.deleted != null) {
            for (const moduleId of updateB.deleted){
                added.delete(moduleId);
            }
        }
        return {
            type: 'partial',
            added: [
                ...added
            ],
            deleted: [
                ...deleted
            ]
        };
    }
    if (updateA.type === 'added' && updateB.type === 'partial') {
        var _updateA_modules1, _updateB_added1;
        const modules = new Set([
            ...(_updateA_modules1 = updateA.modules) !== null && _updateA_modules1 !== void 0 ? _updateA_modules1 : [],
            ...(_updateB_added1 = updateB.added) !== null && _updateB_added1 !== void 0 ? _updateB_added1 : []
        ]);
        var _updateB_deleted1;
        for (const moduleId of (_updateB_deleted1 = updateB.deleted) !== null && _updateB_deleted1 !== void 0 ? _updateB_deleted1 : []){
            modules.delete(moduleId);
        }
        return {
            type: 'added',
            modules: [
                ...modules
            ]
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'deleted') {
        var _updateB_modules1;
        // We could eagerly return `updateB` here, but this would potentially be
        // incorrect if `updateA` has added modules.
        const modules = new Set((_updateB_modules1 = updateB.modules) !== null && _updateB_modules1 !== void 0 ? _updateB_modules1 : []);
        if (updateA.added != null) {
            for (const moduleId of updateA.added){
                modules.delete(moduleId);
            }
        }
        return {
            type: 'deleted',
            modules: [
                ...modules
            ]
        };
    }
    // Any other update combination is invalid.
    return undefined;
}
function invariant(_, message) {
    throw new Error("Invariant: ".concat(message));
}
const CRITICAL = [
    'bug',
    'error',
    'fatal'
];
function compareByList(list, a, b) {
    const aI = list.indexOf(a) + 1 || list.length;
    const bI = list.indexOf(b) + 1 || list.length;
    return aI - bI;
}
const chunksWithIssues = new Map();
function emitIssues() {
    const issues = [];
    const deduplicationSet = new Set();
    for (const [_, chunkIssues] of chunksWithIssues){
        for (const chunkIssue of chunkIssues){
            if (deduplicationSet.has(chunkIssue.formatted)) continue;
            issues.push(chunkIssue);
            deduplicationSet.add(chunkIssue.formatted);
        }
    }
    sortIssues(issues);
    hooks.issues(issues);
}
function handleIssues(msg) {
    const key = resourceKey(msg.resource);
    let hasCriticalIssues = false;
    for (const issue of msg.issues){
        if (CRITICAL.includes(issue.severity)) {
            hasCriticalIssues = true;
        }
    }
    if (msg.issues.length > 0) {
        chunksWithIssues.set(key, msg.issues);
    } else if (chunksWithIssues.has(key)) {
        chunksWithIssues.delete(key);
    }
    emitIssues();
    return hasCriticalIssues;
}
const SEVERITY_ORDER = [
    'bug',
    'fatal',
    'error',
    'warning',
    'info',
    'log'
];
const CATEGORY_ORDER = [
    'parse',
    'resolve',
    'code generation',
    'rendering',
    'typescript',
    'other'
];
function sortIssues(issues) {
    issues.sort((a, b)=>{
        const first = compareByList(SEVERITY_ORDER, a.severity, b.severity);
        if (first !== 0) return first;
        return compareByList(CATEGORY_ORDER, a.category, b.category);
    });
}
const hooks = {
    beforeRefresh: ()=>{},
    refresh: ()=>{},
    buildOk: ()=>{},
    issues: (_issues)=>{}
};
function setHooks(newHooks) {
    Object.assign(hooks, newHooks);
}
function handleSocketMessage(msg) {
    sortIssues(msg.issues);
    handleIssues(msg);
    switch(msg.type){
        case 'issues':
            break;
        case 'partial':
            // aggregate updates
            aggregateUpdates(msg);
            break;
        default:
            // run single update
            const runHooks = chunkListsWithPendingUpdates.size === 0;
            if (runHooks) hooks.beforeRefresh();
            triggerUpdate(msg);
            if (runHooks) finalizeUpdate();
            break;
    }
}
function finalizeUpdate() {
    hooks.refresh();
    hooks.buildOk();
    // This is used by the Next.js integration test suite to notify it when HMR
    // updates have been completed.
    // TODO: Only run this in test environments (gate by `process.env.__NEXT_TEST_MODE`)
    if (globalThis.__NEXT_HMR_CB) {
        globalThis.__NEXT_HMR_CB();
        globalThis.__NEXT_HMR_CB = null;
    }
}
function subscribeToChunkUpdate(chunkListPath, sendMessage, callback) {
    return subscribeToUpdate({
        path: chunkListPath
    }, sendMessage, callback);
}
function subscribeToUpdate(resource, sendMessage, callback) {
    const key = resourceKey(resource);
    let callbackSet;
    const existingCallbackSet = updateCallbackSets.get(key);
    if (!existingCallbackSet) {
        callbackSet = {
            callbacks: new Set([
                callback
            ]),
            unsubscribe: subscribeToUpdates(sendMessage, resource)
        };
        updateCallbackSets.set(key, callbackSet);
    } else {
        existingCallbackSet.callbacks.add(callback);
        callbackSet = existingCallbackSet;
    }
    return ()=>{
        callbackSet.callbacks.delete(callback);
        if (callbackSet.callbacks.size === 0) {
            callbackSet.unsubscribe();
            updateCallbackSets.delete(key);
        }
    };
}
function triggerUpdate(msg) {
    const key = resourceKey(msg.resource);
    const callbackSet = updateCallbackSets.get(key);
    if (!callbackSet) {
        return;
    }
    for (const callback of callbackSet.callbacks){
        callback(msg);
    }
    if (msg.type === 'notFound') {
        // This indicates that the resource which we subscribed to either does not exist or
        // has been deleted. In either case, we should clear all update callbacks, so if a
        // new subscription is created for the same resource, it will send a new "subscribe"
        // message to the server.
        // No need to send an "unsubscribe" message to the server, it will have already
        // dropped the update stream before sending the "notFound" message.
        updateCallbackSets.delete(key);
    }
}
}),
"[project]/src/components/ui/error-boundary.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ErrorBoundary",
    ()=>ErrorBoundary
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
;
;
;
class ErrorBoundary extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Component"] {
    static getDerivedStateFromError(error) {
        return {
            hasError: true,
            error
        };
    }
    componentDidCatch(error, errorInfo) {
        console.error('ErrorBoundary caught an error:', error, errorInfo);
        // Call the onError callback if provided
        if (this.props.onError) {
            this.props.onError(error, errorInfo);
        }
    }
    render() {
        if (this.state.hasError) {
            if (this.props.fallback) {
                return this.props.fallback;
            }
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center justify-center min-h-screen p-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-md text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-2xl font-bold text-red-600 mb-4",
                            children: "Oops! Something went wrong"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/error-boundary.tsx",
                            lineNumber: 41,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-600 dark:text-gray-300 mb-6",
                            children: "We encountered an unexpected error. Please try refreshing the page."
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/error-boundary.tsx",
                            lineNumber: 44,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>window.location.reload(),
                            className: "px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors",
                            children: "Refresh Page"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/error-boundary.tsx",
                            lineNumber: 48,
                            columnNumber: 13
                        }, this),
                        ("TURBOPACK compile-time value", "development") === 'development' && this.state.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                            className: "mt-4 text-left",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                    className: "cursor-pointer text-sm text-gray-500 dark:text-gray-400",
                                    children: "Error Details (Development)"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/error-boundary.tsx",
                                    lineNumber: 56,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                                    className: "mt-2 p-2 bg-gray-100 dark:bg-gray-800 rounded text-xs overflow-auto",
                                    children: this.state.error.toString()
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/error-boundary.tsx",
                                    lineNumber: 59,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ui/error-boundary.tsx",
                            lineNumber: 55,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/error-boundary.tsx",
                    lineNumber: 40,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ui/error-boundary.tsx",
                lineNumber: 39,
                columnNumber: 9
            }, this);
        }
        return this.props.children;
    }
    constructor(...args){
        super(...args), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__["_"])(this, "state", {
            hasError: false
        });
    }
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/firebase/config.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "appClient",
    ()=>appClient,
    "auth",
    ()=>auth,
    "db",
    ()=>db,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/app/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/app/dist/esm/index.esm.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/auth/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/auth/dist/esm/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
;
;
;
// Firebase configuration
const firebaseConfig = {
    apiKey: ("TURBOPACK compile-time value", "AIzaSyDwyj9ywmKxfQZJiIMCzfFg0Q8rhH-cAEc"),
    authDomain: ("TURBOPACK compile-time value", "auth.tdatdev.software"),
    projectId: ("TURBOPACK compile-time value", "vitisme-7e546"),
    storageBucket: ("TURBOPACK compile-time value", "vitisme-7e546.appspot.com"),
    messagingSenderId: ("TURBOPACK compile-time value", "213694170604"),
    appId: ("TURBOPACK compile-time value", "1:213694170604:web:007e3e328d7e8d1a85acc9"),
    measurementId: ("TURBOPACK compile-time value", "G-9NZ9RX2GQL")
};
// Chỉ khởi tạo Firebase trên trình duyệt hoặc khi có đủ biến môi trường.
const isBrowser = "object" !== 'undefined';
let app;
let authInstance;
let dbInstance;
try {
    const hasEnv = Boolean(firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId && firebaseConfig.appId);
    if (isBrowser && hasEnv) {
        // Kiểm tra xem đã có app nào chưa
        const existingApps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getApps"])();
        if (existingApps.length > 0) {
            app = existingApps[0];
        } else {
            app = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["initializeApp"])(firebaseConfig);
        }
        authInstance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getAuth"])(app);
        dbInstance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getFirestore"])(app);
        console.log('Firebase initialized successfully');
    } else {
        console.warn('Firebase not initialized - missing environment variables or not in browser');
    }
} catch (error) {
    console.error('Firebase initialization error:', error);
// Bỏ qua khi build server/CI không có env, tránh crash do auth/invalid-api-key
}
const appClient = app;
const auth = authInstance; // chỉ dùng ở client
const db = dbInstance; // chỉ dùng ở client
const __TURBOPACK__default__export__ = appClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/firebase/client.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "firebase",
    ()=>firebase,
    "firebaseAuth",
    ()=>firebaseAuth,
    "firestore",
    ()=>firestore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/auth/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/auth/dist/esm/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
;
;
;
const firebaseAuth = {
    // Đăng nhập bằng email và mật khẩu
    signInWithPassword: async (email, password)=>{
        try {
            const userCredential = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["signInWithEmailAndPassword"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], email, password);
            return {
                data: {
                    session: {
                        user: userCredential.user,
                        access_token: await userCredential.user.getIdToken()
                    }
                },
                error: null
            };
        } catch (error) {
            return {
                data: {
                    session: null
                },
                error
            };
        }
    },
    // Đăng ký tài khoản mới
    signUp: async (email, password)=>{
        try {
            const userCredential = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createUserWithEmailAndPassword"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], email, password);
            return {
                data: {
                    user: userCredential.user,
                    session: {
                        access_token: await userCredential.user.getIdToken()
                    }
                },
                error: null
            };
        } catch (error) {
            return {
                data: {
                    user: null,
                    session: null
                },
                error
            };
        }
    },
    // Đăng nhập với Google
    signInWithOAuth: async (param)=>{
        let { provider } = param;
        try {
            if (provider === 'google') {
                const googleProvider = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["GoogleAuthProvider"]();
                googleProvider.setCustomParameters({
                    prompt: 'select_account'
                });
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["signInWithPopup"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], googleProvider);
                return {
                    data: result,
                    error: null
                };
            }
            throw new Error("Unsupported provider: ".concat(provider));
        } catch (error) {
            return {
                data: null,
                error
            };
        }
    },
    // Đăng xuất
    signOut: async ()=>{
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["signOut"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"]);
            return {
                error: null
            };
        } catch (error) {
            return {
                error
            };
        }
    },
    // Lấy phiên hiện tại
    getSession: async ()=>{
        return new Promise((resolve)=>{
            const unsubscribe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["onAuthStateChanged"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], async (user)=>{
                unsubscribe();
                if (user) {
                    try {
                        const token = await user.getIdToken(true); // Force refresh token
                        resolve({
                            data: {
                                session: {
                                    user: user,
                                    access_token: token
                                }
                            },
                            error: null
                        });
                    } catch (error) {
                        resolve({
                            data: {
                                session: null
                            },
                            error
                        });
                    }
                } else {
                    resolve({
                        data: {
                            session: null
                        },
                        error: null
                    });
                }
            });
        });
    },
    // Theo dõi thay đổi trạng thái xác thực
    onAuthStateChange: (callback)=>{
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["onAuthStateChanged"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], callback);
    }
};
const firestore = {
    // Lấy thông tin profile người dùng
    getProfile: async (userId)=>{
        try {
            const docRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'profiles', userId);
            const docSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(docRef);
            if (docSnap.exists()) {
                return {
                    profile: docSnap.data(),
                    error: null
                };
            } else {
                return {
                    profile: null,
                    error: null
                };
            }
        } catch (error) {
            return {
                profile: null,
                error
            };
        }
    },
    // Cập nhật thông tin profile người dùng
    updateProfile: async (userId, data)=>{
        try {
            const docRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'profiles', userId);
            const docSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(docRef);
            if (docSnap.exists()) {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(docRef, data);
            } else {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(docRef, data);
            }
            return {
                error: null
            };
        } catch (error) {
            return {
                error
            };
        }
    },
    // Lấy danh sách flashcard
    getFlashcards: async (userId)=>{
        try {
            const decksRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'flashcard_decks');
            const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(decksRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId));
            const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
            const decks = [];
            querySnapshot.forEach((doc)=>{
                decks.push({
                    id: doc.id,
                    ...doc.data()
                });
            });
            return {
                decks,
                error: null
            };
        } catch (error) {
            return {
                decks: [],
                error
            };
        }
    },
    // Lấy danh sách habits
    getHabits: async (userId)=>{
        try {
            const habitsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habits');
            const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(habitsRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId));
            const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
            const habits = [];
            querySnapshot.forEach((doc)=>{
                habits.push({
                    id: doc.id,
                    ...doc.data()
                });
            });
            return {
                habits,
                error: null
            };
        } catch (error) {
            return {
                habits: [],
                error
            };
        }
    },
    // Cập nhật tiến độ học tập
    updateProgress: async (userId, data)=>{
        try {
            const today = new Date().toISOString().split('T')[0];
            const progressRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'progress', "".concat(userId, "_").concat(today));
            const docSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(progressRef);
            if (docSnap.exists()) {
                const currentData = docSnap.data();
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(progressRef, {
                    wordsLearned: (currentData.wordsLearned || 0) + (data.wordsLearned || 0),
                    studyTime: (currentData.studyTime || 0) + (data.studyTime || 0),
                    lastUpdated: new Date()
                });
            } else {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setDoc"])(progressRef, {
                    userId,
                    date: today,
                    wordsLearned: data.wordsLearned || 0,
                    studyTime: data.studyTime || 0,
                    createdAt: new Date(),
                    lastUpdated: new Date()
                });
            }
            // Cập nhật profile
            const userRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'profiles', userId);
            const userSnap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(userRef);
            if (userSnap.exists()) {
                const userData = userSnap.data();
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(userRef, {
                    todayProgress: (userData.todayProgress || 0) + (data.wordsLearned || 0),
                    totalWordsLearned: (userData.totalWordsLearned || 0) + (data.wordsLearned || 0),
                    lastActive: new Date()
                });
            }
            return {
                error: null
            };
        } catch (error) {
            return {
                error
            };
        }
    }
};
const firebase = {
    auth: firebaseAuth,
    firestore: firestore
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/error.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AppError",
    ()=>AppError,
    "handleError",
    ()=>handleError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [client] (ecmascript)");
;
class AppError extends Error {
    static isAppError(error) {
        return error && error.name === 'AppError';
    }
    static from(error) {
        let defaultMessage = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'Đã xảy ra lỗi';
        if (AppError.isAppError(error)) {
            return error;
        }
        if (error instanceof Error) {
            return new AppError(error.message, 'UNKNOWN_ERROR', {
                originalError: error.name
            });
        }
        return new AppError(defaultMessage, 'UNKNOWN_ERROR');
    }
    static auth() {
        let message = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Xác thực thất bại', context = arguments.length > 1 ? arguments[1] : void 0;
        return new AppError(message, 'AUTH_ERROR', context);
    }
    static network() {
        let message = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Lỗi kết nối mạng', context = arguments.length > 1 ? arguments[1] : void 0;
        return new AppError(message, 'NETWORK_ERROR', context);
    }
    static validation() {
        let message = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Dữ liệu không hợp lệ', context = arguments.length > 1 ? arguments[1] : void 0;
        return new AppError(message, 'VALIDATION_ERROR', context);
    }
    static notFound() {
        let message = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Không tìm thấy tài nguyên', context = arguments.length > 1 ? arguments[1] : void 0;
        return new AppError(message, 'NOT_FOUND', context);
    }
    static server() {
        let message = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Lỗi máy chủ', context = arguments.length > 1 ? arguments[1] : void 0;
        return new AppError(message, 'SERVER_ERROR', context);
    }
    constructor(message, code = 'UNKNOWN_ERROR', context){
        super(message), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__["_"])(this, "code", void 0), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__["_"])(this, "context", void 0), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__["_"])(this, "isOperational", void 0);
        this.name = 'AppError';
        this.code = code;
        this.context = context;
        this.isOperational = true; // Mặc định là lỗi hoạt động (có thể xử lý)
    }
}
function handleError(error, options) {
    const { showToast: _showToast = false, logToConsole = true } = options || {};
    const appError = AppError.from(error);
    // Chỉ log trong môi trường development
    if (logToConsole && ("TURBOPACK compile-time value", "development") === 'development') {
        console.error('Application error:', appError);
    }
    return appError;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useErrorHandler.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useErrorHandler",
    ()=>useErrorHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$error$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/error.ts [client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useErrorHandler(options) {
    _s();
    const { showToast = true, logToConsole = true, captureToSentry = ("TURBOPACK compile-time value", "development") === 'production' } = options || {};
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    /**
   * Xử lý lỗi
   * @param err Lỗi cần xử lý
   */ const handleAppError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useErrorHandler.useCallback[handleAppError]": (err)=>{
            const appError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$error$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["handleError"])(err);
            setError(appError);
            if (logToConsole) {
                // Chỉ log trong môi trường development
                if ("TURBOPACK compile-time truthy", 1) {
                    console.error('Application error:', appError);
                }
            }
            if (showToast) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["toast"].error(appError.message);
            }
            if (captureToSentry && !appError.isOperational) {
            // Gửi lỗi đến Sentry hoặc dịch vụ theo dõi lỗi khác
            // Sentry.captureException(appError);
            }
            return appError;
        }
    }["useErrorHandler.useCallback[handleAppError]"], [
        showToast,
        logToConsole,
        captureToSentry
    ]);
    /**
   * Bọc một hàm async với xử lý lỗi và trạng thái loading
   * @param fn Hàm async cần bọc
   * @returns Hàm đã được bọc
   */ const withErrorHandling = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useErrorHandler.useCallback[withErrorHandling]": (fn)=>{
            return ({
                "useErrorHandler.useCallback[withErrorHandling]": async function() {
                    for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                        args[_key] = arguments[_key];
                    }
                    setIsLoading(true);
                    setError(null);
                    try {
                        const result = await fn(...args);
                        return result;
                    } catch (err) {
                        handleAppError(err);
                        return undefined;
                    } finally{
                        setIsLoading(false);
                    }
                }
            })["useErrorHandler.useCallback[withErrorHandling]"];
        }
    }["useErrorHandler.useCallback[withErrorHandling]"], [
        handleAppError
    ]);
    /**
   * Xóa lỗi hiện tại
   */ const clearError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useErrorHandler.useCallback[clearError]": ()=>{
            setError(null);
        }
    }["useErrorHandler.useCallback[clearError]"], []);
    return {
        error,
        isLoading,
        handleError: handleAppError,
        withErrorHandling,
        clearError
    };
}
_s(useErrorHandler, "3njq48uetIMIIr7ZXOaACSPGVsY=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/AuthContext.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/auth/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/auth/dist/esm/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/client.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useErrorHandler$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useErrorHandler.ts [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function AuthProvider(param) {
    let { children } = param;
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const { handleError, withErrorHandling } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useErrorHandler$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["useErrorHandler"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            // Listen for auth state changes
            const unsubscribe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["onAuthStateChanged"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], {
                "AuthProvider.useEffect.unsubscribe": async (firebaseUser)=>{
                    if (firebaseUser) {
                        try {
                            await loadUserProfile(firebaseUser);
                        } catch (error) {
                            handleError(error);
                            setUser(null);
                        } finally{
                            setLoading(false);
                        }
                    } else {
                        setUser(null);
                        setLoading(false);
                    }
                }
            }["AuthProvider.useEffect.unsubscribe"]);
            return ({
                "AuthProvider.useEffect": ()=>unsubscribe()
            })["AuthProvider.useEffect"];
        }
    }["AuthProvider.useEffect"], [
        handleError
    ]);
    const loadUserProfile = async (firebaseUser)=>{
        try {
            // Sử dụng as any để tránh lỗi TypeScript với getIdToken
            // Không force refresh để tránh network issues
            const token = await firebaseUser.getIdToken(false);
            // Add timeout to prevent hanging requests
            const timeoutPromise = new Promise((_, reject)=>setTimeout(()=>reject(new Error('Profile load timeout')), 10000));
            const profilePromise = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].firestore.getProfile(firebaseUser.uid);
            const { profile } = await Promise.race([
                profilePromise,
                timeoutPromise
            ]);
            if (profile) {
                setUser({
                    uid: firebaseUser.uid,
                    name: profile.name || firebaseUser.displayName || 'User',
                    email: profile.email || firebaseUser.email || '',
                    accessToken: token,
                    streak: profile.streak || 0,
                    todayProgress: profile.todayProgress || 0,
                    dailyGoal: profile.dailyGoal || 20,
                    totalWordsLearned: profile.totalWordsLearned || 0,
                    photoURL: profile.photoURL || firebaseUser.photoURL || undefined
                });
            } else {
                var _firebaseUser_email;
                // Create default profile if it doesn't exist
                const defaultProfile = {
                    uid: firebaseUser.uid,
                    name: firebaseUser.displayName || ((_firebaseUser_email = firebaseUser.email) === null || _firebaseUser_email === void 0 ? void 0 : _firebaseUser_email.split('@')[0]) || 'User',
                    email: firebaseUser.email || '',
                    accessToken: token,
                    streak: 0,
                    todayProgress: 0,
                    dailyGoal: 20,
                    totalWordsLearned: 0,
                    photoURL: firebaseUser.photoURL || undefined
                };
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].firestore.updateProfile(firebaseUser.uid, defaultProfile);
                setUser(defaultProfile);
            }
        } catch (error) {
            var _firebaseUser_email1;
            console.error('Error loading user profile:', error);
            // Fallback to basic user info if profile loading fails
            setUser({
                uid: firebaseUser.uid,
                name: firebaseUser.displayName || ((_firebaseUser_email1 = firebaseUser.email) === null || _firebaseUser_email1 === void 0 ? void 0 : _firebaseUser_email1.split('@')[0]) || 'User',
                email: firebaseUser.email || '',
                accessToken: '',
                streak: 0,
                todayProgress: 0,
                dailyGoal: 20,
                totalWordsLearned: 0,
                photoURL: firebaseUser.photoURL || undefined
            });
        } finally{
            setLoading(false);
        }
    };
    const signIn = withErrorHandling(async (email, password)=>{
        setLoading(true);
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].auth.signInWithPassword(email, password);
        if (result.error) {
            throw result.error;
        }
    });
    const signUp = withErrorHandling(async (email, password)=>{
        setLoading(true);
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].auth.signUp(email, password);
        if (result.error) {
            throw result.error;
        }
    });
    const signInWithGoogle = withErrorHandling(async ()=>{
        setLoading(true);
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].auth.signInWithOAuth({
            provider: 'google'
        });
        if (result.error) {
            throw result.error;
        }
    });
    const signOut = withErrorHandling(async ()=>{
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].auth.signOut();
        setUser(null);
    });
    const updateUserProfile = withErrorHandling(async (data)=>{
        if (!user) return;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].firestore.updateProfile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser.uid, data);
        setUser((prev)=>prev ? {
                ...prev,
                ...data
            } : null);
    });
    const value = {
        user,
        loading,
        signIn,
        signUp,
        signInWithGoogle,
        signOut,
        updateUserProfile
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/AuthContext.tsx",
        lineNumber: 182,
        columnNumber: 10
    }, this);
}
_s(AuthProvider, "5eDTBRM+HYHogO+MmieeT7YF3VI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useErrorHandler$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["useErrorHandler"]
    ];
});
_c = AuthProvider;
function useAuth() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
_s1(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/AppStateContext.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AppStateProvider",
    ()=>AppStateProvider,
    "useAppState",
    ()=>useAppState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
const initialState = {
    currentScreen: 'welcome',
    currentTab: 'home',
    hasSeenOnboarding: false,
    flashcardDecks: [],
    habits: [],
    isLoading: {}
};
const AppStateContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function AppStateProvider(param) {
    let { children } = param;
    _s();
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])({
        "AppStateProvider.useState": ()=>{
            // Khởi tạo state từ localStorage nếu có
            if ("TURBOPACK compile-time truthy", 1) {
                const onboardingSeen = localStorage.getItem('hasSeenOnboarding') === 'true';
                return {
                    ...initialState,
                    hasSeenOnboarding: onboardingSeen
                };
            }
            //TURBOPACK unreachable
            ;
        }
    }["AppStateProvider.useState"]);
    const setCurrentScreen = (screen)=>{
        setState((prev)=>({
                ...prev,
                currentScreen: screen
            }));
    };
    const setCurrentTab = (tab)=>{
        setState((prev)=>({
                ...prev,
                currentTab: tab
            }));
    };
    const setHasSeenOnboarding = (seen)=>{
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.setItem('hasSeenOnboarding', seen.toString());
        }
        setState((prev)=>({
                ...prev,
                hasSeenOnboarding: seen
            }));
    };
    const setFlashcardDecks = (decks)=>{
        setState((prev)=>({
                ...prev,
                flashcardDecks: decks
            }));
    };
    const setHabits = (habits)=>{
        setState((prev)=>({
                ...prev,
                habits: habits
            }));
    };
    const setLoading = (key, isLoading)=>{
        setState((prev)=>({
                ...prev,
                isLoading: {
                    ...prev.isLoading,
                    [key]: isLoading
                }
            }));
    };
    const value = {
        state,
        setCurrentScreen,
        setCurrentTab,
        setHasSeenOnboarding,
        setFlashcardDecks,
        setHabits,
        setLoading
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AppStateContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/AppStateContext.tsx",
        lineNumber: 101,
        columnNumber: 5
    }, this);
}
_s(AppStateProvider, "LfM38S4nkWd7GSUUbDib1ReXq6Y=");
_c = AppStateProvider;
function useAppState() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useContext"])(AppStateContext);
    if (context === undefined) {
        throw new Error('useAppState must be used within an AppStateProvider');
    }
    return context;
}
_s1(useAppState, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AppStateProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/level/levelSystem.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LEVEL_THRESHOLDS",
    ()=>LEVEL_THRESHOLDS,
    "XP_ACTIONS",
    ()=>XP_ACTIONS,
    "addXP",
    ()=>addXP,
    "calculateLevel",
    ()=>calculateLevel,
    "getLevelColor",
    ()=>getLevelColor,
    "getLevelIcon",
    ()=>getLevelIcon,
    "getLevelInfo",
    ()=>getLevelInfo,
    "getProgressText",
    ()=>getProgressText,
    "getXPProgress",
    ()=>getXPProgress
]);
const XP_ACTIONS = {
    COMPLETE_FLASHCARD: {
        amount: 5,
        description: 'Hoàn thành flashcard'
    },
    COMPLETE_POMODORO: {
        amount: 25,
        description: 'Hoàn thành phiên pomodoro'
    },
    CHAT_WITH_AI: {
        amount: 3,
        description: 'Trò chuyện với AI'
    },
    COMPLETE_HABIT: {
        amount: 10,
        description: 'Hoàn thành thói quen hàng ngày'
    },
    CREATE_FLASHCARD_DECK: {
        amount: 15,
        description: 'Tạo bộ flashcard mới'
    },
    DAILY_LOGIN: {
        amount: 5,
        description: 'Đăng nhập hàng ngày'
    },
    STREAK_BONUS_3: {
        amount: 20,
        description: 'Bonus 3 ngày liên tiếp'
    },
    STREAK_BONUS_7: {
        amount: 50,
        description: 'Bonus 7 ngày liên tiếp'
    },
    STREAK_BONUS_30: {
        amount: 200,
        description: 'Bonus 30 ngày liên tiếp'
    }
};
const LEVEL_THRESHOLDS = [
    {
        level: 1,
        xpRequired: 0,
        title: 'Người mới bắt đầu'
    },
    {
        level: 2,
        xpRequired: 100,
        title: 'Học viên tập sự'
    },
    {
        level: 3,
        xpRequired: 250,
        title: 'Học viên chăm chỉ'
    },
    {
        level: 4,
        xpRequired: 500,
        title: 'Học sinh giỏi'
    },
    {
        level: 5,
        xpRequired: 800,
        title: 'Học sinh xuất sắc'
    },
    {
        level: 6,
        xpRequired: 1200,
        title: 'Chuyên gia nhỏ'
    },
    {
        level: 7,
        xpRequired: 1700,
        title: 'Chuyên gia'
    },
    {
        level: 8,
        xpRequired: 2300,
        title: 'Cao thủ'
    },
    {
        level: 9,
        xpRequired: 3000,
        title: 'Bậc thầy'
    },
    {
        level: 10,
        xpRequired: 4000,
        title: 'Đại sư'
    },
    {
        level: 11,
        xpRequired: 5200,
        title: 'Truyền thuyết'
    },
    {
        level: 12,
        xpRequired: 6600,
        title: 'Huyền thoại'
    },
    {
        level: 13,
        xpRequired: 8200,
        title: 'Thần thoại'
    },
    {
        level: 14,
        xpRequired: 10000,
        title: 'Vô địch thiên hạ'
    },
    {
        level: 15,
        xpRequired: 12000,
        title: 'Siêu phàm'
    }
];
function calculateLevel(totalXP) {
    let userLevel = LEVEL_THRESHOLDS[0];
    // Tìm level hiện tại
    for(let i = LEVEL_THRESHOLDS.length - 1; i >= 0; i--){
        if (totalXP >= LEVEL_THRESHOLDS[i].xpRequired) {
            userLevel = LEVEL_THRESHOLDS[i];
            break;
        }
    }
    // Tìm level tiếp theo
    const nextLevelIndex = LEVEL_THRESHOLDS.findIndex((l)=>l.level === userLevel.level + 1);
    const nextLevel = nextLevelIndex !== -1 ? LEVEL_THRESHOLDS[nextLevelIndex] : null;
    const currentLevelXP = userLevel.xpRequired;
    const nextLevelXP = (nextLevel === null || nextLevel === void 0 ? void 0 : nextLevel.xpRequired) || totalXP;
    const currentXP = totalXP - currentLevelXP;
    const xpToNextLevel = nextLevelXP - totalXP;
    return {
        level: userLevel.level,
        currentXP: Math.max(0, currentXP),
        xpToNextLevel: Math.max(0, xpToNextLevel),
        totalXP,
        title: userLevel.title
    };
}
function addXP(currentTotalXP, xpGain) {
    const oldLevel = calculateLevel(currentTotalXP);
    const newTotalXP = currentTotalXP + xpGain;
    const newLevel = calculateLevel(newTotalXP);
    return {
        oldLevel,
        newLevel,
        levelUp: newLevel.level > oldLevel.level,
        xpGained: xpGain
    };
}
function getLevelInfo(level) {
    // Import React icons locally if needed or use emoji
    const levelData = LEVEL_THRESHOLDS.find((l)=>l.level === level) || LEVEL_THRESHOLDS[0];
    // Define icon classes based on level for now, can be improved with actual React icons
    let iconClass = 'User';
    let bgColor = 'bg-gray-100';
    let color = 'text-gray-600';
    if (level >= 15) {
        iconClass = 'Crown';
        bgColor = 'bg-purple-100';
        color = 'text-purple-600';
    } else if (level >= 12) {
        iconClass = 'Trophy';
        bgColor = 'bg-yellow-100';
        color = 'text-yellow-600';
    } else if (level >= 10) {
        iconClass = 'Award';
        bgColor = 'bg-orange-100';
        color = 'text-orange-600';
    } else if (level >= 8) {
        iconClass = 'Star';
        bgColor = 'bg-red-100';
        color = 'text-red-600';
    } else if (level >= 6) {
        iconClass = 'Target';
        bgColor = 'bg-blue-100';
        color = 'text-blue-600';
    } else if (level >= 4) {
        iconClass = 'BookOpen';
        bgColor = 'bg-green-100';
        color = 'text-green-600';
    } else if (level >= 2) {
        iconClass = 'Zap';
        bgColor = 'bg-yellow-100';
        color = 'text-yellow-600';
    }
    return {
        level,
        name: levelData.title,
        icon: iconClass,
        bgColor,
        color
    };
}
function getXPProgress(totalXP) {
    const userLevel = calculateLevel(totalXP);
    const current = userLevel.currentXP;
    const required = current + userLevel.xpToNextLevel;
    const percentage = required > 0 ? current / required * 100 : 100;
    return {
        current,
        required,
        percentage
    };
}
function getLevelColor(level) {
    if (level >= 15) return 'from-purple-600 to-pink-600'; // Siêu phàm
    if (level >= 12) return 'from-purple-500 to-indigo-600'; // Huyền thoại+
    if (level >= 10) return 'from-yellow-500 to-orange-500'; // Đại sư+
    if (level >= 8) return 'from-red-500 to-pink-500'; // Cao thủ+
    if (level >= 6) return 'from-blue-500 to-purple-500'; // Chuyên gia+
    if (level >= 4) return 'from-green-500 to-blue-500'; // Học sinh giỏi+
    if (level >= 2) return 'from-yellow-400 to-green-500'; // Học viên+
    return 'from-gray-400 to-blue-400'; // Người mới
}
function getLevelIcon(level) {
    if (level >= 15) return '👑'; // Siêu phàm
    if (level >= 12) return '🏆'; // Huyền thoại+
    if (level >= 10) return '🥇'; // Đại sư+
    if (level >= 8) return '🥈'; // Cao thủ+
    if (level >= 6) return '🥉'; // Chuyên gia+
    if (level >= 4) return '🎖️'; // Học sinh giỏi+
    if (level >= 2) return '🏅'; // Học viên+
    return '🌟'; // Người mới
}
function getProgressText(userLevel) {
    if (userLevel.xpToNextLevel === 0) {
        return 'Cấp độ tối đa!';
    }
    return "".concat(userLevel.currentXP, " / ").concat(userLevel.currentXP + userLevel.xpToNextLevel, " XP");
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/LevelContext.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LevelProvider",
    ()=>LevelProvider,
    "useLevel",
    ()=>useLevel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$level$2f$levelSystem$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/level/levelSystem.ts [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
const LevelContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function LevelProvider(param) {
    let { children, userId } = param;
    _s();
    const [userStats, setUserStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])({
        totalXP: 0,
        level: 1,
        pomodoroSessions: 0,
        flashcardsStudied: 0,
        chatMessages: 0,
        totalHabitsCompleted: 0,
        streakDays: 0,
        studyTimeMinutes: 0,
        joinDate: new Date()
    });
    const [showLevelUpNotification, setShowLevelUpNotification] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const userLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$level$2f$levelSystem$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["calculateLevel"])(userStats.totalXP);
    // Load user stats from localStorage or API
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LevelProvider.useEffect": ()=>{
            if (userId) {
                loadUserStats(userId);
            } else {
                loadLocalStats();
            }
        }
    }["LevelProvider.useEffect"], [
        userId
    ]);
    const loadUserStats = async (userId)=>{
        try {
            // TODO: Load from Firebase/API
            const savedStats = localStorage.getItem("userStats_".concat(userId));
            if (savedStats) {
                const parsed = JSON.parse(savedStats);
                setUserStats({
                    ...parsed,
                    joinDate: new Date(parsed.joinDate)
                });
            }
        } catch (error) {
            console.error('Failed to load user stats:', error);
        }
    };
    const loadLocalStats = ()=>{
        try {
            const savedStats = localStorage.getItem('userStats_local');
            if (savedStats) {
                const parsed = JSON.parse(savedStats);
                setUserStats({
                    ...parsed,
                    joinDate: new Date(parsed.joinDate)
                });
            }
        } catch (error) {
            console.error('Failed to load local stats:', error);
        }
    };
    const saveUserStats = async (stats)=>{
        try {
            const key = userId ? "userStats_".concat(userId) : 'userStats_local';
            localStorage.setItem(key, JSON.stringify(stats));
        // TODO: Save to Firebase/API if userId exists
        } catch (error) {
            console.error('Failed to save user stats:', error);
        }
    };
    const addUserXP = async (action, customAmount)=>{
        const xpAmount = customAmount || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$level$2f$levelSystem$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["XP_ACTIONS"][action].amount;
        const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$level$2f$levelSystem$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["addXP"])(userStats.totalXP, xpAmount);
        const newStats = {
            ...userStats,
            totalXP: result.newLevel.totalXP,
            level: result.newLevel.level
        };
        setUserStats(newStats);
        await saveUserStats(newStats);
        // Show level up notification if leveled up
        if (result.levelUp) {
            setShowLevelUpNotification(true);
            // Auto hide after 5 seconds
            setTimeout(()=>{
                setShowLevelUpNotification(false);
            }, 5000);
        }
    };
    const updateStats = async (newStats)=>{
        const updatedStats = {
            ...userStats,
            ...newStats,
            // Always sync level with totalXP when updating
            level: newStats.totalXP ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$level$2f$levelSystem$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["calculateLevel"])(newStats.totalXP).level : userStats.level
        };
        setUserStats(updatedStats);
        await saveUserStats(updatedStats);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LevelContext.Provider, {
        value: {
            userLevel,
            userStats,
            addUserXP,
            updateStats,
            showLevelUpNotification,
            setShowLevelUpNotification
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/LevelContext.tsx",
        lineNumber: 153,
        columnNumber: 5
    }, this);
}
_s(LevelProvider, "tukLVYmE68+I4gBWW5OjxviqaGY=");
_c = LevelProvider;
const useLevel = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useContext"])(LevelContext);
    if (context === undefined) {
        throw new Error('useLevel must be used within a LevelProvider');
    }
    return context;
};
_s1(useLevel, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "LevelProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/languageDetection.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Language Detection and Suggestion Generation
 */ __turbopack_context__.s([
    "detectUserLanguage",
    ()=>detectUserLanguage,
    "generateContextualSuggestions",
    ()=>generateContextualSuggestions,
    "getLocalizedSuggestions",
    ()=>getLocalizedSuggestions
]);
function detectUserLanguage(chatHistory) {
    if (!chatHistory || chatHistory.length === 0) {
        return 'vi'; // Default Vietnamese
    }
    // Get user messages only
    const userMessages = chatHistory.filter((msg)=>msg.sender === 'user').map((msg)=>msg.content).slice(-10); // Last 10 messages
    if (userMessages.length === 0) {
        return 'vi';
    }
    // Simple language detection based on patterns
    const text = userMessages.join(' ').toLowerCase();
    // English indicators
    const englishPatterns = [
        /\b(the|and|or|but|in|on|at|to|for|of|with|by)\b/g,
        /\b(hello|hi|how|what|when|where|why|can|could|would|should)\b/g,
        /\b(please|thank|thanks|sorry|excuse|help|need|want)\b/g
    ];
    // Vietnamese indicators
    const vietnamesePatterns = [
        /\b(và|hoặc|nhưng|trong|trên|tại|để|của|với|bởi)\b/g,
        /\b(xin|chào|làm|thế|nào|gì|khi|nào|ở|đâu|tại|sao|có|thể)\b/g,
        /\b(cảm|ơn|xin|lỗi|giúp|cần|muốn|là|được)\b/g
    ];
    let englishScore = 0;
    let vietnameseScore = 0;
    englishPatterns.forEach((pattern)=>{
        const matches = text.match(pattern);
        englishScore += matches ? matches.length : 0;
    });
    vietnamesePatterns.forEach((pattern)=>{
        const matches = text.match(pattern);
        vietnameseScore += matches ? matches.length : 0;
    });
    // Also check for Vietnamese diacritics
    const vietnameseDiacritics = /[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]/g;
    const diacriticMatches = text.match(vietnameseDiacritics);
    vietnameseScore += diacriticMatches ? diacriticMatches.length * 2 : 0;
    return vietnameseScore > englishScore ? 'vi' : 'en';
}
function getLocalizedSuggestions(language) {
    const timeOfDay = getTimeOfDay();
    if (language === 'en') {
        return getEnglishSuggestions(timeOfDay);
    } else {
        return getVietnameseSuggestions(timeOfDay);
    }
}
function getTimeOfDay() {
    const hour = new Date().getHours();
    if (hour < 12) return 'morning';
    if (hour < 18) return 'afternoon';
    return 'evening';
}
function getEnglishSuggestions(timeOfDay) {
    const suggestionSets = {
        morning: [
            {
                id: '1',
                title: 'Morning Grammar Boost',
                prompt: 'Help me practice English grammar with some morning exercises',
                category: 'grammar',
                icon: '📝'
            },
            {
                id: '2',
                title: 'Daily Vocabulary',
                prompt: 'Teach me 5 new English words for today',
                category: 'vocabulary',
                icon: '📚'
            },
            {
                id: '3',
                title: 'Pronunciation Practice',
                prompt: 'Help me practice English pronunciation',
                category: 'pronunciation',
                icon: '🗣️'
            },
            {
                id: '4',
                title: 'Morning Conversation',
                prompt: "Let's have a casual morning conversation in English",
                category: 'conversation',
                icon: '☕'
            },
            {
                id: '5',
                title: 'News Discussion',
                prompt: "Discuss today's news in English",
                category: 'current events',
                icon: '📰'
            },
            {
                id: '6',
                title: 'English Idioms',
                prompt: 'Teach me some common English idioms',
                category: 'idioms',
                icon: '💡'
            }
        ],
        afternoon: [
            {
                id: '1',
                title: 'Afternoon Tea Chat',
                prompt: "Let's have an afternoon tea conversation in English",
                category: 'conversation',
                icon: '🫖'
            },
            {
                id: '2',
                title: 'Describing Your Afternoon',
                prompt: 'Help me describe my afternoon activities in English',
                category: 'daily life',
                icon: '🌤️'
            },
            {
                id: '3',
                title: 'Afternoon Idioms',
                prompt: 'Teach me English idioms related to time and daily activities',
                category: 'idioms',
                icon: '⏰'
            },
            {
                id: '4',
                title: 'Past Perfect Practice',
                prompt: 'Help me practice past perfect tense with afternoon scenarios',
                category: 'grammar',
                icon: '⏪'
            },
            {
                id: '5',
                title: 'Afternoon Movie Review',
                prompt: "Let's discuss and review movies in English",
                category: 'entertainment',
                icon: '🎬'
            },
            {
                id: '6',
                title: 'Relaxing Conversation Starters',
                prompt: 'Give me some relaxing conversation topics for the afternoon',
                category: 'conversation',
                icon: '💬'
            }
        ],
        evening: [
            {
                id: '1',
                title: 'Evening Reflection',
                prompt: 'Help me reflect on my day in English',
                category: 'daily life',
                icon: '🌅'
            },
            {
                id: '2',
                title: 'Bedtime Stories',
                prompt: 'Tell me a short bedtime story in English',
                category: 'stories',
                icon: '📖'
            },
            {
                id: '3',
                title: 'Evening News',
                prompt: 'Discuss evening news and current events',
                category: 'current events',
                icon: '📺'
            },
            {
                id: '4',
                title: 'Night Vocabulary',
                prompt: 'Teach me English words related to evening and night',
                category: 'vocabulary',
                icon: '🌙'
            },
            {
                id: '5',
                title: 'Dinner Conversation',
                prompt: "Let's have a dinner conversation in English",
                category: 'food',
                icon: '🍽️'
            },
            {
                id: '6',
                title: 'Planning Tomorrow',
                prompt: "Help me plan tomorrow's activities in English",
                category: 'future plans',
                icon: '📅'
            }
        ]
    };
    return suggestionSets[timeOfDay] || suggestionSets.afternoon;
}
function getVietnameseSuggestions(timeOfDay) {
    const suggestionSets = {
        morning: [
            {
                id: '1',
                title: 'Luyện ngữ pháp buổi sáng',
                prompt: 'Giúp tôi luyện ngữ pháp tiếng Anh với bài tập buổi sáng',
                category: 'grammar',
                icon: '📝'
            },
            {
                id: '2',
                title: 'Từ vựng hàng ngày',
                prompt: 'Dạy tôi 5 từ tiếng Anh mới hôm nay',
                category: 'vocabulary',
                icon: '📚'
            },
            {
                id: '3',
                title: 'Luyện phát âm',
                prompt: 'Giúp tôi luyện phát âm tiếng Anh',
                category: 'pronunciation',
                icon: '🗣️'
            },
            {
                id: '4',
                title: 'Trò chuyện buổi sáng',
                prompt: 'Hãy trò chuyện tiếng Anh thông thường buổi sáng',
                category: 'conversation',
                icon: '☕'
            },
            {
                id: '5',
                title: 'Thảo luận tin tức',
                prompt: 'Thảo luận tin tức hôm nay bằng tiếng Anh',
                category: 'current events',
                icon: '📰'
            },
            {
                id: '6',
                title: 'Thành ngữ tiếng Anh',
                prompt: 'Dạy tôi một số thành ngữ tiếng Anh phổ biến',
                category: 'idioms',
                icon: '💡'
            }
        ],
        afternoon: [
            {
                id: '1',
                title: 'Trò chuyện trà chiều',
                prompt: 'Hãy trò chuyện trà chiều bằng tiếng Anh',
                category: 'conversation',
                icon: '🫖'
            },
            {
                id: '2',
                title: 'Mô tả buổi chiều',
                prompt: 'Giúp tôi mô tả các hoạt động buổi chiều bằng tiếng Anh',
                category: 'daily life',
                icon: '🌤️'
            },
            {
                id: '3',
                title: 'Thành ngữ buổi chiều',
                prompt: 'Dạy tôi thành ngữ tiếng Anh về thời gian và hoạt động hàng ngày',
                category: 'idioms',
                icon: '⏰'
            },
            {
                id: '4',
                title: 'Luyện quá khứ hoàn thành',
                prompt: 'Giúp tôi luyện thì quá khứ hoàn thành với tình huống buổi chiều',
                category: 'grammar',
                icon: '⏪'
            },
            {
                id: '5',
                title: 'Review phim buổi chiều',
                prompt: 'Hãy thảo luận và review phim bằng tiếng Anh',
                category: 'entertainment',
                icon: '🎬'
            },
            {
                id: '6',
                title: 'Chủ đề thư giãn',
                prompt: 'Cho tôi một số chủ đề trò chuyện thư giãn cho buổi chiều',
                category: 'conversation',
                icon: '💬'
            }
        ],
        evening: [
            {
                id: '1',
                title: 'Suy ngẫm buổi tối',
                prompt: 'Giúp tôi suy ngẫm về ngày hôm nay bằng tiếng Anh',
                category: 'daily life',
                icon: '🌅'
            },
            {
                id: '2',
                title: 'Truyện trước khi ngủ',
                prompt: 'Kể cho tôi một câu chuyện ngắn bằng tiếng Anh',
                category: 'stories',
                icon: '📖'
            },
            {
                id: '3',
                title: 'Tin tức buổi tối',
                prompt: 'Thảo luận tin tức buổi tối và sự kiện hiện tại',
                category: 'current events',
                icon: '📺'
            },
            {
                id: '4',
                title: 'Từ vựng về đêm',
                prompt: 'Dạy tôi từ tiếng Anh liên quan đến buổi tối và ban đêm',
                category: 'vocabulary',
                icon: '🌙'
            },
            {
                id: '5',
                title: 'Trò chuyện bữa tối',
                prompt: 'Hãy trò chuyện bữa tối bằng tiếng Anh',
                category: 'food',
                icon: '🍽️'
            },
            {
                id: '6',
                title: 'Lập kế hoạch ngày mai',
                prompt: 'Giúp tôi lập kế hoạch hoạt động ngày mai bằng tiếng Anh',
                category: 'future plans',
                icon: '📅'
            }
        ]
    };
    return suggestionSets[timeOfDay] || suggestionSets.afternoon;
}
function generateContextualSuggestions(context) {
    // Detect language from chat history if not explicitly set
    let language = context.userLanguage;
    if (!language && context.chatHistory) {
        language = detectUserLanguage(context.chatHistory);
    }
    // Default to Vietnamese
    language = language || 'vi';
    return getLocalizedSuggestions(language);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/LanguageContext.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LanguageProvider",
    ()=>LanguageProvider,
    "useLanguage",
    ()=>useLanguage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$languageDetection$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/languageDetection.ts [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
const LanguageContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function LanguageProvider(param) {
    let { children } = param;
    _s();
    const [userLanguage, setUserLanguageState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('vi'); // Default Vietnamese
    const [detectedLanguage, setDetectedLanguage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('vi');
    const [isClient, setIsClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Check if we're on client side
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LanguageProvider.useEffect": ()=>{
            setIsClient(true);
        }
    }["LanguageProvider.useEffect"], []);
    // Load user language preference from localStorage
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LanguageProvider.useEffect": ()=>{
            if (!isClient) return; // Skip on server side
            try {
                const savedLanguage = localStorage.getItem('userLanguage');
                if (savedLanguage) {
                    setUserLanguageState(savedLanguage);
                } else {
                    // Detect browser language
                    const browserLang = navigator.language.startsWith('en') ? 'en' : 'vi';
                    setUserLanguageState(browserLang);
                }
            } catch (error) {
                console.warn('Failed to access localStorage:', error);
            }
        }
    }["LanguageProvider.useEffect"], [
        isClient
    ]);
    const setUserLanguage = (language)=>{
        setUserLanguageState(language);
        if (isClient) {
            try {
                localStorage.setItem('userLanguage', language);
            } catch (error) {
                console.warn('Failed to save to localStorage:', error);
            }
        }
    };
    const updateDetectedLanguageFromChat = (chatHistory)=>{
        // Chuyển đổi định dạng để match với detectUserLanguage
        const formattedHistory = chatHistory.map((msg)=>({
                content: msg.content,
                sender: msg.role === 'user' ? 'user' : 'assistant'
            }));
        const detected = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$languageDetection$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["detectUserLanguage"])(formattedHistory);
        setDetectedLanguage(detected);
        return detected;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LanguageContext.Provider, {
        value: {
            userLanguage,
            setUserLanguage,
            detectedLanguage,
            setDetectedLanguage,
            updateDetectedLanguageFromChat
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/LanguageContext.tsx",
        lineNumber: 82,
        columnNumber: 5
    }, this);
}
_s(LanguageProvider, "7/XsjtW9FjhcMUx3Jkhorp5kMLY=");
_c = LanguageProvider;
function useLanguage() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useContext"])(LanguageContext);
    if (context === undefined) {
        throw new Error('useLanguage must be used within a LanguageProvider');
    }
    return context;
}
_s1(useLanguage, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "LanguageProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/pages/_app.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>App
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$error$2d$boundary$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/error-boundary.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$AuthContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/AuthContext.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$AppStateContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/AppStateContext.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$LevelContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/LevelContext.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$LanguageContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/LanguageContext.tsx [client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
function App(param) {
    let { Component, pageProps } = param;
    const handleError = (error, errorInfo)=>{
        console.error('Global error caught:', error, errorInfo);
        if (("TURBOPACK compile-time value", "development") === 'production') {
        // send to monitoring here
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$error$2d$boundary$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["ErrorBoundary"], {
        onError: handleError,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["ThemeProvider"], {
            attribute: "class",
            defaultTheme: "system",
            enableSystem: true,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$LanguageContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["LanguageProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$AppStateContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AppStateProvider"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$AuthContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["AuthProvider"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$LevelContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["LevelProvider"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Component, {
                                    ...pageProps
                                }, void 0, false, {
                                    fileName: "[project]/pages/_app.tsx",
                                    lineNumber: 28,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["Toaster"], {
                                    position: "top-center"
                                }, void 0, false, {
                                    fileName: "[project]/pages/_app.tsx",
                                    lineNumber: 29,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/pages/_app.tsx",
                            lineNumber: 27,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/pages/_app.tsx",
                        lineNumber: 26,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/pages/_app.tsx",
                    lineNumber: 25,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/pages/_app.tsx",
                lineNumber: 24,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/pages/_app.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/pages/_app.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_c = App;
var _c;
__turbopack_context__.k.register(_c, "App");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[next]/entry/page-loader.ts { PAGE => \"[project]/pages/_app.tsx [client] (ecmascript)\" } [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const PAGE_PATH = "/_app";
(window.__NEXT_P = window.__NEXT_P || []).push([
    PAGE_PATH,
    ()=>{
        return __turbopack_context__.r("[project]/pages/_app.tsx [client] (ecmascript)");
    }
]);
// @ts-expect-error module.hot exists
if (module.hot) {
    // @ts-expect-error module.hot exists
    module.hot.dispose(function() {
        window.__NEXT_P.push([
            PAGE_PATH
        ]);
    });
}
}),
"[hmr-entry]/hmr-entry.js { ENTRY => \"[project]/pages/_app\" }", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.r("[next]/entry/page-loader.ts { PAGE => \"[project]/pages/_app.tsx [client] (ecmascript)\" } [client] (ecmascript)");
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__1253443a._.js.map