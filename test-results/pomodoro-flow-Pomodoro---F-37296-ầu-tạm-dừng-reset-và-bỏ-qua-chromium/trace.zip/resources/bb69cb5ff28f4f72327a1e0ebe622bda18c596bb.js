(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/error.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AppError",
    ()=>AppError,
    "handleError",
    ()=>handleError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [client] (ecmascript)");
;
class AppError extends Error {
    static isAppError(error) {
        return error && error.name === 'AppError';
    }
    static from(error) {
        let defaultMessage = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'Đã xảy ra lỗi';
        if (AppError.isAppError(error)) {
            return error;
        }
        if (error instanceof Error) {
            return new AppError(error.message, 'UNKNOWN_ERROR', {
                originalError: error.name
            });
        }
        return new AppError(defaultMessage, 'UNKNOWN_ERROR');
    }
    static auth() {
        let message = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Xác thực thất bại', context = arguments.length > 1 ? arguments[1] : void 0;
        return new AppError(message, 'AUTH_ERROR', context);
    }
    static network() {
        let message = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Lỗi kết nối mạng', context = arguments.length > 1 ? arguments[1] : void 0;
        return new AppError(message, 'NETWORK_ERROR', context);
    }
    static validation() {
        let message = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Dữ liệu không hợp lệ', context = arguments.length > 1 ? arguments[1] : void 0;
        return new AppError(message, 'VALIDATION_ERROR', context);
    }
    static notFound() {
        let message = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Không tìm thấy tài nguyên', context = arguments.length > 1 ? arguments[1] : void 0;
        return new AppError(message, 'NOT_FOUND', context);
    }
    static server() {
        let message = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Lỗi máy chủ', context = arguments.length > 1 ? arguments[1] : void 0;
        return new AppError(message, 'SERVER_ERROR', context);
    }
    constructor(message, code = 'UNKNOWN_ERROR', context){
        super(message), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__["_"])(this, "code", void 0), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__["_"])(this, "context", void 0), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$client$5d$__$28$ecmascript$29$__["_"])(this, "isOperational", void 0);
        this.name = 'AppError';
        this.code = code;
        this.context = context;
        this.isOperational = true; // Mặc định là lỗi hoạt động (có thể xử lý)
    }
}
function handleError(error, options) {
    const { showToast: _showToast = false, logToConsole = true } = options || {};
    const appError = AppError.from(error);
    // Chỉ log trong môi trường development
    if (logToConsole && ("TURBOPACK compile-time value", "development") === 'development') {
        console.error('Application error:', appError);
    }
    return appError;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/utils.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn,
    "debounce",
    ()=>debounce,
    "formatDate",
    ()=>formatDate,
    "formatTime",
    ()=>formatTime,
    "generateId",
    ()=>generateId,
    "safeJsonParse",
    ()=>safeJsonParse,
    "truncateString",
    ()=>truncateString
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [client] (ecmascript)");
;
;
function cn() {
    for(var _len = arguments.length, inputs = new Array(_len), _key = 0; _key < _len; _key++){
        inputs[_key] = arguments[_key];
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
function formatDate(date) {
    if (!date) return '';
    const d = typeof date === 'string' ? new Date(date) : date;
    return d.toLocaleDateString('vi-VN', {
        day: 'numeric',
        month: 'numeric',
        year: 'numeric'
    });
}
function formatTime(date) {
    if (!date) return '';
    const d = typeof date === 'string' ? new Date(date) : date;
    return d.toLocaleTimeString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit'
    });
}
function truncateString(str, maxLength) {
    if (!str || str.length <= maxLength) return str;
    return str.substring(0, maxLength) + '...';
}
function generateId() {
    let prefix = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'id';
    return "".concat(prefix, "-").concat(Date.now(), "-").concat(Math.random().toString(36).substring(2, 9));
}
function debounce(fn, delay) {
    let timeoutId = null;
    return function() {
        for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
            args[_key] = arguments[_key];
        }
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
        timeoutId = setTimeout(()=>{
            fn(...args);
            timeoutId = null;
        }, delay);
    };
}
function safeJsonParse(json, fallback) {
    try {
        return JSON.parse(json);
    } catch (error) {
        if ("TURBOPACK compile-time truthy", 1) {
            console.error('Error parsing JSON:', error);
        }
        return fallback;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useErrorHandler.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useErrorHandler",
    ()=>useErrorHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$error$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/error.ts [client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useErrorHandler(options) {
    _s();
    const { showToast = true, logToConsole = true, captureToSentry = ("TURBOPACK compile-time value", "development") === 'production' } = options || {};
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    /**
   * Xử lý lỗi
   * @param err Lỗi cần xử lý
   */ const handleAppError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useErrorHandler.useCallback[handleAppError]": (err)=>{
            const appError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$error$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["handleError"])(err);
            setError(appError);
            if (logToConsole) {
                // Chỉ log trong môi trường development
                if ("TURBOPACK compile-time truthy", 1) {
                    console.error('Application error:', appError);
                }
            }
            if (showToast) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["toast"].error(appError.message);
            }
            if (captureToSentry && !appError.isOperational) {
            // Gửi lỗi đến Sentry hoặc dịch vụ theo dõi lỗi khác
            // Sentry.captureException(appError);
            }
            return appError;
        }
    }["useErrorHandler.useCallback[handleAppError]"], [
        showToast,
        logToConsole,
        captureToSentry
    ]);
    /**
   * Bọc một hàm async với xử lý lỗi và trạng thái loading
   * @param fn Hàm async cần bọc
   * @returns Hàm đã được bọc
   */ const withErrorHandling = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useErrorHandler.useCallback[withErrorHandling]": (fn)=>{
            return ({
                "useErrorHandler.useCallback[withErrorHandling]": async function() {
                    for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                        args[_key] = arguments[_key];
                    }
                    setIsLoading(true);
                    setError(null);
                    try {
                        const result = await fn(...args);
                        return result;
                    } catch (err) {
                        handleAppError(err);
                        return undefined;
                    } finally{
                        setIsLoading(false);
                    }
                }
            })["useErrorHandler.useCallback[withErrorHandling]"];
        }
    }["useErrorHandler.useCallback[withErrorHandling]"], [
        handleAppError
    ]);
    /**
   * Xóa lỗi hiện tại
   */ const clearError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useErrorHandler.useCallback[clearError]": ()=>{
            setError(null);
        }
    }["useErrorHandler.useCallback[clearError]"], []);
    return {
        error,
        isLoading,
        handleError: handleAppError,
        withErrorHandling,
        clearError
    };
}
_s(useErrorHandler, "3njq48uetIMIIr7ZXOaACSPGVsY=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useHabitPomodoroIntegration.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useHabitPomodoroIntegration",
    ()=>useHabitPomodoroIntegration
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useHabitPomodoroIntegration(user) {
    _s();
    const [habitTasks, setHabitTasks] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [habitOptions, setHabitOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [habitStats, setHabitStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentHabitId, setCurrentHabitId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Load available habits for task creation
    const loadHabitOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useHabitPomodoroIntegration.useCallback[loadHabitOptions]": async ()=>{
            var _auth_currentUser;
            const uid = (user === null || user === void 0 ? void 0 : user.uid) || ((_auth_currentUser = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) === null || _auth_currentUser === void 0 ? void 0 : _auth_currentUser.uid);
            if (!uid) return;
            try {
                const habitsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habits');
                const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(habitsRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', uid));
                const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
                const habits = querySnapshot.docs.map({
                    "useHabitPomodoroIntegration.useCallback[loadHabitOptions].habits": (doc)=>{
                        const data = doc.data();
                        // Fallback màu sắc mặc định nếu thiếu từ Firestore
                        const fallbackColor = 'bg-blue-500';
                        const fallbackBg = 'bg-blue-100 dark:bg-blue-900/50';
                        const fallbackText = 'text-blue-600 dark:text-blue-400';
                        return {
                            id: doc.id,
                            title: data.title || 'Habit',
                            color: data.color || fallbackColor,
                            bgColor: data.bgColor || fallbackBg,
                            textColor: data.textColor || fallbackText,
                            icon: data.iconName
                        };
                    }
                }["useHabitPomodoroIntegration.useCallback[loadHabitOptions].habits"]);
                setHabitOptions(habits);
            } catch (error) {
                console.error('Failed to load habit options:', error);
            }
        }
    }["useHabitPomodoroIntegration.useCallback[loadHabitOptions]"], [
        user === null || user === void 0 ? void 0 : user.uid
    ]);
    // Load habit-based tasks
    const loadHabitTasks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useHabitPomodoroIntegration.useCallback[loadHabitTasks]": async ()=>{
            var _auth_currentUser;
            const uid = (user === null || user === void 0 ? void 0 : user.uid) || ((_auth_currentUser = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) === null || _auth_currentUser === void 0 ? void 0 : _auth_currentUser.uid);
            if (!uid) return;
            setLoading(true);
            try {
                const tasksRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'pomodoro_habit_tasks');
                const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["query"])(tasksRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', uid));
                const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
                const tasks = querySnapshot.docs.map({
                    "useHabitPomodoroIntegration.useCallback[loadHabitTasks].tasks": (doc)=>{
                        var _data_createdAt_toDate, _data_createdAt_toDate1, _data_createdAt, _data_completedAt_toDate, _data_completedAt_toDate1, _data_completedAt;
                        const data = doc.data();
                        return {
                            id: doc.id,
                            text: data.text,
                            completed: data.completed || false,
                            pomodoroCount: data.pomodoroCount || 0,
                            habitId: data.habitId,
                            habitTitle: data.habitTitle,
                            habitColor: data.habitColor,
                            estimatedPomodoros: data.estimatedPomodoros,
                            priority: data.priority || 'medium',
                            createdAt: ((_data_createdAt = data.createdAt) === null || _data_createdAt === void 0 ? void 0 : (_data_createdAt_toDate1 = _data_createdAt.toDate) === null || _data_createdAt_toDate1 === void 0 ? void 0 : (_data_createdAt_toDate = _data_createdAt_toDate1.call(_data_createdAt)) === null || _data_createdAt_toDate === void 0 ? void 0 : _data_createdAt_toDate.toISOString()) || new Date().toISOString(),
                            completedAt: (_data_completedAt = data.completedAt) === null || _data_completedAt === void 0 ? void 0 : (_data_completedAt_toDate1 = _data_completedAt.toDate) === null || _data_completedAt_toDate1 === void 0 ? void 0 : (_data_completedAt_toDate = _data_completedAt_toDate1.call(_data_completedAt)) === null || _data_completedAt_toDate === void 0 ? void 0 : _data_completedAt_toDate.toISOString()
                        };
                    }
                }["useHabitPomodoroIntegration.useCallback[loadHabitTasks].tasks"]);
                setHabitTasks(tasks.sort({
                    "useHabitPomodoroIntegration.useCallback[loadHabitTasks]": (a, b)=>new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                }["useHabitPomodoroIntegration.useCallback[loadHabitTasks]"]));
            } catch (error) {
                console.error('Failed to load habit tasks:', error);
                // Fallback to empty array
                setHabitTasks([]);
            } finally{
                setLoading(false);
            }
        }
    }["useHabitPomodoroIntegration.useCallback[loadHabitTasks]"], [
        user === null || user === void 0 ? void 0 : user.uid
    ]);
    // Create a new habit-based task
    const createHabitTask = async (taskData)=>{
        var _auth_currentUser;
        const uid = (user === null || user === void 0 ? void 0 : user.uid) || ((_auth_currentUser = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) === null || _auth_currentUser === void 0 ? void 0 : _auth_currentUser.uid);
        if (!uid) return null;
        try {
            // Find habit details
            let habit = habitOptions.find((h)=>h.id === taskData.habitId);
            if (!habit) {
                // Fallback chắc chắn: đọc trực tiếp document theo id
                const habitRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habits', taskData.habitId);
                const snap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(habitRef);
                if (snap.exists()) {
                    const data = snap.data();
                    const fallbackColor = 'bg-blue-500';
                    const fallbackBg = 'bg-blue-100 dark:bg-blue-900/50';
                    const fallbackText = 'text-blue-600 dark:text-blue-400';
                    habit = {
                        id: taskData.habitId,
                        title: data.title || 'Habit',
                        color: data.color || fallbackColor,
                        bgColor: data.bgColor || fallbackBg,
                        textColor: data.textColor || fallbackText,
                        icon: data.iconName
                    };
                }
            }
            if (!habit) throw new Error('Habit not found');
            const tasksRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'pomodoro_habit_tasks');
            const newTask = {
                userId: uid,
                text: taskData.text,
                completed: false,
                pomodoroCount: 0,
                habitId: taskData.habitId,
                habitTitle: habit.title || 'Habit',
                habitColor: habit.color || 'bg-blue-500',
                estimatedPomodoros: taskData.estimatedPomodoros || 1,
                priority: taskData.priority || 'medium',
                createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Timestamp"].now()
            };
            const docRef = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["addDoc"])(tasksRef, newTask);
            // Reload tasks
            await loadHabitTasks();
            return docRef.id;
        } catch (error) {
            console.error('Failed to create habit task:', error);
            return null;
        }
    };
    // Update task pomodoro count
    const updateTaskPomodoroCount = async function(taskId) {
        let increment = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1;
        try {
            const taskRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'pomodoro_habit_tasks', taskId);
            const task = habitTasks.find((t)=>t.id === taskId);
            if (task) {
                const newCount = task.pomodoroCount + increment;
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(taskRef, {
                    pomodoroCount: newCount,
                    lastPomodoroAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Timestamp"].now()
                });
                // Update local state
                setHabitTasks((prev)=>prev.map((t)=>t.id === taskId ? {
                            ...t,
                            pomodoroCount: newCount
                        } : t));
                // Check if task should be auto-completed
                if (task.estimatedPomodoros && newCount >= task.estimatedPomodoros) {
                    await completeTask(taskId);
                }
            }
        } catch (error) {
            console.error('Failed to update task pomodoro count:', error);
        }
    };
    // Force mark a habit as completed for today (used after finishing a Pomodoro)
    const markHabitCompletedToday = async (habitId)=>{
        try {
            const habitRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habits', habitId);
            const snap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getDoc"])(habitRef);
            if (!snap.exists()) return;
            const data = snap.data();
            // Calculate indices
            const now = new Date();
            const dayOfWeek = now.getDay(); // 0 = Sun
            const adjustedDayOfWeek = (dayOfWeek + 6) % 7; // 0 = Mon
            const dayOfMonth = now.getDate() - 1; // 0-indexed
            const weeklyProgress = (data.weeklyProgress || [
                false,
                false,
                false,
                false,
                false,
                false,
                false
            ]).slice();
            weeklyProgress[adjustedDayOfWeek] = true;
            const monthlyProgress = (data.monthlyProgress || Array(30).fill(false)).slice();
            if (dayOfMonth >= 0 && dayOfMonth < monthlyProgress.length) {
                monthlyProgress[dayOfMonth] = true;
            }
            const currentStreak = data.currentStreak || 0;
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(habitRef, {
                todayCompleted: true,
                currentStreak: currentStreak + 1,
                weeklyProgress,
                monthlyProgress,
                lastCompletedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Timestamp"].now(),
                lastUpdated: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Timestamp"].now()
            });
        } catch (error) {
            console.error('Failed to mark habit as completed today:', error);
        }
    };
    // Complete a task
    const completeTask = async (taskId)=>{
        try {
            const taskRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'pomodoro_habit_tasks', taskId);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(taskRef, {
                completed: true,
                completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Timestamp"].now()
            });
            // Update local state
            setHabitTasks((prev)=>prev.map((t)=>t.id === taskId ? {
                        ...t,
                        completed: true,
                        completedAt: new Date().toISOString()
                    } : t));
            // Update habit completion if this was the last task for today
            const task = habitTasks.find((t)=>t.id === taskId);
            if (task === null || task === void 0 ? void 0 : task.habitId) {
                await updateHabitProgress(task.habitId);
            }
        } catch (error) {
            console.error('Failed to complete task:', error);
        }
    };
    // Update habit progress based on completed tasks
    const updateHabitProgress = async (habitId)=>{
        try {
            // Check if all tasks for this habit today are completed
            const today = new Date().toDateString();
            const todayTasks = habitTasks.filter((t)=>t.habitId === habitId && new Date(t.createdAt).toDateString() === today);
            const completedTodayTasks = todayTasks.filter((t)=>t.completed);
            // If all tasks are completed, mark habit as completed for today
            if (todayTasks.length > 0 && completedTodayTasks.length === todayTasks.length) {
                const habitRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'habits', habitId);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["updateDoc"])(habitRef, {
                    todayCompleted: true,
                    lastCompletedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Timestamp"].now()
                });
            }
        } catch (error) {
            console.error('Failed to update habit progress:', error);
        }
    };
    // Delete a task
    const deleteTask = async (taskId)=>{
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["deleteDoc"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["db"], 'pomodoro_habit_tasks', taskId));
            setHabitTasks((prev)=>prev.filter((t)=>t.id !== taskId));
        } catch (error) {
            console.error('Failed to delete task:', error);
        }
    };
    // Get tasks for a specific habit
    const getTasksForHabit = (habitId)=>{
        return habitTasks.filter((task)=>task.habitId === habitId);
    };
    // Get active (incomplete) tasks
    const getActiveTasks = ()=>{
        return habitTasks.filter((task)=>!task.completed);
    };
    // Get tasks by priority
    const getTasksByPriority = (priority)=>{
        return habitTasks.filter((task)=>task.priority === priority && !task.completed);
    };
    // Calculate habit statistics
    const calculateHabitStats = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useHabitPomodoroIntegration.useCallback[calculateHabitStats]": ()=>{
            const stats = habitOptions.map({
                "useHabitPomodoroIntegration.useCallback[calculateHabitStats].stats": (habit)=>{
                    var _habitTasks_filter_sort_;
                    const habitTasks = getTasksForHabit(habit.id);
                    const completedTasks = habitTasks.filter({
                        "useHabitPomodoroIntegration.useCallback[calculateHabitStats].stats.completedTasks": (t)=>t.completed
                    }["useHabitPomodoroIntegration.useCallback[calculateHabitStats].stats.completedTasks"]);
                    const totalPomodoros = habitTasks.reduce({
                        "useHabitPomodoroIntegration.useCallback[calculateHabitStats].stats.totalPomodoros": (sum, t)=>sum + t.pomodoroCount
                    }["useHabitPomodoroIntegration.useCallback[calculateHabitStats].stats.totalPomodoros"], 0);
                    return {
                        habitId: habit.id,
                        habitTitle: habit.title,
                        totalPomodoros,
                        completedTasks: completedTasks.length,
                        totalTasks: habitTasks.length,
                        averageTaskDuration: habitTasks.length > 0 ? totalPomodoros / habitTasks.length : 0,
                        lastPomodoroDate: (_habitTasks_filter_sort_ = habitTasks.filter({
                            "useHabitPomodoroIntegration.useCallback[calculateHabitStats].stats": (t)=>t.pomodoroCount > 0
                        }["useHabitPomodoroIntegration.useCallback[calculateHabitStats].stats"]).sort({
                            "useHabitPomodoroIntegration.useCallback[calculateHabitStats].stats": (a, b)=>new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                        }["useHabitPomodoroIntegration.useCallback[calculateHabitStats].stats"])[0]) === null || _habitTasks_filter_sort_ === void 0 ? void 0 : _habitTasks_filter_sort_.createdAt,
                        weeklyPomodoros: [],
                        monthlyPomodoros: []
                    };
                }
            }["useHabitPomodoroIntegration.useCallback[calculateHabitStats].stats"]);
            setHabitStats(stats);
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["useHabitPomodoroIntegration.useCallback[calculateHabitStats]"], [
        habitOptions,
        habitTasks
    ]);
    // Load data on mount and when user changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useHabitPomodoroIntegration.useEffect": ()=>{
            var _auth_currentUser;
            if ((_auth_currentUser = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser) === null || _auth_currentUser === void 0 ? void 0 : _auth_currentUser.uid) {
                loadHabitOptions();
                loadHabitTasks();
            }
        }
    }["useHabitPomodoroIntegration.useEffect"], [
        user,
        loadHabitOptions,
        loadHabitTasks
    ]);
    // Recalculate stats when data changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useHabitPomodoroIntegration.useEffect": ()=>{
            calculateHabitStats();
        }
    }["useHabitPomodoroIntegration.useEffect"], [
        calculateHabitStats
    ]);
    return {
        // Data
        habitTasks,
        habitOptions,
        habitStats,
        loading,
        currentHabitId,
        // Actions
        createHabitTask,
        updateTaskPomodoroCount,
        completeTask,
        deleteTask,
        setCurrentHabitId,
        markHabitCompletedToday,
        // Getters
        getTasksForHabit,
        getActiveTasks,
        getTasksByPriority,
        // Refresh
        loadHabitTasks,
        loadHabitOptions
    };
}
_s(useHabitPomodoroIntegration, "0K7Doc7ddaErswBgl/u/72ejIQA=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useDashboardData.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCTAActions",
    ()=>useCTAActions,
    "useDashboardData",
    ()=>useDashboardData,
    "useQuickActions",
    ()=>useQuickActions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/dashboard/userProgressService.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$missionsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/dashboard/missionsService.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$achievementsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/dashboard/achievementsService.ts [client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
;
;
function useDashboardData(user) {
    _s();
    const [userProgress, setUserProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [dailyMissions, setDailyMissions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [upcomingAchievements, setUpcomingAchievements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [weeklyStats, setWeeklyStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Load initial data
    const loadDashboardData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardData.useCallback[loadDashboardData]": async ()=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return;
            try {
                setLoading(true);
                setError(null);
                // Helper function for retry with exponential backoff
                const retryWithBackoff = {
                    "useDashboardData.useCallback[loadDashboardData].retryWithBackoff": async function(fn) {
                        let maxRetries = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 2, baseDelay = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1000;
                        for(let i = 0; i <= maxRetries; i++){
                            try {
                                return await fn();
                            } catch (error) {
                                if (i === maxRetries) {
                                    console.warn("Failed after ".concat(maxRetries + 1, " attempts:"), error.message);
                                    return null;
                                }
                                // Don't retry on permission errors
                                if (error.code === 'permission-denied') {
                                    return null;
                                }
                                const delay = baseDelay * Math.pow(2, i);
                                await new Promise({
                                    "useDashboardData.useCallback[loadDashboardData].retryWithBackoff": (resolve)=>setTimeout(resolve, delay)
                                }["useDashboardData.useCallback[loadDashboardData].retryWithBackoff"]);
                            }
                        }
                        return null;
                    }
                }["useDashboardData.useCallback[loadDashboardData].retryWithBackoff"];
                // Load data with retry logic and graceful fallbacks
                const [progress, missions, achievements, stats] = await Promise.allSettled([
                    retryWithBackoff({
                        "useDashboardData.useCallback[loadDashboardData]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getUserProgress"])(user.uid)
                    }["useDashboardData.useCallback[loadDashboardData]"]),
                    retryWithBackoff({
                        "useDashboardData.useCallback[loadDashboardData]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$missionsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getDailyMissions"])(user.uid)
                    }["useDashboardData.useCallback[loadDashboardData]"]),
                    retryWithBackoff({
                        "useDashboardData.useCallback[loadDashboardData]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$achievementsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getUpcomingAchievements"])(user.uid, 4)
                    }["useDashboardData.useCallback[loadDashboardData]"]),
                    retryWithBackoff({
                        "useDashboardData.useCallback[loadDashboardData]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getWeeklyStats"])(user.uid)
                    }["useDashboardData.useCallback[loadDashboardData]"])
                ]);
                // Set results with fallbacks
                setUserProgress(progress.status === 'fulfilled' ? progress.value : null);
                setDailyMissions(missions.status === 'fulfilled' ? missions.value : null);
                setUpcomingAchievements(achievements.status === 'fulfilled' ? achievements.value || [] : []);
                setWeeklyStats(stats.status === 'fulfilled' ? stats.value : null);
            } catch (err) {
                console.error('Error loading dashboard data:', err);
                setError(err instanceof Error ? err.message : 'Failed to load dashboard data');
            } finally{
                setLoading(false);
            }
        }
    }["useDashboardData.useCallback[loadDashboardData]"], [
        user === null || user === void 0 ? void 0 : user.uid
    ]);
    // Update progress
    const updateProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardData.useCallback[updateProgress]": async function(wordsLearned) {
            let studyTimeMinutes = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return;
            try {
                const updatedProgress = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updateTodayProgress"])(user.uid, wordsLearned, studyTimeMinutes);
                setUserProgress(updatedProgress);
                // Update achievement progress
                const { unlockedAchievements, totalXPEarned } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$achievementsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updateAchievementProgress"])(user.uid, 'words', wordsLearned);
                if (unlockedAchievements.length > 0) {
                    // Add XP from achievements
                    const finalProgress = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updateXP"])(user.uid, totalXPEarned);
                    setUserProgress(finalProgress);
                    // Refresh upcoming achievements
                    const newUpcoming = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$achievementsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getUpcomingAchievements"])(user.uid, 4);
                    setUpcomingAchievements(newUpcoming);
                }
            } catch (err) {
                console.error('Error updating progress:', err);
                setError(err instanceof Error ? err.message : 'Failed to update progress');
            }
        }
    }["useDashboardData.useCallback[updateProgress]"], [
        user === null || user === void 0 ? void 0 : user.uid
    ]);
    // Complete mission
    const completeMissionAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardData.useCallback[completeMissionAction]": async (missionId)=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return {
                xpEarned: 0
            };
            try {
                const { missions, xpEarned: _xpEarned } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$missionsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["completeMission"])(user.uid, missionId);
                setDailyMissions(missions);
                // Không cộng XP tại đây để tránh "cộng chay" khi chỉ tick nhiệm vụ từ UI
                // XP sẽ chỉ được cộng trong các luồng hành động hợp lệ (flashcard/pomodoro/habit)
                return {
                    xpEarned: 0
                };
            } catch (err) {
                console.error('Error completing mission:', err);
                setError(err instanceof Error ? err.message : 'Failed to complete mission');
                return {
                    xpEarned: 0
                };
            }
        }
    }["useDashboardData.useCallback[completeMissionAction]"], [
        user === null || user === void 0 ? void 0 : user.uid
    ]);
    // Complete mission by type
    const completeMissionByTypeAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardData.useCallback[completeMissionByTypeAction]": async (type)=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return null;
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$missionsService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["completeMissionByType"])(user.uid, type);
                if (result) {
                    setDailyMissions(result.missions);
                }
                // Không cộng XP ở đây; để các service tích hợp xử lý khi có hành động thực sự
                return result ? {
                    ...result,
                    xpEarned: 0
                } : result;
            } catch (err) {
                console.error('Error completing mission by type:', err);
                setError(err instanceof Error ? err.message : 'Failed to complete mission');
                return null;
            }
        }
    }["useDashboardData.useCallback[completeMissionByTypeAction]"], [
        user === null || user === void 0 ? void 0 : user.uid
    ]);
    // Update daily goal
    const updateDailyGoalAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardData.useCallback[updateDailyGoalAction]": async (newGoal)=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return;
            try {
                const updatedProgress = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$userProgressService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updateDailyGoal"])(user.uid, newGoal);
                setUserProgress(updatedProgress);
            } catch (err) {
                console.error('Error updating daily goal:', err);
                setError(err instanceof Error ? err.message : 'Failed to update daily goal');
            }
        }
    }["useDashboardData.useCallback[updateDailyGoalAction]"], [
        user === null || user === void 0 ? void 0 : user.uid
    ]);
    // Refresh data
    const refreshData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardData.useCallback[refreshData]": async ()=>{
            await loadDashboardData();
        }
    }["useDashboardData.useCallback[refreshData]"], [
        loadDashboardData
    ]);
    // Load data on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDashboardData.useEffect": ()=>{
            loadDashboardData();
        }
    }["useDashboardData.useEffect"], [
        loadDashboardData
    ]);
    return {
        // Data
        userProgress,
        dailyMissions,
        upcomingAchievements,
        weeklyStats,
        loading,
        error,
        // Actions
        updateProgress,
        completeMission: completeMissionAction,
        completeMissionByType: completeMissionByTypeAction,
        updateDailyGoal: updateDailyGoalAction,
        refreshData
    };
}
_s(useDashboardData, "qsACxXFTNRxFBFK9zUZvoP9xBNk=");
function useQuickActions(user) {
    _s1();
    const { updateProgress, completeMissionByType } = useDashboardData(user);
    const handleQuickAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useQuickActions.useCallback[handleQuickAction]": async (actionType, words)=>{
            try {
                // Update progress
                await updateProgress(words, 5); // 5 minutes study time
                // Complete corresponding mission
                let missionType = null;
                switch(actionType){
                    case 'review':
                        missionType = 'review';
                        break;
                    case 'quiz':
                        missionType = 'quiz';
                        break;
                    case 'challenge':
                        missionType = 'challenge';
                        break;
                    default:
                        break;
                }
                if (missionType) {
                    await completeMissionByType(missionType);
                }
            } catch (error) {
                console.error('Error in quick action:', error);
            }
        }
    }["useQuickActions.useCallback[handleQuickAction]"], [
        updateProgress,
        completeMissionByType
    ]);
    return {
        handleQuickAction
    };
}
_s1(useQuickActions, "o6jkiuPX5zBPkYiThhq7Ps2FcdA=", false, function() {
    return [
        useDashboardData
    ];
});
function useCTAActions(user) {
    _s2();
    const { updateProgress, completeMissionByType } = useDashboardData(user);
    const handleStartLearning = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useCTAActions.useCallback[handleStartLearning]": async ()=>{
            try {
                await updateProgress(3, 10); // 3 words, 10 minutes
                await completeMissionByType('review');
            } catch (error) {
                console.error('Error in start learning:', error);
            }
        }
    }["useCTAActions.useCallback[handleStartLearning]"], [
        updateProgress,
        completeMissionByType
    ]);
    const handleTabChangeWithMission = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useCTAActions.useCallback[handleTabChangeWithMission]": async (tab)=>{
            try {
                switch(tab){
                    case 'pomodoro':
                        await completeMissionByType('pomodoro');
                        break;
                    case 'habits':
                        await completeMissionByType('habit');
                        break;
                    default:
                        break;
                }
            } catch (error) {
                console.error('Error in tab change with mission:', error);
            }
        }
    }["useCTAActions.useCallback[handleTabChangeWithMission]"], [
        completeMissionByType
    ]);
    return {
        handleStartLearning,
        handleTabChangeWithMission
    };
}
_s2(useCTAActions, "cad3OB+Q8SGVOExnLnQrtBsHpbg=", false, function() {
    return [
        useDashboardData
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useDashboardIntegration.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDashboardIntegration",
    ()=>useDashboardIntegration,
    "useQuickActions",
    ()=>useQuickActions,
    "useRealtimeUpdates",
    ()=>useRealtimeUpdates
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$integrationService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/dashboard/integrationService.ts [client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
function useDashboardIntegration(user) {
    _s();
    const [progress, setProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Load integrated progress
    const loadProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardIntegration.useCallback[loadProgress]": async ()=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return;
            try {
                setLoading(true);
                setError(null);
                // Load integrated progress trước
                const integratedProgress = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$integrationService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getIntegratedProgress"])(user.uid);
                setProgress(integratedProgress);
                // Reset weekly habits nếu cần (chỉ khi thực sự cần)
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$integrationService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["resetWeeklyHabits"])(user.uid);
            } catch (err) {
                console.error('Error loading integrated progress:', err);
                setError(err instanceof Error ? err.message : 'Failed to load progress');
            } finally{
                setLoading(false);
            }
        }
    }["useDashboardIntegration.useCallback[loadProgress]"], [
        user === null || user === void 0 ? void 0 : user.uid
    ]);
    // Complete flashcard session
    const completeFlashcardSession = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardIntegration.useCallback[completeFlashcardSession]": async function(wordsLearned) {
            let studyTimeMinutes = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
            if (!(user === null || user === void 0 ? void 0 : user.uid)) {
                return {
                    success: false,
                    xpEarned: 0,
                    progressUpdated: false,
                    message: 'User not authenticated'
                };
            }
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$integrationService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updateFlashcardProgress"])(user.uid, wordsLearned, studyTimeMinutes);
                if (result.success) {
                    // Refresh progress after successful update
                    await loadProgress();
                }
                return result;
            } catch (err) {
                console.error('Error completing flashcard session:', err);
                return {
                    success: false,
                    xpEarned: 0,
                    progressUpdated: false,
                    message: 'Có lỗi khi hoàn thành phiên học flashcard'
                };
            }
        }
    }["useDashboardIntegration.useCallback[completeFlashcardSession]"], [
        user === null || user === void 0 ? void 0 : user.uid,
        loadProgress
    ]);
    // Complete pomodoro session
    const completePomodoroSession = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardIntegration.useCallback[completePomodoroSession]": async function() {
            let pomodorosCompleted = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 1, focusTimeMinutes = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 25;
            if (!(user === null || user === void 0 ? void 0 : user.uid)) {
                return {
                    success: false,
                    xpEarned: 0,
                    progressUpdated: false,
                    message: 'User not authenticated'
                };
            }
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$integrationService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updatePomodoroProgress"])(user.uid, pomodorosCompleted, focusTimeMinutes);
                if (result.success) {
                    // Refresh progress after successful update
                    await loadProgress();
                }
                return result;
            } catch (err) {
                console.error('Error completing pomodoro session:', err);
                return {
                    success: false,
                    xpEarned: 0,
                    progressUpdated: false,
                    message: 'Có lỗi khi hoàn thành phiên Pomodoro'
                };
            }
        }
    }["useDashboardIntegration.useCallback[completePomodoroSession]"], [
        user === null || user === void 0 ? void 0 : user.uid,
        loadProgress
    ]);
    // Toggle habit completion
    const toggleHabitCompletion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardIntegration.useCallback[toggleHabitCompletion]": async (habitId, completed)=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) {
                return {
                    success: false,
                    xpEarned: 0,
                    progressUpdated: false,
                    message: 'User not authenticated'
                };
            }
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$integrationService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["updateHabitProgress"])(user.uid, habitId, completed);
                if (result.success) {
                    // Refresh progress after successful update
                    await loadProgress();
                }
                return result;
            } catch (err) {
                console.error('Error toggling habit completion:', err);
                return {
                    success: false,
                    xpEarned: 0,
                    progressUpdated: false,
                    message: 'Có lỗi khi cập nhật thói quen'
                };
            }
        }
    }["useDashboardIntegration.useCallback[toggleHabitCompletion]"], [
        user === null || user === void 0 ? void 0 : user.uid,
        loadProgress
    ]);
    // Refresh progress
    const refreshProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardIntegration.useCallback[refreshProgress]": async ()=>{
            await loadProgress();
        }
    }["useDashboardIntegration.useCallback[refreshProgress]"], [
        loadProgress
    ]);
    // Reset weekly habits
    const resetWeeklyHabitsAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDashboardIntegration.useCallback[resetWeeklyHabitsAction]": async ()=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return;
            try {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$dashboard$2f$integrationService$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["resetWeeklyHabits"])(user.uid);
                await loadProgress();
            } catch (err) {
                console.error('Error resetting weekly habits:', err);
                setError('Có lỗi khi reset thói quen hàng tuần');
            }
        }
    }["useDashboardIntegration.useCallback[resetWeeklyHabitsAction]"], [
        user === null || user === void 0 ? void 0 : user.uid,
        loadProgress
    ]);
    // Load progress on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDashboardIntegration.useEffect": ()=>{
            loadProgress();
        }
    }["useDashboardIntegration.useEffect"], [
        loadProgress
    ]);
    return {
        // Data
        progress,
        loading,
        error,
        // Actions
        completeFlashcardSession,
        completePomodoroSession,
        toggleHabitCompletion,
        refreshProgress,
        resetWeeklyHabits: resetWeeklyHabitsAction
    };
}
_s(useDashboardIntegration, "moUkfLhvufUEM6iphQOzqnYuD3w=");
function useQuickActions(user) {
    _s1();
    const { completeFlashcardSession, completePomodoroSession, toggleHabitCompletion } = useDashboardIntegration(user);
    const handleQuickFlashcardReview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useQuickActions.useCallback[handleQuickFlashcardReview]": async function() {
            let wordsCount = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 5;
            return await completeFlashcardSession(wordsCount, 10); // 10 minutes study time
        }
    }["useQuickActions.useCallback[handleQuickFlashcardReview]"], [
        completeFlashcardSession
    ]);
    const handleQuickPomodoro = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useQuickActions.useCallback[handleQuickPomodoro]": async function() {
            let sessions = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 1;
            return await completePomodoroSession(sessions, sessions * 25); // 25 minutes per session
        }
    }["useQuickActions.useCallback[handleQuickPomodoro]"], [
        completePomodoroSession
    ]);
    const handleQuickHabitCheck = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useQuickActions.useCallback[handleQuickHabitCheck]": async (habitId)=>{
            return await toggleHabitCompletion(habitId, true);
        }
    }["useQuickActions.useCallback[handleQuickHabitCheck]"], [
        toggleHabitCompletion
    ]);
    return {
        handleQuickFlashcardReview,
        handleQuickPomodoro,
        handleQuickHabitCheck
    };
}
_s1(useQuickActions, "Jz5hqW5gasdCqNHk5LZa481eL1I=", false, function() {
    return [
        useDashboardIntegration
    ];
});
function useRealtimeUpdates(user) {
    _s2();
    const { refreshProgress } = useDashboardIntegration(user);
    // Auto refresh every 5 minutes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useRealtimeUpdates.useEffect": ()=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return;
            const interval = setInterval({
                "useRealtimeUpdates.useEffect.interval": ()=>{
                    refreshProgress();
                }
            }["useRealtimeUpdates.useEffect.interval"], 5 * 60 * 1000); // 5 minutes
            return ({
                "useRealtimeUpdates.useEffect": ()=>clearInterval(interval)
            })["useRealtimeUpdates.useEffect"];
        }
    }["useRealtimeUpdates.useEffect"], [
        user === null || user === void 0 ? void 0 : user.uid,
        refreshProgress
    ]);
    // Refresh when tab becomes visible
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useRealtimeUpdates.useEffect": ()=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return;
            const handleVisibilityChange = {
                "useRealtimeUpdates.useEffect.handleVisibilityChange": ()=>{
                    if (!document.hidden) {
                        refreshProgress();
                    }
                }
            }["useRealtimeUpdates.useEffect.handleVisibilityChange"];
            document.addEventListener('visibilitychange', handleVisibilityChange);
            return ({
                "useRealtimeUpdates.useEffect": ()=>document.removeEventListener('visibilitychange', handleVisibilityChange)
            })["useRealtimeUpdates.useEffect"];
        }
    }["useRealtimeUpdates.useEffect"], [
        user === null || user === void 0 ? void 0 : user.uid,
        refreshProgress
    ]);
}
_s2(useRealtimeUpdates, "mPgI+7lnYH44R2jXK5wTS83DwfA=", false, function() {
    return [
        useDashboardIntegration
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/AuthContext.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/auth/dist/esm/index.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/auth/dist/esm/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/config.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/firebase/client.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useErrorHandler$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useErrorHandler.ts [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function AuthProvider(param) {
    let { children } = param;
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const { handleError, withErrorHandling } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useErrorHandler$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["useErrorHandler"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            // Listen for auth state changes
            const unsubscribe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["onAuthStateChanged"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"], {
                "AuthProvider.useEffect.unsubscribe": async (firebaseUser)=>{
                    if (firebaseUser) {
                        try {
                            await loadUserProfile(firebaseUser);
                        } catch (error) {
                            handleError(error);
                            setUser(null);
                        } finally{
                            setLoading(false);
                        }
                    } else {
                        setUser(null);
                        setLoading(false);
                    }
                }
            }["AuthProvider.useEffect.unsubscribe"]);
            return ({
                "AuthProvider.useEffect": ()=>unsubscribe()
            })["AuthProvider.useEffect"];
        }
    }["AuthProvider.useEffect"], [
        handleError
    ]);
    const loadUserProfile = async (firebaseUser)=>{
        try {
            // Sử dụng as any để tránh lỗi TypeScript với getIdToken
            // Không force refresh để tránh network issues
            const token = await firebaseUser.getIdToken(false);
            // Add timeout to prevent hanging requests
            const timeoutPromise = new Promise((_, reject)=>setTimeout(()=>reject(new Error('Profile load timeout')), 10000));
            const profilePromise = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].firestore.getProfile(firebaseUser.uid);
            const { profile } = await Promise.race([
                profilePromise,
                timeoutPromise
            ]);
            if (profile) {
                setUser({
                    uid: firebaseUser.uid,
                    name: profile.name || firebaseUser.displayName || 'User',
                    email: profile.email || firebaseUser.email || '',
                    accessToken: token,
                    streak: profile.streak || 0,
                    todayProgress: profile.todayProgress || 0,
                    dailyGoal: profile.dailyGoal || 20,
                    totalWordsLearned: profile.totalWordsLearned || 0,
                    photoURL: profile.photoURL || firebaseUser.photoURL || undefined
                });
            } else {
                var _firebaseUser_email;
                // Create default profile if it doesn't exist
                const defaultProfile = {
                    uid: firebaseUser.uid,
                    name: firebaseUser.displayName || ((_firebaseUser_email = firebaseUser.email) === null || _firebaseUser_email === void 0 ? void 0 : _firebaseUser_email.split('@')[0]) || 'User',
                    email: firebaseUser.email || '',
                    accessToken: token,
                    streak: 0,
                    todayProgress: 0,
                    dailyGoal: 20,
                    totalWordsLearned: 0,
                    photoURL: firebaseUser.photoURL || undefined
                };
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].firestore.updateProfile(firebaseUser.uid, defaultProfile);
                setUser(defaultProfile);
            }
        } catch (error) {
            var _firebaseUser_email1;
            console.error('Error loading user profile:', error);
            // Fallback to basic user info if profile loading fails
            setUser({
                uid: firebaseUser.uid,
                name: firebaseUser.displayName || ((_firebaseUser_email1 = firebaseUser.email) === null || _firebaseUser_email1 === void 0 ? void 0 : _firebaseUser_email1.split('@')[0]) || 'User',
                email: firebaseUser.email || '',
                accessToken: '',
                streak: 0,
                todayProgress: 0,
                dailyGoal: 20,
                totalWordsLearned: 0,
                photoURL: firebaseUser.photoURL || undefined
            });
        } finally{
            setLoading(false);
        }
    };
    const signIn = withErrorHandling(async (email, password)=>{
        setLoading(true);
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].auth.signInWithPassword(email, password);
        if (result.error) {
            throw result.error;
        }
    });
    const signUp = withErrorHandling(async (email, password)=>{
        setLoading(true);
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].auth.signUp(email, password);
        if (result.error) {
            throw result.error;
        }
    });
    const signInWithGoogle = withErrorHandling(async ()=>{
        setLoading(true);
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].auth.signInWithOAuth({
            provider: 'google'
        });
        if (result.error) {
            throw result.error;
        }
    });
    const signOut = withErrorHandling(async ()=>{
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].auth.signOut();
        setUser(null);
    });
    const updateUserProfile = withErrorHandling(async (data)=>{
        if (!user) return;
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["firebase"].firestore.updateProfile(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$firebase$2f$config$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["auth"].currentUser.uid, data);
        setUser((prev)=>prev ? {
                ...prev,
                ...data
            } : null);
    });
    const value = {
        user,
        loading,
        signIn,
        signUp,
        signInWithGoogle,
        signOut,
        updateUserProfile
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/AuthContext.tsx",
        lineNumber: 182,
        columnNumber: 10
    }, this);
}
_s(AuthProvider, "5eDTBRM+HYHogO+MmieeT7YF3VI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useErrorHandler$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["useErrorHandler"]
    ];
});
_c = AuthProvider;
function useAuth() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
_s1(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/LanguageContext.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LanguageProvider",
    ()=>LanguageProvider,
    "useLanguage",
    ()=>useLanguage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$languageDetection$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/languageDetection.ts [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
const LanguageContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function LanguageProvider(param) {
    let { children } = param;
    _s();
    const [userLanguage, setUserLanguageState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('vi'); // Default Vietnamese
    const [detectedLanguage, setDetectedLanguage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('vi');
    const [isClient, setIsClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Check if we're on client side
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LanguageProvider.useEffect": ()=>{
            setIsClient(true);
        }
    }["LanguageProvider.useEffect"], []);
    // Load user language preference from localStorage
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LanguageProvider.useEffect": ()=>{
            if (!isClient) return; // Skip on server side
            try {
                const savedLanguage = localStorage.getItem('userLanguage');
                if (savedLanguage) {
                    setUserLanguageState(savedLanguage);
                } else {
                    // Detect browser language
                    const browserLang = navigator.language.startsWith('en') ? 'en' : 'vi';
                    setUserLanguageState(browserLang);
                }
            } catch (error) {
                console.warn('Failed to access localStorage:', error);
            }
        }
    }["LanguageProvider.useEffect"], [
        isClient
    ]);
    const setUserLanguage = (language)=>{
        setUserLanguageState(language);
        if (isClient) {
            try {
                localStorage.setItem('userLanguage', language);
            } catch (error) {
                console.warn('Failed to save to localStorage:', error);
            }
        }
    };
    const updateDetectedLanguageFromChat = (chatHistory)=>{
        // Chuyển đổi định dạng để match với detectUserLanguage
        const formattedHistory = chatHistory.map((msg)=>({
                content: msg.content,
                sender: msg.role === 'user' ? 'user' : 'assistant'
            }));
        const detected = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$languageDetection$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["detectUserLanguage"])(formattedHistory);
        setDetectedLanguage(detected);
        return detected;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LanguageContext.Provider, {
        value: {
            userLanguage,
            setUserLanguage,
            detectedLanguage,
            setDetectedLanguage,
            updateDetectedLanguageFromChat
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/LanguageContext.tsx",
        lineNumber: 82,
        columnNumber: 5
    }, this);
}
_s(LanguageProvider, "7/XsjtW9FjhcMUx3Jkhorp5kMLY=");
_c = LanguageProvider;
function useLanguage() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useContext"])(LanguageContext);
    if (context === undefined) {
        throw new Error('useLanguage must be used within a LanguageProvider');
    }
    return context;
}
_s1(useLanguage, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "LanguageProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/LevelContext.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LevelProvider",
    ()=>LevelProvider,
    "useLevel",
    ()=>useLevel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$level$2f$levelSystem$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/level/levelSystem.ts [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
const LevelContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function LevelProvider(param) {
    let { children, userId } = param;
    _s();
    const [userStats, setUserStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])({
        totalXP: 0,
        level: 1,
        pomodoroSessions: 0,
        flashcardsStudied: 0,
        chatMessages: 0,
        totalHabitsCompleted: 0,
        streakDays: 0,
        studyTimeMinutes: 0,
        joinDate: new Date()
    });
    const [showLevelUpNotification, setShowLevelUpNotification] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const userLevel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$level$2f$levelSystem$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["calculateLevel"])(userStats.totalXP);
    // Load user stats from localStorage or API
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LevelProvider.useEffect": ()=>{
            if (userId) {
                loadUserStats(userId);
            } else {
                loadLocalStats();
            }
        }
    }["LevelProvider.useEffect"], [
        userId
    ]);
    const loadUserStats = async (userId)=>{
        try {
            // TODO: Load from Firebase/API
            const savedStats = localStorage.getItem("userStats_".concat(userId));
            if (savedStats) {
                const parsed = JSON.parse(savedStats);
                setUserStats({
                    ...parsed,
                    joinDate: new Date(parsed.joinDate)
                });
            }
        } catch (error) {
            console.error('Failed to load user stats:', error);
        }
    };
    const loadLocalStats = ()=>{
        try {
            const savedStats = localStorage.getItem('userStats_local');
            if (savedStats) {
                const parsed = JSON.parse(savedStats);
                setUserStats({
                    ...parsed,
                    joinDate: new Date(parsed.joinDate)
                });
            }
        } catch (error) {
            console.error('Failed to load local stats:', error);
        }
    };
    const saveUserStats = async (stats)=>{
        try {
            const key = userId ? "userStats_".concat(userId) : 'userStats_local';
            localStorage.setItem(key, JSON.stringify(stats));
        // TODO: Save to Firebase/API if userId exists
        } catch (error) {
            console.error('Failed to save user stats:', error);
        }
    };
    const addUserXP = async (action, customAmount)=>{
        const xpAmount = customAmount || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$level$2f$levelSystem$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["XP_ACTIONS"][action].amount;
        const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$level$2f$levelSystem$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["addXP"])(userStats.totalXP, xpAmount);
        const newStats = {
            ...userStats,
            totalXP: result.newLevel.totalXP,
            level: result.newLevel.level
        };
        setUserStats(newStats);
        await saveUserStats(newStats);
        // Show level up notification if leveled up
        if (result.levelUp) {
            setShowLevelUpNotification(true);
            // Auto hide after 5 seconds
            setTimeout(()=>{
                setShowLevelUpNotification(false);
            }, 5000);
        }
    };
    const updateStats = async (newStats)=>{
        const updatedStats = {
            ...userStats,
            ...newStats,
            // Always sync level with totalXP when updating
            level: newStats.totalXP ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$level$2f$levelSystem$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["calculateLevel"])(newStats.totalXP).level : userStats.level
        };
        setUserStats(updatedStats);
        await saveUserStats(updatedStats);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LevelContext.Provider, {
        value: {
            userLevel,
            userStats,
            addUserXP,
            updateStats,
            showLevelUpNotification,
            setShowLevelUpNotification
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/LevelContext.tsx",
        lineNumber: 153,
        columnNumber: 5
    }, this);
}
_s(LevelProvider, "tukLVYmE68+I4gBWW5OjxviqaGY=");
_c = LevelProvider;
const useLevel = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useContext"])(LevelContext);
    if (context === undefined) {
        throw new Error('useLevel must be used within a LevelProvider');
    }
    return context;
};
_s1(useLevel, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "LevelProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/PomodoroContext.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PomodoroProvider",
    ()=>PomodoroProvider,
    "usePomodoro",
    ()=>usePomodoro
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
const PomodoroContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const defaultSettings = {
    pomodoroTime: 25,
    shortBreakTime: 5,
    longBreakTime: 15,
    soundEnabled: true,
    autoStartBreaks: false,
    autoStartPomodoros: false,
    notificationsEnabled: true
};
const defaultState = {
    timeLeft: 25 * 60,
    isActive: false,
    mode: 'pomodoro',
    completedPomodoros: 0
};
function PomodoroProvider(param) {
    let { children } = param;
    _s();
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(defaultState);
    const [settings, setSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(defaultSettings);
    // Load settings from localStorage on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PomodoroProvider.useEffect": ()=>{
            const savedSettings = localStorage.getItem('pomodoro-settings');
            if (savedSettings) {
                try {
                    setSettings(JSON.parse(savedSettings));
                } catch (error) {
                    console.warn('Failed to load pomodoro settings:', error);
                }
            }
        }
    }["PomodoroProvider.useEffect"], []);
    // Save settings to localStorage when changed
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PomodoroProvider.useEffect": ()=>{
            localStorage.setItem('pomodoro-settings', JSON.stringify(settings));
        }
    }["PomodoroProvider.useEffect"], [
        settings
    ]);
    // Load state from localStorage on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PomodoroProvider.useEffect": ()=>{
            const savedState = localStorage.getItem('pomodoro-state');
            if (savedState) {
                try {
                    const parsed = JSON.parse(savedState);
                    // Only restore if timer was active
                    if (parsed.isActive) {
                        setState(parsed);
                    }
                } catch (error) {
                    console.warn('Failed to load pomodoro state:', error);
                }
            }
        }
    }["PomodoroProvider.useEffect"], []);
    // Save state to localStorage when changed
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PomodoroProvider.useEffect": ()=>{
            localStorage.setItem('pomodoro-state', JSON.stringify(state));
        }
    }["PomodoroProvider.useEffect"], [
        state
    ]);
    // Đảm bảo timeLeft luôn có giá trị hợp lệ khi không chạy
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PomodoroProvider.useEffect": ()=>{
            if (!state.isActive && state.timeLeft === 0) {
                const duration = ({
                    "PomodoroProvider.useEffect.duration": ()=>{
                        switch(state.mode){
                            case 'pomodoro':
                                return settings.pomodoroTime * 60;
                            case 'shortBreak':
                                return settings.shortBreakTime * 60;
                            case 'longBreak':
                                return settings.longBreakTime * 60;
                            default:
                                return 25 * 60;
                        }
                    }
                })["PomodoroProvider.useEffect.duration"]();
                setState({
                    "PomodoroProvider.useEffect": (prev)=>({
                            ...prev,
                            timeLeft: duration
                        })
                }["PomodoroProvider.useEffect"]);
            }
        }
    }["PomodoroProvider.useEffect"], [
        state.isActive,
        state.mode,
        state.timeLeft,
        settings
    ]);
    const handleTimerComplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[handleTimerComplete]": ()=>{
            // Play sound if enabled
            if (settings.soundEnabled) {
                try {
                    const audio = new Audio('/sounds/timer-complete.mp3');
                    audio.play().catch({
                        "PomodoroProvider.useCallback[handleTimerComplete]": ()=>{
                            // Fallback: use Web Audio API
                            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                            const oscillator = audioContext.createOscillator();
                            const gainNode = audioContext.createGain();
                            oscillator.connect(gainNode);
                            gainNode.connect(audioContext.destination);
                            oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
                            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1);
                            oscillator.start(audioContext.currentTime);
                            oscillator.stop(audioContext.currentTime + 1);
                        }
                    }["PomodoroProvider.useCallback[handleTimerComplete]"]);
                } catch (error) {
                    console.warn('Failed to play timer sound:', error);
                }
            }
            // Show notification if enabled
            if (settings.notificationsEnabled && 'Notification' in window) {
                if (Notification.permission === 'granted') {
                    const modeText = state.mode === 'pomodoro' ? 'Pomodoro' : state.mode === 'shortBreak' ? 'Nghỉ ngắn' : 'Nghỉ dài';
                    new Notification("".concat(modeText, " hoàn thành!"), {
                        body: state.mode === 'pomodoro' ? 'Chúc mừng! Hãy nghỉ ngơi một chút.' : 'Thời gian nghỉ kết thúc. Hãy quay lại làm việc!',
                        icon: '/images/logo-192.png'
                    });
                } else if (Notification.permission !== 'denied') {
                    Notification.requestPermission();
                }
            }
            // Chuyển mode tự động sau khi hoàn thành/skip
            setState({
                "PomodoroProvider.useCallback[handleTimerComplete]": (prev)=>{
                    const wasPomodoro = prev.mode === 'pomodoro';
                    const newCompleted = wasPomodoro ? prev.completedPomodoros + 1 : prev.completedPomodoros;
                    // Quy tắc: sau mỗi 4 Pomodoro thì nghỉ dài
                    const nextMode = wasPomodoro ? newCompleted % 4 === 0 ? 'longBreak' : 'shortBreak' : 'pomodoro';
                    const nextTimeLeft = nextMode === 'pomodoro' ? settings.pomodoroTime * 60 : nextMode === 'shortBreak' ? settings.shortBreakTime * 60 : settings.longBreakTime * 60;
                    const shouldAutoStart = nextMode === 'pomodoro' ? settings.autoStartPomodoros : settings.autoStartBreaks;
                    return {
                        ...prev,
                        completedPomodoros: newCompleted,
                        mode: nextMode,
                        timeLeft: nextTimeLeft,
                        isActive: shouldAutoStart
                    };
                }
            }["PomodoroProvider.useCallback[handleTimerComplete]"]);
        }
    }["PomodoroProvider.useCallback[handleTimerComplete]"], [
        state.mode,
        settings.soundEnabled,
        settings.notificationsEnabled,
        settings.pomodoroTime,
        settings.shortBreakTime,
        settings.longBreakTime,
        settings.autoStartBreaks,
        settings.autoStartPomodoros
    ]);
    // Timer effect
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PomodoroProvider.useEffect": ()=>{
            let interval = null;
            if (state.isActive && state.timeLeft > 0) {
                interval = setInterval({
                    "PomodoroProvider.useEffect": ()=>{
                        setState({
                            "PomodoroProvider.useEffect": (prev)=>{
                                const newTimeLeft = prev.timeLeft - 1;
                                if (newTimeLeft <= 0) {
                                    // Timer completed -> chuyển mode trong handleTimerComplete
                                    handleTimerComplete();
                                    // Không ghi đè state ở đây, để handleTimerComplete quyết định
                                    return prev;
                                }
                                return {
                                    ...prev,
                                    timeLeft: newTimeLeft
                                };
                            }
                        }["PomodoroProvider.useEffect"]);
                    }
                }["PomodoroProvider.useEffect"], 1000);
            }
            return ({
                "PomodoroProvider.useEffect": ()=>{
                    if (interval) {
                        clearInterval(interval);
                    }
                }
            })["PomodoroProvider.useEffect"];
        }
    }["PomodoroProvider.useEffect"], [
        state.isActive,
        state.timeLeft,
        handleTimerComplete
    ]);
    const getCurrentDuration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[getCurrentDuration]": ()=>{
            switch(state.mode){
                case 'pomodoro':
                    return settings.pomodoroTime * 60;
                case 'shortBreak':
                    return settings.shortBreakTime * 60;
                case 'longBreak':
                    return settings.longBreakTime * 60;
                default:
                    return 25 * 60;
            }
        }
    }["PomodoroProvider.useCallback[getCurrentDuration]"], [
        state.mode,
        settings
    ]);
    const startTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[startTimer]": ()=>{
            setState({
                "PomodoroProvider.useCallback[startTimer]": (prev)=>({
                        ...prev,
                        isActive: true
                    })
            }["PomodoroProvider.useCallback[startTimer]"]);
        }
    }["PomodoroProvider.useCallback[startTimer]"], []);
    const pauseTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[pauseTimer]": ()=>{
            setState({
                "PomodoroProvider.useCallback[pauseTimer]": (prev)=>({
                        ...prev,
                        isActive: false
                    })
            }["PomodoroProvider.useCallback[pauseTimer]"]);
        }
    }["PomodoroProvider.useCallback[pauseTimer]"], []);
    const resetTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[resetTimer]": ()=>{
            const duration = getCurrentDuration();
            setState({
                "PomodoroProvider.useCallback[resetTimer]": (prev)=>({
                        ...prev,
                        timeLeft: duration,
                        isActive: false
                    })
            }["PomodoroProvider.useCallback[resetTimer]"]);
        }
    }["PomodoroProvider.useCallback[resetTimer]"], [
        getCurrentDuration
    ]);
    const skipTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[skipTimer]": ()=>{
            // Dừng ngay lập tức rồi chuyển mode để tránh race condition với interval
            setState({
                "PomodoroProvider.useCallback[skipTimer]": (prev)=>({
                        ...prev,
                        isActive: false
                    })
            }["PomodoroProvider.useCallback[skipTimer]"]);
            handleTimerComplete();
        }
    }["PomodoroProvider.useCallback[skipTimer]"], [
        handleTimerComplete
    ]);
    const switchMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[switchMode]": (mode)=>{
            setState({
                "PomodoroProvider.useCallback[switchMode]": (prev)=>({
                        ...prev,
                        mode,
                        isActive: false,
                        timeLeft: mode === 'pomodoro' ? settings.pomodoroTime * 60 : mode === 'shortBreak' ? settings.shortBreakTime * 60 : settings.longBreakTime * 60
                    })
            }["PomodoroProvider.useCallback[switchMode]"]);
        }
    }["PomodoroProvider.useCallback[switchMode]"], [
        settings
    ]);
    const updateSettings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[updateSettings]": (newSettings)=>{
            setSettings({
                "PomodoroProvider.useCallback[updateSettings]": (prev)=>({
                        ...prev,
                        ...newSettings
                    })
            }["PomodoroProvider.useCallback[updateSettings]"]);
        }
    }["PomodoroProvider.useCallback[updateSettings]"], []);
    const setCurrentTask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[setCurrentTask]": (taskId, taskText)=>{
            setState({
                "PomodoroProvider.useCallback[setCurrentTask]": (prev)=>({
                        ...prev,
                        currentTaskId: taskId,
                        currentTaskText: taskText
                    })
            }["PomodoroProvider.useCallback[setCurrentTask]"]);
        }
    }["PomodoroProvider.useCallback[setCurrentTask]"], []);
    const clearCurrentTask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[clearCurrentTask]": ()=>{
            setState({
                "PomodoroProvider.useCallback[clearCurrentTask]": (prev)=>({
                        ...prev,
                        currentTaskId: undefined,
                        currentTaskText: undefined
                    })
            }["PomodoroProvider.useCallback[clearCurrentTask]"]);
        }
    }["PomodoroProvider.useCallback[clearCurrentTask]"], []);
    const progress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[progress]": ()=>{
            const duration = getCurrentDuration();
            return (duration - state.timeLeft) / duration * 100;
        }
    }["PomodoroProvider.useCallback[progress]"], [
        state.timeLeft,
        getCurrentDuration
    ]);
    const formatTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PomodoroProvider.useCallback[formatTime]": (seconds)=>{
            const mins = Math.floor(seconds / 60);
            const secs = seconds % 60;
            return "".concat(mins.toString().padStart(2, '0'), ":").concat(secs.toString().padStart(2, '0'));
        }
    }["PomodoroProvider.useCallback[formatTime]"], []);
    const value = {
        state,
        settings,
        startTimer,
        pauseTimer,
        resetTimer,
        skipTimer,
        switchMode,
        updateSettings,
        setCurrentTask,
        clearCurrentTask,
        progress: progress(),
        formattedTime: formatTime(state.timeLeft)
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PomodoroContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/PomodoroContext.tsx",
        lineNumber: 356,
        columnNumber: 5
    }, this);
}
_s(PomodoroProvider, "FK+HLFU6EbSCSfFoCytOxtqqRVU=");
_c = PomodoroProvider;
function usePomodoro() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useContext"])(PomodoroContext);
    if (context === undefined) {
        throw new Error('usePomodoro must be used within a PomodoroProvider');
    }
    return context;
}
_s1(usePomodoro, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "PomodoroProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/transcript.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "copyTranscript",
    ()=>copyTranscript,
    "toMarkdownTranscript",
    ()=>toMarkdownTranscript,
    "toPlainTextTranscript",
    ()=>toPlainTextTranscript
]);
function toMarkdownTranscript(messages) {
    let transcript = '# Chat Transcript\n\n';
    messages.forEach((message, index)=>{
        const timestamp = new Date(message.timestamp).toLocaleString('vi-VN');
        const sender = message.sender === 'user' ? 'Bạn' : 'AI Tutor';
        transcript += "## ".concat(sender, " - ").concat(timestamp, "\n\n");
        transcript += "".concat(message.content, "\n\n");
        if (index < messages.length - 1) {
            transcript += '---\n\n';
        }
    });
    return transcript;
}
function toPlainTextTranscript(messages) {
    let transcript = 'CHAT TRANSCRIPT\n';
    transcript += '='.repeat(50) + '\n\n';
    messages.forEach((message, index)=>{
        const timestamp = new Date(message.timestamp).toLocaleString('vi-VN');
        const sender = message.sender === 'user' ? 'Bạn' : 'AI Tutor';
        transcript += "".concat(sender, " (").concat(timestamp, "):\n");
        transcript += "".concat(message.content, "\n\n");
        if (index < messages.length - 1) {
            transcript += '-'.repeat(30) + '\n\n';
        }
    });
    return transcript;
}
async function copyTranscript(messages) {
    let format = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'markdown';
    try {
        const transcript = format === 'markdown' ? toMarkdownTranscript(messages) : toPlainTextTranscript(messages);
        await navigator.clipboard.writeText(transcript);
        return true;
    } catch (error) {
        console.error('Failed to copy transcript:', error);
        return false;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/languageDetection.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Language Detection and Suggestion Generation
 */ __turbopack_context__.s([
    "detectUserLanguage",
    ()=>detectUserLanguage,
    "generateContextualSuggestions",
    ()=>generateContextualSuggestions,
    "getLocalizedSuggestions",
    ()=>getLocalizedSuggestions
]);
function detectUserLanguage(chatHistory) {
    if (!chatHistory || chatHistory.length === 0) {
        return 'vi'; // Default Vietnamese
    }
    // Get user messages only
    const userMessages = chatHistory.filter((msg)=>msg.sender === 'user').map((msg)=>msg.content).slice(-10); // Last 10 messages
    if (userMessages.length === 0) {
        return 'vi';
    }
    // Simple language detection based on patterns
    const text = userMessages.join(' ').toLowerCase();
    // English indicators
    const englishPatterns = [
        /\b(the|and|or|but|in|on|at|to|for|of|with|by)\b/g,
        /\b(hello|hi|how|what|when|where|why|can|could|would|should)\b/g,
        /\b(please|thank|thanks|sorry|excuse|help|need|want)\b/g
    ];
    // Vietnamese indicators
    const vietnamesePatterns = [
        /\b(và|hoặc|nhưng|trong|trên|tại|để|của|với|bởi)\b/g,
        /\b(xin|chào|làm|thế|nào|gì|khi|nào|ở|đâu|tại|sao|có|thể)\b/g,
        /\b(cảm|ơn|xin|lỗi|giúp|cần|muốn|là|được)\b/g
    ];
    let englishScore = 0;
    let vietnameseScore = 0;
    englishPatterns.forEach((pattern)=>{
        const matches = text.match(pattern);
        englishScore += matches ? matches.length : 0;
    });
    vietnamesePatterns.forEach((pattern)=>{
        const matches = text.match(pattern);
        vietnameseScore += matches ? matches.length : 0;
    });
    // Also check for Vietnamese diacritics
    const vietnameseDiacritics = /[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]/g;
    const diacriticMatches = text.match(vietnameseDiacritics);
    vietnameseScore += diacriticMatches ? diacriticMatches.length * 2 : 0;
    return vietnameseScore > englishScore ? 'vi' : 'en';
}
function getLocalizedSuggestions(language) {
    const timeOfDay = getTimeOfDay();
    if (language === 'en') {
        return getEnglishSuggestions(timeOfDay);
    } else {
        return getVietnameseSuggestions(timeOfDay);
    }
}
function getTimeOfDay() {
    const hour = new Date().getHours();
    if (hour < 12) return 'morning';
    if (hour < 18) return 'afternoon';
    return 'evening';
}
function getEnglishSuggestions(timeOfDay) {
    const suggestionSets = {
        morning: [
            {
                id: '1',
                title: 'Morning Grammar Boost',
                prompt: 'Help me practice English grammar with some morning exercises',
                category: 'grammar',
                icon: '📝'
            },
            {
                id: '2',
                title: 'Daily Vocabulary',
                prompt: 'Teach me 5 new English words for today',
                category: 'vocabulary',
                icon: '📚'
            },
            {
                id: '3',
                title: 'Pronunciation Practice',
                prompt: 'Help me practice English pronunciation',
                category: 'pronunciation',
                icon: '🗣️'
            },
            {
                id: '4',
                title: 'Morning Conversation',
                prompt: "Let's have a casual morning conversation in English",
                category: 'conversation',
                icon: '☕'
            },
            {
                id: '5',
                title: 'News Discussion',
                prompt: "Discuss today's news in English",
                category: 'current events',
                icon: '📰'
            },
            {
                id: '6',
                title: 'English Idioms',
                prompt: 'Teach me some common English idioms',
                category: 'idioms',
                icon: '💡'
            }
        ],
        afternoon: [
            {
                id: '1',
                title: 'Afternoon Tea Chat',
                prompt: "Let's have an afternoon tea conversation in English",
                category: 'conversation',
                icon: '🫖'
            },
            {
                id: '2',
                title: 'Describing Your Afternoon',
                prompt: 'Help me describe my afternoon activities in English',
                category: 'daily life',
                icon: '🌤️'
            },
            {
                id: '3',
                title: 'Afternoon Idioms',
                prompt: 'Teach me English idioms related to time and daily activities',
                category: 'idioms',
                icon: '⏰'
            },
            {
                id: '4',
                title: 'Past Perfect Practice',
                prompt: 'Help me practice past perfect tense with afternoon scenarios',
                category: 'grammar',
                icon: '⏪'
            },
            {
                id: '5',
                title: 'Afternoon Movie Review',
                prompt: "Let's discuss and review movies in English",
                category: 'entertainment',
                icon: '🎬'
            },
            {
                id: '6',
                title: 'Relaxing Conversation Starters',
                prompt: 'Give me some relaxing conversation topics for the afternoon',
                category: 'conversation',
                icon: '💬'
            }
        ],
        evening: [
            {
                id: '1',
                title: 'Evening Reflection',
                prompt: 'Help me reflect on my day in English',
                category: 'daily life',
                icon: '🌅'
            },
            {
                id: '2',
                title: 'Bedtime Stories',
                prompt: 'Tell me a short bedtime story in English',
                category: 'stories',
                icon: '📖'
            },
            {
                id: '3',
                title: 'Evening News',
                prompt: 'Discuss evening news and current events',
                category: 'current events',
                icon: '📺'
            },
            {
                id: '4',
                title: 'Night Vocabulary',
                prompt: 'Teach me English words related to evening and night',
                category: 'vocabulary',
                icon: '🌙'
            },
            {
                id: '5',
                title: 'Dinner Conversation',
                prompt: "Let's have a dinner conversation in English",
                category: 'food',
                icon: '🍽️'
            },
            {
                id: '6',
                title: 'Planning Tomorrow',
                prompt: "Help me plan tomorrow's activities in English",
                category: 'future plans',
                icon: '📅'
            }
        ]
    };
    return suggestionSets[timeOfDay] || suggestionSets.afternoon;
}
function getVietnameseSuggestions(timeOfDay) {
    const suggestionSets = {
        morning: [
            {
                id: '1',
                title: 'Luyện ngữ pháp buổi sáng',
                prompt: 'Giúp tôi luyện ngữ pháp tiếng Anh với bài tập buổi sáng',
                category: 'grammar',
                icon: '📝'
            },
            {
                id: '2',
                title: 'Từ vựng hàng ngày',
                prompt: 'Dạy tôi 5 từ tiếng Anh mới hôm nay',
                category: 'vocabulary',
                icon: '📚'
            },
            {
                id: '3',
                title: 'Luyện phát âm',
                prompt: 'Giúp tôi luyện phát âm tiếng Anh',
                category: 'pronunciation',
                icon: '🗣️'
            },
            {
                id: '4',
                title: 'Trò chuyện buổi sáng',
                prompt: 'Hãy trò chuyện tiếng Anh thông thường buổi sáng',
                category: 'conversation',
                icon: '☕'
            },
            {
                id: '5',
                title: 'Thảo luận tin tức',
                prompt: 'Thảo luận tin tức hôm nay bằng tiếng Anh',
                category: 'current events',
                icon: '📰'
            },
            {
                id: '6',
                title: 'Thành ngữ tiếng Anh',
                prompt: 'Dạy tôi một số thành ngữ tiếng Anh phổ biến',
                category: 'idioms',
                icon: '💡'
            }
        ],
        afternoon: [
            {
                id: '1',
                title: 'Trò chuyện trà chiều',
                prompt: 'Hãy trò chuyện trà chiều bằng tiếng Anh',
                category: 'conversation',
                icon: '🫖'
            },
            {
                id: '2',
                title: 'Mô tả buổi chiều',
                prompt: 'Giúp tôi mô tả các hoạt động buổi chiều bằng tiếng Anh',
                category: 'daily life',
                icon: '🌤️'
            },
            {
                id: '3',
                title: 'Thành ngữ buổi chiều',
                prompt: 'Dạy tôi thành ngữ tiếng Anh về thời gian và hoạt động hàng ngày',
                category: 'idioms',
                icon: '⏰'
            },
            {
                id: '4',
                title: 'Luyện quá khứ hoàn thành',
                prompt: 'Giúp tôi luyện thì quá khứ hoàn thành với tình huống buổi chiều',
                category: 'grammar',
                icon: '⏪'
            },
            {
                id: '5',
                title: 'Review phim buổi chiều',
                prompt: 'Hãy thảo luận và review phim bằng tiếng Anh',
                category: 'entertainment',
                icon: '🎬'
            },
            {
                id: '6',
                title: 'Chủ đề thư giãn',
                prompt: 'Cho tôi một số chủ đề trò chuyện thư giãn cho buổi chiều',
                category: 'conversation',
                icon: '💬'
            }
        ],
        evening: [
            {
                id: '1',
                title: 'Suy ngẫm buổi tối',
                prompt: 'Giúp tôi suy ngẫm về ngày hôm nay bằng tiếng Anh',
                category: 'daily life',
                icon: '🌅'
            },
            {
                id: '2',
                title: 'Truyện trước khi ngủ',
                prompt: 'Kể cho tôi một câu chuyện ngắn bằng tiếng Anh',
                category: 'stories',
                icon: '📖'
            },
            {
                id: '3',
                title: 'Tin tức buổi tối',
                prompt: 'Thảo luận tin tức buổi tối và sự kiện hiện tại',
                category: 'current events',
                icon: '📺'
            },
            {
                id: '4',
                title: 'Từ vựng về đêm',
                prompt: 'Dạy tôi từ tiếng Anh liên quan đến buổi tối và ban đêm',
                category: 'vocabulary',
                icon: '🌙'
            },
            {
                id: '5',
                title: 'Trò chuyện bữa tối',
                prompt: 'Hãy trò chuyện bữa tối bằng tiếng Anh',
                category: 'food',
                icon: '🍽️'
            },
            {
                id: '6',
                title: 'Lập kế hoạch ngày mai',
                prompt: 'Giúp tôi lập kế hoạch hoạt động ngày mai bằng tiếng Anh',
                category: 'future plans',
                icon: '📅'
            }
        ]
    };
    return suggestionSets[timeOfDay] || suggestionSets.afternoon;
}
function generateContextualSuggestions(context) {
    // Detect language from chat history if not explicitly set
    let language = context.userLanguage;
    if (!language && context.chatHistory) {
        language = detectUserLanguage(context.chatHistory);
    }
    // Default to Vietnamese
    language = language || 'vi';
    return getLocalizedSuggestions(language);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/date/index.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Các tiện ích xử lý ngày theo múi giờ IANA.
 * Không dùng thư viện ngoài để giữ gọn nhẹ.
 */ /** Lấy time zone của người dùng theo IANA, ví dụ: 'Asia/Ho_Chi_Minh' */ __turbopack_context__.s([
    "formatDateYMD",
    ()=>formatDateYMD,
    "getMonthDayIndexZeroBased",
    ()=>getMonthDayIndexZeroBased,
    "getUserTimeZone",
    ()=>getUserTimeZone,
    "getWeekdayIndexMondayFirst",
    ()=>getWeekdayIndexMondayFirst,
    "isSameCalendarDay",
    ()=>isSameCalendarDay
]);
function getUserTimeZone() {
    try {
        return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    } catch (e) {
        return 'UTC';
    }
}
/** Tạo Date mới đã chuyển đổi theo múi giờ (cùng thời điểm cục bộ ở tz) */ function toTimeZoneLocalDate(date, timeZone) {
    // Biến đổi thành chuỗi theo tz rồi parse lại về Date (giờ địa phương của tz)
    const parts = new Intl.DateTimeFormat('en-CA', {
        timeZone,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    }).formatToParts(date).reduce((acc, p)=>{
        if (p.type !== 'literal') acc[p.type] = p.value;
        return acc;
    }, {});
    const y = Number(parts.year);
    const m = Number(parts.month) - 1; // 0-indexed
    const d = Number(parts.day);
    const hh = Number(parts.hour || '0');
    const mm = Number(parts.minute || '0');
    const ss = Number(parts.second || '0');
    return new Date(y, m, d, hh, mm, ss);
}
function isSameCalendarDay(a, b, timeZone) {
    const aa = toTimeZoneLocalDate(a, timeZone);
    const bb = toTimeZoneLocalDate(b, timeZone);
    return aa.getFullYear() === bb.getFullYear() && aa.getMonth() === bb.getMonth() && aa.getDate() === bb.getDate();
}
function getWeekdayIndexMondayFirst(date, timeZone) {
    const local = toTimeZoneLocalDate(date, timeZone);
    // JS getDay: 0=CN..6=Th7 → chuyển về 0=Th2..6=CN
    return (local.getDay() + 6) % 7;
}
function getMonthDayIndexZeroBased(date, timeZone) {
    const local = toTimeZoneLocalDate(date, timeZone);
    return Math.max(0, local.getDate() - 1);
}
function formatDateYMD(date, timeZone) {
    const local = toTimeZoneLocalDate(date, timeZone);
    const y = local.getFullYear();
    const m = String(local.getMonth() + 1).padStart(2, '0');
    const d = String(local.getDate()).padStart(2, '0');
    return "".concat(y, "-").concat(m, "-").concat(d);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/refresh.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Utility function để refresh hoàn toàn ứng dụng
__turbopack_context__.s([
    "clearAppStorage",
    ()=>clearAppStorage,
    "hardRefresh",
    ()=>hardRefresh,
    "softRefresh",
    ()=>softRefresh
]);
const hardRefresh = ()=>{
    try {
        // 1. Clear tất cả localStorage
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.clear();
        }
        // 2. Clear tất cả sessionStorage
        if ("TURBOPACK compile-time truthy", 1) {
            sessionStorage.clear();
        }
        // 3. Clear tất cả cookies
        if (typeof document !== 'undefined') {
            document.cookie.split(';').forEach((c)=>{
                document.cookie = c.replace(/^ +/, '').replace(/=.*/, '=;expires=' + new Date().toUTCString() + ';path=/');
            });
        }
        // 4. Clear browser cache bằng service worker
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.getRegistrations().then((registrations)=>{
                registrations.forEach((registration)=>{
                    registration.unregister();
                });
            });
        }
        // 5. Clear cache storage
        if ('caches' in window) {
            caches.keys().then((names)=>{
                names.forEach((name)=>{
                    caches.delete(name);
                });
            });
        }
        // 6. Force reload trang với bypass cache
        if ("TURBOPACK compile-time truthy", 1) {
            window.location.reload();
        }
    } catch (error) {
        console.error('Lỗi khi refresh:', error);
        // Fallback: reload bình thường
        if ("TURBOPACK compile-time truthy", 1) {
            window.location.reload();
        }
    }
};
const softRefresh = ()=>{
    if ("TURBOPACK compile-time truthy", 1) {
        window.location.reload();
    }
};
const clearAppStorage = ()=>{
    try {
        if ("TURBOPACK compile-time truthy", 1) {
            // Clear app-specific keys
            const keysToRemove = [
                'auth-token',
                'user-data',
                'chat-history',
                'app-state',
                'theme-preference'
            ];
            keysToRemove.forEach((key)=>{
                localStorage.removeItem(key);
                sessionStorage.removeItem(key);
            });
        }
    } catch (error) {
        console.error('Lỗi khi clear storage:', error);
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_e3715274._.js.map