(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/services/ai/gemini.ts [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_services_ai_gemini_ts_4efba2d4._.js",
  "static/chunks/src_services_ai_gemini_ts_01f0ab34._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/services/ai/gemini.ts [client] (ecmascript)");
    });
});
}),
"[project]/node_modules/pdfjs-dist/build/pdf.mjs [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_pdfjs-dist_build_pdf_mjs_32f4129b._.js",
  "static/chunks/node_modules_@swc_helpers_esm_90dbe0da._.js",
  "static/chunks/node_modules_pdfjs-dist_build_pdf_mjs_01f0ab34._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/pdfjs-dist/build/pdf.mjs [client] (ecmascript)");
    });
});
}),
"[project]/node_modules/mammoth/lib/index.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_underscore_modules_8d68ec7a._.js",
  "static/chunks/node_modules_bluebird_js_release_aa3aeee2._.js",
  "static/chunks/node_modules_mammoth_616db93e._.js",
  "static/chunks/node_modules_next_dist_compiled_2bdbc344._.js",
  "static/chunks/node_modules_jszip_lib_2d4c1349._.js",
  "static/chunks/node_modules_pako_52ecd5f3._.js",
  "static/chunks/node_modules_@xmldom_xmldom_lib_fe30cccd._.js",
  "static/chunks/node_modules_dingbat-to-unicode_dist_1d266524._.js",
  "static/chunks/node_modules_82990ada._.js",
  "static/chunks/node_modules_mammoth_lib_index_01f0ab34.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/mammoth/lib/index.js [client] (ecmascript)");
    });
});
}),
"[project]/node_modules/xlsx/xlsx.mjs [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_xlsx_xlsx_mjs_6addffd6._.js",
  "static/chunks/node_modules_xlsx_xlsx_mjs_01f0ab34._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/xlsx/xlsx.mjs [client] (ecmascript)");
    });
});
}),
"[project]/src/services/ai/chatNaming.ts [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/services/ai/chatNaming.ts [client] (ecmascript)");
    });
});
}),
"[project]/src/services/dashboard/missionsService.ts [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/services/dashboard/missionsService.ts [client] (ecmascript)");
    });
});
}),
]);